--
-- PostgreSQL database dump
--

-- Dumped from database version 15.13 (Homebrew)
-- Dumped by pg_dump version 15.13 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: rma_test_ch; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE rma_test_ch WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'C';


ALTER DATABASE rma_test_ch OWNER TO postgres;

\connect rma_test_ch

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: fuzzystrmatch; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS fuzzystrmatch WITH SCHEMA public;


--
-- Name: EXTENSION fuzzystrmatch; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION fuzzystrmatch IS 'determine similarities and distance between strings';


--
-- Name: financial_year_status_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.financial_year_status_enum AS ENUM (
    'OPEN',
    'CURRENT_FINANCIAL_YEAR',
    'CLOSED'
);


ALTER TYPE public.financial_year_status_enum OWNER TO postgres;

--
-- Name: settlement_type_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.settlement_type_enum AS ENUM (
    'NORMAL_SETTLEMENT',
    'CORRECTION_SETTLEMENT',
    'ANNUAL_RECONCILIATION'
);


ALTER TYPE public.settlement_type_enum OWNER TO postgres;

--
-- Name: to_filtered_tsvector(text, text, regconfig); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.to_filtered_tsvector(input text, filter_type text DEFAULT 'COMMON'::text, ts_config regconfig DEFAULT 'simple'::regconfig) RETURNS tsvector
    LANGUAGE plpgsql
    AS $$ DECLARE filtered_input TEXT; BEGIN SELECT string_agg(input_word, ' ') INTO filtered_input FROM unnest(string_to_array(input, ' ')) AS input_word WHERE lower(input_word) NOT IN (SELECT lower(word) FROM search_irrelevant_words WHERE search_target = 'COMMON' OR search_target = filter_type); RETURN to_tsvector(ts_config, filtered_input); END; $$;


ALTER FUNCTION public.to_filtered_tsvector(input text, filter_type text, ts_config regconfig) OWNER TO postgres;

--
-- Name: update_last_modified_column(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_last_modified_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
    new.last_modified := now();
    return new;
end;
$$;


ALTER FUNCTION public.update_last_modified_column() OWNER TO postgres;

--
-- Name: entry_id; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.entry_id
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.entry_id OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: acc_trans; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.acc_trans (
    trans_id integer,
    chart_id integer NOT NULL,
    amount double precision,
    transdate date DEFAULT CURRENT_DATE,
    source text,
    approved boolean DEFAULT true,
    fx_transaction boolean DEFAULT false,
    project_id integer,
    memo text,
    id integer,
    cleared date,
    vr_id integer,
    entry_id integer DEFAULT nextval('public.entry_id'::regclass),
    tax text,
    taxamount double precision,
    tax_chart_id integer,
    lineamount numeric(12,2) DEFAULT 0,
    imported_transaction_id integer
);


ALTER TABLE public.acc_trans OWNER TO postgres;

--
-- Name: acc_trans_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.acc_trans_log (
    trans_id integer,
    chart_id integer,
    amount double precision,
    transdate date,
    source text,
    approved boolean,
    fx_transaction boolean,
    project_id integer,
    memo text,
    id integer,
    cleared date,
    vr_id integer,
    entry_id integer,
    tax text,
    taxamount double precision,
    tax_chart_id integer,
    ts timestamp without time zone DEFAULT now(),
    lineamount numeric(12,2) DEFAULT 0
);


ALTER TABLE public.acc_trans_log OWNER TO postgres;

--
-- Name: acc_trans_log_deleted; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.acc_trans_log_deleted (
    trans_id integer,
    chart_id integer,
    amount double precision,
    transdate date,
    source text,
    approved boolean,
    fx_transaction boolean,
    project_id integer,
    memo text,
    id integer,
    cleared date,
    vr_id integer,
    entry_id integer,
    tax text,
    taxamount double precision,
    tax_chart_id integer,
    ts timestamp without time zone DEFAULT now(),
    lineamount numeric(12,2) DEFAULT 0
);


ALTER TABLE public.acc_trans_log_deleted OWNER TO postgres;

--
-- Name: addressid; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.addressid
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.addressid OWNER TO postgres;

--
-- Name: address; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.address (
    id integer DEFAULT nextval('public.addressid'::regclass) NOT NULL,
    trans_id integer,
    address1 character varying(64),
    address2 character varying(64),
    city character varying(64),
    state character varying(32),
    zipcode character varying(32),
    country character varying(32),
    post_office character varying(64),
    is_migrated boolean DEFAULT true
);


ALTER TABLE public.address OWNER TO postgres;

--
-- Name: id; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.id
    START WITH 10000
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.id OWNER TO postgres;

--
-- Name: ap; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ap (
    id integer DEFAULT nextval('public.id'::regclass),
    invnumber text,
    transdate date DEFAULT CURRENT_DATE,
    vendor_id integer,
    taxincluded boolean DEFAULT false,
    amount double precision,
    netamount double precision,
    paid double precision,
    datepaid date,
    duedate date,
    invoice boolean DEFAULT false,
    ordnumber text,
    curr character(3),
    notes text,
    employee_id integer,
    till character varying(20),
    quonumber text,
    intnotes text,
    department_id integer DEFAULT 0,
    shipvia text,
    language_code character varying(6),
    ponumber text,
    shippingpoint text,
    terms smallint DEFAULT 0,
    approved boolean DEFAULT true,
    cashdiscount real,
    discountterms smallint,
    waybill text,
    warehouse_id integer,
    description text,
    onhold boolean DEFAULT false,
    exchangerate double precision,
    dcn text,
    bank_id integer,
    paymentmethod_id integer,
    fxamount double precision DEFAULT 0,
    fxpaid double precision DEFAULT 0,
    linetax boolean DEFAULT false,
    ts timestamp without time zone DEFAULT now()
);


ALTER TABLE public.ap OWNER TO postgres;

--
-- Name: ap_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ap_log (
    id integer,
    invnumber text,
    transdate date,
    vendor_id integer,
    taxincluded boolean,
    amount double precision,
    netamount double precision,
    paid double precision,
    datepaid date,
    duedate date,
    invoice boolean,
    ordnumber text,
    curr character(3),
    notes text,
    employee_id integer,
    till character varying(20),
    quonumber text,
    intnotes text,
    department_id integer,
    shipvia text,
    language_code character varying(6),
    ponumber text,
    shippingpoint text,
    terms smallint,
    approved boolean,
    cashdiscount real,
    discountterms smallint,
    waybill text,
    warehouse_id integer,
    description text,
    onhold boolean,
    exchangerate double precision,
    dcn text,
    bank_id integer,
    paymentmethod_id integer,
    fxamount double precision,
    fxpaid double precision,
    linetax boolean,
    ts timestamp without time zone
);


ALTER TABLE public.ap_log OWNER TO postgres;

--
-- Name: ap_log_deleted; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ap_log_deleted (
    id integer,
    invnumber text,
    transdate date,
    vendor_id integer,
    taxincluded boolean,
    amount double precision,
    netamount double precision,
    paid double precision,
    datepaid date,
    duedate date,
    invoice boolean,
    ordnumber text,
    curr character(3),
    notes text,
    employee_id integer,
    till character varying(20),
    quonumber text,
    intnotes text,
    department_id integer,
    shipvia text,
    language_code character varying(6),
    ponumber text,
    shippingpoint text,
    terms smallint,
    approved boolean,
    cashdiscount real,
    discountterms smallint,
    waybill text,
    warehouse_id integer,
    description text,
    onhold boolean,
    exchangerate double precision,
    dcn text,
    bank_id integer,
    paymentmethod_id integer,
    fxamount double precision,
    fxpaid double precision,
    linetax boolean,
    ts timestamp without time zone
);


ALTER TABLE public.ap_log_deleted OWNER TO postgres;

--
-- Name: ar; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ar (
    id integer DEFAULT nextval('public.id'::regclass),
    invnumber text,
    transdate date DEFAULT CURRENT_DATE,
    customer_id integer,
    taxincluded boolean,
    amount double precision,
    netamount double precision,
    paid double precision,
    datepaid date,
    duedate date,
    invoice boolean DEFAULT false,
    shippingpoint text,
    terms smallint DEFAULT 0,
    notes text,
    curr character(3),
    ordnumber text,
    employee_id integer,
    till character varying(20),
    quonumber text,
    intnotes text,
    department_id integer DEFAULT 0,
    shipvia text,
    language_code character varying(6),
    ponumber text,
    approved boolean DEFAULT true,
    cashdiscount real,
    discountterms smallint,
    waybill text,
    warehouse_id integer,
    description text,
    onhold boolean DEFAULT false,
    exchangerate double precision,
    dcn text,
    bank_id integer,
    paymentmethod_id integer,
    fxamount double precision DEFAULT 0,
    fxpaid double precision DEFAULT 0,
    linetax boolean DEFAULT false,
    ts timestamp without time zone DEFAULT now()
);


ALTER TABLE public.ar OWNER TO postgres;

--
-- Name: ar_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ar_log (
    id integer,
    invnumber text,
    transdate date,
    customer_id integer,
    taxincluded boolean,
    amount double precision,
    netamount double precision,
    paid double precision,
    datepaid date,
    duedate date,
    invoice boolean,
    shippingpoint text,
    terms smallint,
    notes text,
    curr character(3),
    ordnumber text,
    employee_id integer,
    till character varying(20),
    quonumber text,
    intnotes text,
    department_id integer,
    shipvia text,
    language_code character varying(6),
    ponumber text,
    approved boolean,
    cashdiscount real,
    discountterms smallint,
    waybill text,
    warehouse_id integer,
    description text,
    onhold boolean,
    exchangerate double precision,
    dcn text,
    bank_id integer,
    paymentmethod_id integer,
    fxamount double precision,
    fxpaid double precision,
    linetax boolean,
    ts timestamp without time zone
);


ALTER TABLE public.ar_log OWNER TO postgres;

--
-- Name: ar_log_deleted; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ar_log_deleted (
    id integer,
    invnumber text,
    transdate date,
    customer_id integer,
    taxincluded boolean,
    amount double precision,
    netamount double precision,
    paid double precision,
    datepaid date,
    duedate date,
    invoice boolean,
    shippingpoint text,
    terms smallint,
    notes text,
    curr character(3),
    ordnumber text,
    employee_id integer,
    till character varying(20),
    quonumber text,
    intnotes text,
    department_id integer,
    shipvia text,
    language_code character varying(6),
    ponumber text,
    approved boolean,
    cashdiscount real,
    discountterms smallint,
    waybill text,
    warehouse_id integer,
    description text,
    onhold boolean,
    exchangerate double precision,
    dcn text,
    bank_id integer,
    paymentmethod_id integer,
    fxamount double precision,
    fxpaid double precision,
    linetax boolean,
    ts timestamp without time zone
);


ALTER TABLE public.ar_log_deleted OWNER TO postgres;

--
-- Name: assemblyid; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.assemblyid
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.assemblyid OWNER TO postgres;

--
-- Name: assembly; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.assembly (
    id integer DEFAULT nextval('public.assemblyid'::regclass),
    parts_id integer,
    qty double precision,
    bom boolean,
    adj boolean,
    aid integer
);


ALTER TABLE public.assembly OWNER TO postgres;

--
-- Name: audittrail; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.audittrail (
    trans_id integer,
    tablename text,
    reference text,
    formname text,
    action text,
    transdate timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    employee_id integer
);


ALTER TABLE public.audittrail OWNER TO postgres;

--
-- Name: bank; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.bank (
    id integer,
    name character varying(64),
    iban character varying(34),
    bic character varying(11),
    address_id integer DEFAULT nextval('public.addressid'::regclass),
    dcn text,
    rvc text,
    membernumber text,
    qriban text,
    strdbkginf text,
    invdescriptionqr text
);


ALTER TABLE public.bank OWNER TO postgres;

--
-- Name: bank_account; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.bank_account (
    id integer NOT NULL,
    bic text,
    iban text,
    account text,
    bank text,
    branch text,
    country text,
    country_iso text,
    city text,
    state text,
    zip text,
    address text,
    description text,
    chart_id integer,
    inactive boolean,
    currency character varying(3),
    blink_permission_id bigint,
    blink_account_id text
);


ALTER TABLE public.bank_account OWNER TO postgres;

--
-- Name: bank_account_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.bank_account ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.bank_account_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: banking_export_event; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.banking_export_event (
    id integer NOT NULL,
    status text NOT NULL,
    bank_account_id integer NOT NULL,
    source_type text NOT NULL,
    exported_when timestamp without time zone NOT NULL,
    is_manual boolean NOT NULL,
    export_message_id text NOT NULL,
    export_submission_id text
);


ALTER TABLE public.banking_export_event OWNER TO postgres;

--
-- Name: banking_export_event_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.banking_export_event_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.banking_export_event_id_seq OWNER TO postgres;

--
-- Name: banking_export_event_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.banking_export_event_id_seq OWNED BY public.banking_export_event.id;


--
-- Name: banking_import_event; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.banking_import_event (
    id integer NOT NULL,
    status text NOT NULL,
    bank_account_id integer,
    imported_iban text,
    imported_currency text,
    imported_owner text,
    total_credit double precision,
    total_debit double precision,
    transactions_count integer,
    imported_when timestamp without time zone NOT NULL,
    source_type text NOT NULL,
    is_manual boolean NOT NULL,
    filename text,
    file_content text,
    delegated_to text
);


ALTER TABLE public.banking_import_event OWNER TO postgres;

--
-- Name: banking_import_event_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.banking_import_event ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.banking_import_event_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: blink_export_process; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.blink_export_process (
    id integer NOT NULL,
    bank_account_id integer NOT NULL,
    process_type text NOT NULL,
    status text NOT NULL,
    error jsonb,
    created_at timestamp without time zone NOT NULL,
    last_modified_at timestamp without time zone
);


ALTER TABLE public.blink_export_process OWNER TO postgres;

--
-- Name: blink_export_process_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.blink_export_process_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.blink_export_process_id_seq OWNER TO postgres;

--
-- Name: blink_export_process_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.blink_export_process_id_seq OWNED BY public.blink_export_process.id;


--
-- Name: blink_export_process_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.blink_export_process_log (
    id integer NOT NULL,
    blink_export_process_id bigint NOT NULL,
    processed_target_id text NOT NULL,
    processed_payload jsonb NOT NULL,
    error jsonb,
    banking_export_event_id bigint,
    correlation_id character varying(255)
);


ALTER TABLE public.blink_export_process_log OWNER TO postgres;

--
-- Name: blink_export_process_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.blink_export_process_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.blink_export_process_log_id_seq OWNER TO postgres;

--
-- Name: blink_export_process_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.blink_export_process_log_id_seq OWNED BY public.blink_export_process_log.id;


--
-- Name: blink_import_process; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.blink_import_process (
    id integer NOT NULL,
    bank_account_id bigint NOT NULL,
    status text NOT NULL,
    error jsonb,
    created_at timestamp without time zone NOT NULL,
    last_modified_at timestamp without time zone
);


ALTER TABLE public.blink_import_process OWNER TO postgres;

--
-- Name: blink_import_process_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.blink_import_process_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.blink_import_process_id_seq OWNER TO postgres;

--
-- Name: blink_import_process_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.blink_import_process_id_seq OWNED BY public.blink_import_process.id;


--
-- Name: blink_import_process_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.blink_import_process_log (
    id integer NOT NULL,
    blink_import_process_id bigint NOT NULL,
    processed_target_id text NOT NULL,
    processed_payload jsonb NOT NULL,
    error jsonb,
    banking_import_event_id bigint,
    correlation_id character varying(255)
);


ALTER TABLE public.blink_import_process_log OWNER TO postgres;

--
-- Name: blink_import_process_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.blink_import_process_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.blink_import_process_log_id_seq OWNER TO postgres;

--
-- Name: blink_import_process_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.blink_import_process_log_id_seq OWNED BY public.blink_import_process_log.id;


--
-- Name: booking_to_settlement; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.booking_to_settlement (
    id integer NOT NULL,
    booking_id integer NOT NULL,
    settlement_id integer NOT NULL
);


ALTER TABLE public.booking_to_settlement OWNER TO postgres;

--
-- Name: booking_to_settlement_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.booking_to_settlement_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.booking_to_settlement_id_seq OWNER TO postgres;

--
-- Name: booking_to_settlement_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.booking_to_settlement_id_seq OWNED BY public.booking_to_settlement.id;


--
-- Name: br; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.br (
    id integer DEFAULT nextval('public.id'::regclass) NOT NULL,
    batchnumber text,
    description text,
    batch text,
    transdate date DEFAULT CURRENT_DATE,
    apprdate date,
    amount double precision,
    managerid integer,
    employee_id integer
);


ALTER TABLE public.br OWNER TO postgres;

--
-- Name: build; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.build (
    id integer DEFAULT nextval('public.id'::regclass) NOT NULL,
    reference text,
    transdate date,
    department_id integer,
    warehouse_id integer,
    employee_id integer
);


ALTER TABLE public.build OWNER TO postgres;

--
-- Name: business; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.business (
    id integer DEFAULT nextval('public.id'::regclass),
    description text,
    discount real
);


ALTER TABLE public.business OWNER TO postgres;

--
-- Name: cargo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cargo (
    id integer NOT NULL,
    trans_id integer NOT NULL,
    package text,
    netweight double precision,
    grossweight double precision,
    volume double precision
);


ALTER TABLE public.cargo OWNER TO postgres;

--
-- Name: chart; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.chart (
    id integer DEFAULT nextval('public.id'::regclass),
    accno text NOT NULL,
    description text,
    charttype character(1) DEFAULT 'A'::bpchar,
    category character(1),
    link text,
    gifi_accno text,
    contra boolean DEFAULT false,
    allow_gl boolean DEFAULT true,
    symbol_link character varying(128),
    parent_id integer
);


ALTER TABLE public.chart OWNER TO postgres;

--
-- Name: chat; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.chat (
    id integer NOT NULL,
    trans_id integer NOT NULL,
    message character varying(1024) NOT NULL,
    employee_id integer NOT NULL,
    creation_date timestamp without time zone NOT NULL
);


ALTER TABLE public.chat OWNER TO postgres;

--
-- Name: chat_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.chat_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.chat_id_seq OWNER TO postgres;

--
-- Name: chat_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.chat_id_seq OWNED BY public.chat.id;


--
-- Name: contactid; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.contactid
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.contactid OWNER TO postgres;

--
-- Name: contact; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.contact (
    id integer DEFAULT nextval('public.contactid'::regclass) NOT NULL,
    trans_id integer NOT NULL,
    salutation character varying(32),
    firstname character varying(32),
    lastname character varying(32),
    contacttitle character varying(32),
    occupation character varying(32),
    phone character varying(20),
    fax character varying(20),
    mobile character varying(20),
    email text,
    gender character(1) DEFAULT 'M'::bpchar,
    parent_id integer,
    typeofcontact character varying(20)
);


ALTER TABLE public.contact OWNER TO postgres;

--
-- Name: credits; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.credits (
    id integer NOT NULL,
    reference text,
    description text,
    transdate date,
    accno text,
    amount numeric(12,2)
);


ALTER TABLE public.credits OWNER TO postgres;

--
-- Name: credits_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.credits_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.credits_id_seq OWNER TO postgres;

--
-- Name: credits_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.credits_id_seq OWNED BY public.credits.id;


--
-- Name: curr; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.curr (
    rn integer,
    curr character(3) NOT NULL,
    "precision" smallint
);


ALTER TABLE public.curr OWNER TO postgres;

--
-- Name: customer; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customer (
    id integer DEFAULT nextval('public.id'::regclass) NOT NULL,
    name character varying(128),
    contact character varying(64),
    phone character varying(20),
    fax character varying(20),
    email text,
    notes text,
    terms smallint DEFAULT 0,
    taxincluded boolean DEFAULT false,
    customernumber character varying(32),
    cc text,
    bcc text,
    business_id integer,
    taxnumber character varying(32),
    sic_code character varying(6),
    discount real,
    creditlimit double precision DEFAULT 0,
    iban character varying(34),
    bic character varying(11),
    employee_id integer,
    language_code character varying(6),
    pricegroup_id integer,
    curr character(3),
    startdate date,
    enddate date,
    arap_accno_id integer,
    payment_accno_id integer,
    discount_accno_id integer,
    cashdiscount real,
    discountterms smallint,
    threshold double precision,
    paymentmethod_id integer,
    remittancevoucher boolean,
    dispatch_id integer,
    last_modified timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    income_accno_id integer,
    payment_clearing_accno_id integer,
    reminderstop boolean DEFAULT false
);


ALTER TABLE public.customer OWNER TO postgres;

--
-- Name: customercart; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customercart (
    cart_id character varying(32),
    customer_id integer,
    parts_id integer,
    qty double precision DEFAULT 0,
    price double precision DEFAULT 0,
    taxaccounts text
);


ALTER TABLE public.customercart OWNER TO postgres;

--
-- Name: customerloginid; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.customerloginid
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.customerloginid OWNER TO postgres;

--
-- Name: customerlogin; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customerlogin (
    id integer DEFAULT nextval('public.customerloginid'::regclass) NOT NULL,
    login character varying(100),
    passwd character(32),
    session character(32),
    session_exp character varying(20),
    customer_id integer
);


ALTER TABLE public.customerlogin OWNER TO postgres;

--
-- Name: customertax; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customertax (
    customer_id integer,
    chart_id integer
);


ALTER TABLE public.customertax OWNER TO postgres;

--
-- Name: debits; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.debits (
    id integer NOT NULL,
    reference text,
    description text,
    transdate date,
    accno text,
    amount numeric(12,2)
);


ALTER TABLE public.debits OWNER TO postgres;

--
-- Name: debits_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.debits_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.debits_id_seq OWNER TO postgres;

--
-- Name: debits_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.debits_id_seq OWNED BY public.debits.id;


--
-- Name: debitscredits; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.debitscredits (
    id integer NOT NULL,
    reference text,
    description text,
    transdate date,
    debit_accno text,
    credit_accno text,
    amount numeric(12,2)
);


ALTER TABLE public.debitscredits OWNER TO postgres;

--
-- Name: debitscredits_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.debitscredits_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.debitscredits_id_seq OWNER TO postgres;

--
-- Name: debitscredits_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.debitscredits_id_seq OWNED BY public.debitscredits.id;


--
-- Name: defaults; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.defaults (
    fldname text,
    fldvalue text
);


ALTER TABLE public.defaults OWNER TO postgres;

--
-- Name: department; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.department (
    id integer DEFAULT nextval('public.id'::regclass),
    description text,
    role character(1) DEFAULT 'P'::bpchar
);


ALTER TABLE public.department OWNER TO postgres;

--
-- Name: dispatch; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dispatch (
    id integer DEFAULT nextval('public.id'::regclass),
    description text
);


ALTER TABLE public.dispatch OWNER TO postgres;

--
-- Name: dpt_trans; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dpt_trans (
    trans_id integer,
    department_id integer
);


ALTER TABLE public.dpt_trans OWNER TO postgres;

--
-- Name: employee; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.employee (
    id integer DEFAULT nextval('public.id'::regclass),
    login text,
    name character varying(64),
    address1 character varying(64),
    address2 character varying(64),
    city character varying(64),
    state character varying(32),
    zipcode character varying(32),
    country character varying(32),
    workphone character varying(20),
    workfax character varying(20),
    workmobile character varying(20),
    homephone character varying(20),
    startdate date DEFAULT CURRENT_DATE,
    enddate date,
    notes text,
    role character varying(20),
    sales boolean DEFAULT false,
    email text,
    ssn character varying(20),
    iban character varying(34),
    bic character varying(11),
    managerid integer,
    employeenumber character varying(32),
    dob date,
    closedto date
);


ALTER TABLE public.employee OWNER TO postgres;

--
-- Name: exchangerate; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.exchangerate (
    curr character(3),
    transdate date,
    buy double precision,
    sell double precision
);


ALTER TABLE public.exchangerate OWNER TO postgres;

--
-- Name: exported_payment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.exported_payment (
    id integer NOT NULL,
    banking_export_event_id bigint NOT NULL,
    rma_payment_id integer,
    payload jsonb NOT NULL,
    export_instruction_id text NOT NULL
);


ALTER TABLE public.exported_payment OWNER TO postgres;

--
-- Name: exported_payment_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.exported_payment_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.exported_payment_id_seq OWNER TO postgres;

--
-- Name: exported_payment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.exported_payment_id_seq OWNED BY public.exported_payment.id;


--
-- Name: fifo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fifo (
    trans_id integer,
    transdate date,
    parts_id integer,
    qty double precision,
    costprice double precision,
    sellprice double precision,
    warehouse_id integer,
    invoice_id integer
);


ALTER TABLE public.fifo OWNER TO postgres;

--
-- Name: filtered; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.filtered (
    trans_id integer,
    entry_id integer DEFAULT 0,
    entry_id2 integer DEFAULT 0,
    debit double precision DEFAULT 0,
    credit double precision DEFAULT 0
);


ALTER TABLE public.filtered OWNER TO postgres;

--
-- Name: financial_year; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.financial_year (
    id integer NOT NULL,
    start_date date,
    end_date date,
    status public.financial_year_status_enum,
    yearend_id integer
);


ALTER TABLE public.financial_year OWNER TO postgres;

--
-- Name: financial_year_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.financial_year_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.financial_year_id_seq OWNER TO postgres;

--
-- Name: financial_year_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.financial_year_id_seq OWNED BY public.financial_year.id;


--
-- Name: gifi; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.gifi (
    accno text,
    description text
);


ALTER TABLE public.gifi OWNER TO postgres;

--
-- Name: gl; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.gl (
    id integer DEFAULT nextval('public.id'::regclass),
    reference text,
    description text,
    transdate date DEFAULT CURRENT_DATE,
    employee_id integer,
    notes text,
    department_id integer DEFAULT 0,
    approved boolean DEFAULT true,
    curr character(3),
    exchangerate double precision,
    ts timestamp without time zone DEFAULT now(),
    onhold boolean
);


ALTER TABLE public.gl OWNER TO postgres;

--
-- Name: gl_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.gl_log (
    id integer,
    reference text,
    description text,
    transdate date,
    employee_id integer,
    notes text,
    department_id integer,
    approved boolean,
    curr character(3),
    exchangerate double precision,
    ts timestamp without time zone,
    onhold boolean
);


ALTER TABLE public.gl_log OWNER TO postgres;

--
-- Name: gl_log_deleted; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.gl_log_deleted (
    id integer,
    reference text,
    description text,
    transdate date,
    employee_id integer,
    notes text,
    department_id integer,
    approved boolean,
    curr character(3),
    exchangerate double precision,
    ts timestamp without time zone,
    onhold boolean
);


ALTER TABLE public.gl_log_deleted OWNER TO postgres;

--
-- Name: imported_balance; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.imported_balance (
    id integer NOT NULL,
    banking_import_event_id integer NOT NULL,
    balance_type text NOT NULL,
    amount double precision NOT NULL,
    balance_currency text NOT NULL,
    credit_debit text NOT NULL,
    date date NOT NULL
);


ALTER TABLE public.imported_balance OWNER TO postgres;

--
-- Name: imported_balance_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.imported_balance ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.imported_balance_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: imported_transaction; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.imported_transaction (
    id integer NOT NULL,
    parent_imported_transaction_id integer,
    banking_import_event_id integer NOT NULL,
    amount double precision NOT NULL,
    currency text NOT NULL,
    credit_debit text NOT NULL,
    booking_date date NOT NULL,
    status text NOT NULL,
    reversal_indicator boolean,
    transaction_ref text,
    bank_domain_code text,
    bank_family_code text,
    bank_sub_family_code text,
    transaction_text text,
    origin_amount double precision,
    origin_currency character varying(3),
    exchange_rate double precision,
    related_party_name text,
    related_party_address jsonb,
    end_to_end_id text,
    purpose text,
    remittance_ref text,
    remittance_type text,
    hashcode integer NOT NULL,
    suppression text DEFAULT 'NONE'::text NOT NULL
);


ALTER TABLE public.imported_transaction OWNER TO postgres;

--
-- Name: imported_transaction_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.imported_transaction ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.imported_transaction_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: imported_transaction_to_booking; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.imported_transaction_to_booking (
    imported_transaction_id integer NOT NULL,
    booking_id integer NOT NULL,
    ledger_type character varying(2) NOT NULL,
    exchange_rate double precision
);


ALTER TABLE public.imported_transaction_to_booking OWNER TO postgres;

--
-- Name: inventoryid; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.inventoryid
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.inventoryid OWNER TO postgres;

--
-- Name: inventory; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.inventory (
    id integer DEFAULT nextval('public.inventoryid'::regclass),
    warehouse_id integer,
    parts_id integer,
    trans_id integer,
    orderitems_id integer,
    qty double precision,
    shippingdate date,
    employee_id integer,
    department_id integer,
    warehouse_id2 integer,
    serialnumber text,
    itemnotes text,
    cost double precision,
    linetype character(1) DEFAULT '0'::bpchar,
    description text,
    invoice_id integer,
    cogs double precision
);


ALTER TABLE public.inventory OWNER TO postgres;

--
-- Name: invoiceid; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.invoiceid
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.invoiceid OWNER TO postgres;

--
-- Name: invoice; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.invoice (
    id integer DEFAULT nextval('public.invoiceid'::regclass) NOT NULL,
    trans_id integer,
    parts_id integer,
    description text,
    qty double precision,
    allocated double precision,
    sellprice double precision,
    fxsellprice double precision,
    discount real,
    assemblyitem boolean DEFAULT false,
    unit character varying(5),
    project_id integer,
    deliverydate date,
    serialnumber text,
    itemnotes text,
    lineitemdetail boolean,
    ordernumber text,
    ponumber text,
    transdate date,
    lastcost double precision,
    warehouse_id integer,
    cogs double precision
);


ALTER TABLE public.invoice OWNER TO postgres;

--
-- Name: invoice_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.invoice_log (
    id integer,
    trans_id integer,
    parts_id integer,
    description text,
    qty double precision,
    allocated double precision,
    sellprice double precision,
    fxsellprice double precision,
    discount real,
    assemblyitem boolean,
    unit character varying(5),
    project_id integer,
    deliverydate date,
    serialnumber text,
    itemnotes text,
    lineitemdetail boolean,
    ordernumber text,
    ponumber text,
    transdate date,
    lastcost double precision,
    warehouse_id integer,
    cogs double precision,
    ts timestamp without time zone DEFAULT now()
);


ALTER TABLE public.invoice_log OWNER TO postgres;

--
-- Name: invoice_log_deleted; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.invoice_log_deleted (
    trans_id integer,
    chart_id integer,
    amount double precision,
    transdate date,
    source text,
    approved boolean,
    fx_transaction boolean,
    project_id integer,
    memo text,
    id integer,
    cleared date,
    vr_id integer,
    entry_id integer,
    tax text,
    taxamount double precision,
    tax_chart_id integer,
    ts timestamp without time zone DEFAULT now()
);


ALTER TABLE public.invoice_log_deleted OWNER TO postgres;

--
-- Name: invoicetax; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.invoicetax (
    trans_id integer,
    invoice_id integer,
    chart_id integer,
    taxamount double precision,
    amount double precision
);


ALTER TABLE public.invoicetax OWNER TO postgres;

--
-- Name: jcitemsid; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.jcitemsid
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.jcitemsid OWNER TO postgres;

--
-- Name: jcitems; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.jcitems (
    id integer DEFAULT nextval('public.jcitemsid'::regclass),
    project_id integer,
    parts_id integer,
    description text,
    qty double precision,
    allocated double precision,
    sellprice double precision,
    fxsellprice double precision,
    serialnumber text,
    checkedin timestamp with time zone,
    checkedout timestamp with time zone,
    employee_id integer,
    notes text
);


ALTER TABLE public.jcitems OWNER TO postgres;

--
-- Name: language; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.language (
    code character varying(6),
    description text
);


ALTER TABLE public.language OWNER TO postgres;

--
-- Name: lastused; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lastused (
    id integer NOT NULL,
    report character varying(40),
    cols text,
    login character varying(255)
);


ALTER TABLE public.lastused OWNER TO postgres;

--
-- Name: lastused_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.lastused_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.lastused_id_seq OWNER TO postgres;

--
-- Name: lastused_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.lastused_id_seq OWNED BY public.lastused.id;


--
-- Name: makemodel; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.makemodel (
    parts_id integer,
    make text,
    model text
);


ALTER TABLE public.makemodel OWNER TO postgres;

--
-- Name: oe; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.oe (
    id integer DEFAULT nextval('public.id'::regclass),
    ordnumber text,
    transdate date DEFAULT CURRENT_DATE,
    vendor_id integer,
    customer_id integer,
    amount double precision,
    netamount double precision,
    reqdate date,
    taxincluded boolean,
    shippingpoint text,
    notes text,
    curr character(3),
    employee_id integer,
    closed boolean DEFAULT false,
    quotation boolean DEFAULT false,
    quonumber text,
    intnotes text,
    department_id integer DEFAULT 0,
    shipvia text,
    language_code character varying(6),
    ponumber text,
    terms smallint DEFAULT 0,
    waybill text,
    warehouse_id integer,
    description text,
    aa_id integer,
    exchangerate double precision
);


ALTER TABLE public.oe OWNER TO postgres;

--
-- Name: orderitemsid; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.orderitemsid
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.orderitemsid OWNER TO postgres;

--
-- Name: orderitems; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.orderitems (
    id integer DEFAULT nextval('public.orderitemsid'::regclass),
    trans_id integer,
    parts_id integer,
    description text,
    qty double precision,
    sellprice double precision,
    discount real,
    unit character varying(5),
    project_id integer,
    reqdate date,
    ship double precision,
    serialnumber text,
    itemnotes text,
    lineitemdetail boolean,
    ordernumber text,
    ponumber text
);


ALTER TABLE public.orderitems OWNER TO postgres;

--
-- Name: parts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.parts (
    id integer DEFAULT nextval('public.id'::regclass),
    partnumber text,
    description text,
    unit character varying(5),
    listprice double precision,
    sellprice double precision,
    lastcost double precision,
    priceupdate date DEFAULT CURRENT_DATE,
    weight double precision,
    onhand double precision DEFAULT 0,
    notes text,
    makemodel boolean DEFAULT false,
    assembly boolean DEFAULT false,
    alternate boolean DEFAULT false,
    rop double precision,
    inventory_accno_id integer,
    income_accno_id integer,
    expense_accno_id integer,
    bin text,
    obsolete boolean DEFAULT false,
    bom boolean DEFAULT false,
    image text,
    drawing text,
    microfiche text,
    partsgroup_id integer,
    project_id integer,
    avgcost double precision,
    tariff_hscode text,
    countryorigin text,
    barcode text,
    toolnumber text
);


ALTER TABLE public.parts OWNER TO postgres;

--
-- Name: partsattr; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.partsattr (
    parts_id integer,
    hotnew character varying(3)
);


ALTER TABLE public.partsattr OWNER TO postgres;

--
-- Name: partscustomer; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.partscustomer (
    parts_id integer,
    customer_id integer,
    pricegroup_id integer,
    pricebreak double precision,
    sellprice double precision,
    validfrom date,
    validto date,
    curr character(3)
);


ALTER TABLE public.partscustomer OWNER TO postgres;

--
-- Name: partsgroup; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.partsgroup (
    id integer DEFAULT nextval('public.id'::regclass),
    partsgroup text,
    pos boolean DEFAULT true
);


ALTER TABLE public.partsgroup OWNER TO postgres;

--
-- Name: partstax; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.partstax (
    parts_id integer,
    chart_id integer
);


ALTER TABLE public.partstax OWNER TO postgres;

--
-- Name: partsvendor; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.partsvendor (
    vendor_id integer,
    parts_id integer,
    partnumber text,
    leadtime smallint,
    lastcost double precision,
    curr character(3)
);


ALTER TABLE public.partsvendor OWNER TO postgres;

--
-- Name: payment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payment (
    id integer NOT NULL,
    trans_id integer NOT NULL,
    exchangerate double precision DEFAULT 1,
    paymentmethod_id integer
);


ALTER TABLE public.payment OWNER TO postgres;

--
-- Name: paymentmethod; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.paymentmethod (
    id integer DEFAULT nextval('public.id'::regclass) NOT NULL,
    description text,
    fee double precision,
    rn integer
);


ALTER TABLE public.paymentmethod OWNER TO postgres;

--
-- Name: pricegroup; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pricegroup (
    id integer DEFAULT nextval('public.id'::regclass),
    pricegroup text
);


ALTER TABLE public.pricegroup OWNER TO postgres;

--
-- Name: project; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.project (
    id integer DEFAULT nextval('public.id'::regclass),
    projectnumber text,
    description text,
    startdate date,
    enddate date,
    parts_id integer,
    production double precision DEFAULT 0,
    completed double precision DEFAULT 0,
    customer_id integer
);


ALTER TABLE public.project OWNER TO postgres;

--
-- Name: recurring; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.recurring (
    id integer,
    reference text,
    startdate date,
    nextdate date,
    enddate date,
    repeat smallint,
    unit character varying(6),
    howmany integer,
    payment boolean DEFAULT false,
    description text
);


ALTER TABLE public.recurring OWNER TO postgres;

--
-- Name: recurringemail; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.recurringemail (
    id integer,
    formname text,
    format text,
    message text
);


ALTER TABLE public.recurringemail OWNER TO postgres;

--
-- Name: recurringprint; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.recurringprint (
    id integer,
    formname text,
    format text,
    printer text
);


ALTER TABLE public.recurringprint OWNER TO postgres;

--
-- Name: report; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.report (
    reportid integer DEFAULT nextval('public.id'::regclass) NOT NULL,
    reportcode text,
    reportdescription text,
    login text
);


ALTER TABLE public.report OWNER TO postgres;

--
-- Name: reportvars; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reportvars (
    reportid integer NOT NULL,
    reportvariable text,
    reportvalue text
);


ALTER TABLE public.reportvars OWNER TO postgres;

--
-- Name: search_irrelevant_words; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.search_irrelevant_words (
    id integer NOT NULL,
    search_target text NOT NULL,
    word text NOT NULL
);


ALTER TABLE public.search_irrelevant_words OWNER TO postgres;

--
-- Name: search_irrelevant_words_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.search_irrelevant_words_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.search_irrelevant_words_id_seq OWNER TO postgres;

--
-- Name: search_irrelevant_words_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.search_irrelevant_words_id_seq OWNED BY public.search_irrelevant_words.id;


--
-- Name: semaphore; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.semaphore (
    id integer,
    login text,
    module text,
    expires character varying(10)
);


ALTER TABLE public.semaphore OWNER TO postgres;

--
-- Name: shipto; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.shipto (
    trans_id integer,
    shiptoname character varying(64),
    shiptoaddress1 character varying(64),
    shiptoaddress2 character varying(64),
    shiptocity character varying(64),
    shiptostate character varying(32),
    shiptozipcode character varying(32),
    shiptocountry character varying(32),
    shiptocontact character varying(64),
    shiptophone character varying(20),
    shiptofax character varying(20),
    shiptoemail text
);


ALTER TABLE public.shipto OWNER TO postgres;

--
-- Name: sic; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sic (
    code character varying(6),
    sictype character(1),
    description text
);


ALTER TABLE public.sic OWNER TO postgres;

--
-- Name: status; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.status (
    trans_id integer,
    formname text,
    printed boolean DEFAULT false,
    emailed boolean DEFAULT false,
    spoolfile text
);


ALTER TABLE public.status OWNER TO postgres;

--
-- Name: tax; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tax (
    chart_id integer,
    rate double precision,
    taxnumber text,
    validto date,
    reversecharge_id integer,
    vatkey character varying(5),
    formdigit integer DEFAULT 0,
    validfrom date,
    id integer NOT NULL,
    inactive boolean DEFAULT false
);


ALTER TABLE public.tax OWNER TO postgres;

--
-- Name: tax_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tax_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tax_id_seq OWNER TO postgres;

--
-- Name: tax_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tax_id_seq OWNED BY public.tax.id;


--
-- Name: translation; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.translation (
    trans_id integer,
    language_code character varying(6),
    description text
);


ALTER TABLE public.translation OWNER TO postgres;

--
-- Name: trf; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.trf (
    id integer DEFAULT nextval('public.id'::regclass) NOT NULL,
    transdate date,
    trfnumber text,
    description text,
    notes text,
    department_id integer,
    from_warehouse_id integer,
    to_warehouse_id integer DEFAULT 0,
    employee_id integer DEFAULT 0,
    delivereddate date
);


ALTER TABLE public.trf OWNER TO postgres;

--
-- Name: vat_settlement; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.vat_settlement (
    id integer NOT NULL,
    vat_form_id integer,
    period_from date,
    period_to date,
    creation_date timestamp without time zone,
    data json,
    xml bytea,
    type public.settlement_type_enum,
    meldecenter_data json
);


ALTER TABLE public.vat_settlement OWNER TO postgres;

--
-- Name: vat_settlement_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.vat_settlement_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.vat_settlement_id_seq OWNER TO postgres;

--
-- Name: vat_settlement_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.vat_settlement_id_seq OWNED BY public.vat_settlement.id;


--
-- Name: vendor; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.vendor (
    id integer DEFAULT nextval('public.id'::regclass) NOT NULL,
    name character varying(128),
    contact character varying(64),
    phone character varying(20),
    fax character varying(20),
    email text,
    notes text,
    terms smallint DEFAULT 0,
    taxincluded boolean DEFAULT false,
    vendornumber character varying(32),
    cc text,
    bcc text,
    gifi_accno character varying(30),
    business_id integer,
    taxnumber character varying(32),
    sic_code character varying(6),
    discount real,
    creditlimit double precision DEFAULT 0,
    iban character varying(34),
    bic character varying(11),
    employee_id integer,
    language_code character varying(6),
    pricegroup_id integer,
    curr character(3),
    startdate date,
    enddate date,
    arap_accno_id integer,
    payment_accno_id integer,
    discount_accno_id integer,
    cashdiscount real,
    discountterms smallint,
    threshold double precision,
    paymentmethod_id integer,
    remittancevoucher boolean,
    dispatch_id integer,
    last_modified timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    expense_accno_id integer,
    early_payment_discount numeric(5,4),
    payment_clearing_accno_id integer,
    reminderstop boolean DEFAULT false
);


ALTER TABLE public.vendor OWNER TO postgres;

--
-- Name: vendortax; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.vendortax (
    vendor_id integer,
    chart_id integer
);


ALTER TABLE public.vendortax OWNER TO postgres;

--
-- Name: vr; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.vr (
    br_id integer,
    trans_id integer NOT NULL,
    id integer DEFAULT nextval('public.id'::regclass) NOT NULL,
    vouchernumber text
);


ALTER TABLE public.vr OWNER TO postgres;

--
-- Name: warehouse; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.warehouse (
    id integer DEFAULT nextval('public.id'::regclass),
    description text
);


ALTER TABLE public.warehouse OWNER TO postgres;

--
-- Name: xabschluss; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.xabschluss (
    id integer NOT NULL,
    xml text,
    data jsonb,
    status text DEFAULT 'NEW'::text
);


ALTER TABLE public.xabschluss OWNER TO postgres;

--
-- Name: TABLE xabschluss; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.xabschluss IS 'nagebootst door rma_create.pl (testset PyBalans)';


--
-- Name: xabschluss_history; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.xabschluss_history (
    id integer NOT NULL,
    xml text,
    data jsonb
);


ALTER TABLE public.xabschluss_history OWNER TO postgres;

--
-- Name: xabschluss_history_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.xabschluss_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.xabschluss_history_id_seq OWNER TO postgres;

--
-- Name: xabschluss_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.xabschluss_history_id_seq OWNED BY public.xabschluss_history.id;


--
-- Name: xabschluss_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.xabschluss_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.xabschluss_id_seq OWNER TO postgres;

--
-- Name: xabschluss_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.xabschluss_id_seq OWNED BY public.xabschluss.id;


--
-- Name: xcontrolling_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.xcontrolling_log (
    id integer NOT NULL,
    trans_id integer NOT NULL,
    controlling_key character varying(32) NOT NULL,
    checked boolean DEFAULT false,
    checked_timestamp timestamp without time zone,
    checked_hash character varying(64),
    checked_login_ref integer,
    checked_by_ibp_user_id bigint
);


ALTER TABLE public.xcontrolling_log OWNER TO postgres;

--
-- Name: xcontrolling_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.xcontrolling_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.xcontrolling_log_id_seq OWNER TO postgres;

--
-- Name: xcontrolling_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.xcontrolling_log_id_seq OWNED BY public.xcontrolling_log.id;


--
-- Name: yearend; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.yearend (
    trans_id integer,
    transdate date,
    id integer NOT NULL
);


ALTER TABLE public.yearend OWNER TO postgres;

--
-- Name: yearend_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.yearend_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.yearend_id_seq OWNER TO postgres;

--
-- Name: yearend_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.yearend_id_seq OWNED BY public.yearend.id;


--
-- Name: banking_export_event id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.banking_export_event ALTER COLUMN id SET DEFAULT nextval('public.banking_export_event_id_seq'::regclass);


--
-- Name: blink_export_process id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blink_export_process ALTER COLUMN id SET DEFAULT nextval('public.blink_export_process_id_seq'::regclass);


--
-- Name: blink_export_process_log id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blink_export_process_log ALTER COLUMN id SET DEFAULT nextval('public.blink_export_process_log_id_seq'::regclass);


--
-- Name: blink_import_process id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blink_import_process ALTER COLUMN id SET DEFAULT nextval('public.blink_import_process_id_seq'::regclass);


--
-- Name: blink_import_process_log id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blink_import_process_log ALTER COLUMN id SET DEFAULT nextval('public.blink_import_process_log_id_seq'::regclass);


--
-- Name: booking_to_settlement id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.booking_to_settlement ALTER COLUMN id SET DEFAULT nextval('public.booking_to_settlement_id_seq'::regclass);


--
-- Name: chat id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.chat ALTER COLUMN id SET DEFAULT nextval('public.chat_id_seq'::regclass);


--
-- Name: credits id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.credits ALTER COLUMN id SET DEFAULT nextval('public.credits_id_seq'::regclass);


--
-- Name: debits id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.debits ALTER COLUMN id SET DEFAULT nextval('public.debits_id_seq'::regclass);


--
-- Name: debitscredits id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.debitscredits ALTER COLUMN id SET DEFAULT nextval('public.debitscredits_id_seq'::regclass);


--
-- Name: exported_payment id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.exported_payment ALTER COLUMN id SET DEFAULT nextval('public.exported_payment_id_seq'::regclass);


--
-- Name: financial_year id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.financial_year ALTER COLUMN id SET DEFAULT nextval('public.financial_year_id_seq'::regclass);


--
-- Name: lastused id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lastused ALTER COLUMN id SET DEFAULT nextval('public.lastused_id_seq'::regclass);


--
-- Name: search_irrelevant_words id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.search_irrelevant_words ALTER COLUMN id SET DEFAULT nextval('public.search_irrelevant_words_id_seq'::regclass);


--
-- Name: tax id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tax ALTER COLUMN id SET DEFAULT nextval('public.tax_id_seq'::regclass);


--
-- Name: vat_settlement id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vat_settlement ALTER COLUMN id SET DEFAULT nextval('public.vat_settlement_id_seq'::regclass);


--
-- Name: xabschluss id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.xabschluss ALTER COLUMN id SET DEFAULT nextval('public.xabschluss_id_seq'::regclass);


--
-- Name: xabschluss_history id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.xabschluss_history ALTER COLUMN id SET DEFAULT nextval('public.xabschluss_history_id_seq'::regclass);


--
-- Name: xcontrolling_log id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.xcontrolling_log ALTER COLUMN id SET DEFAULT nextval('public.xcontrolling_log_id_seq'::regclass);


--
-- Name: yearend id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.yearend ALTER COLUMN id SET DEFAULT nextval('public.yearend_id_seq'::regclass);


--
-- Data for Name: acc_trans; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.acc_trans (trans_id, chart_id, amount, transdate, source, approved, fx_transaction, project_id, memo, id, cleared, vr_id, entry_id, tax, taxamount, tax_chart_id, lineamount, imported_transaction_id) FROM stdin;
10177	10101	-263.76	2025-02-20	\N	t	f	\N	\N	14	\N	\N	36	\N	\N	\N	0.00	\N
10177	10015	285.12	2025-02-20	\N	t	f	\N	\N	\N	\N	\N	37	\N	\N	\N	0.00	\N
10177	10152	-21.36	2025-02-20	\N	t	f	\N	\N	\N	\N	\N	38	\N	\N	\N	0.00	\N
10174	10035	2400	2025-02-10	\N	t	f	\N	\N	5	\N	\N	8	\N	\N	\N	0.00	\N
10174	10101	1600	2025-02-10	\N	t	f	\N	\N	2	\N	\N	9	\N	\N	\N	0.00	\N
10174	10035	1240	2025-02-10	\N	t	f	\N	\N	9	\N	\N	10	\N	\N	\N	0.00	\N
10174	10101	800	2025-02-10	\N	t	f	\N	\N	2	\N	\N	11	\N	\N	\N	0.00	\N
10174	10043	450	2025-02-10	\N	t	f	\N	\N	6	\N	\N	12	\N	\N	\N	0.00	\N
10174	10101	15	2025-02-10	\N	t	f	\N	\N	3	\N	\N	13	\N	\N	\N	0.00	\N
10174	10055	-15	2025-02-10	\N	t	f	\N	\N	3	\N	\N	14	\N	\N	\N	0.00	\N
10174	10054	-800	2025-02-10	\N	t	f	\N	\N	2	\N	\N	15	\N	\N	\N	0.00	\N
10174	10054	-1600	2025-02-10	\N	t	f	\N	\N	2	\N	\N	16	\N	\N	\N	0.00	\N
10174	10150	-4421.29	2025-02-10	\N	t	f	\N	\N	\N	\N	\N	17	\N	\N	\N	0.00	\N
10174	10152	331.29	2025-02-10	\N	t	f	\N	\N	\N	\N	\N	19	\N	\N	\N	0.00	\N
10174	10150	4421.29	2025-03-10	\N	t	f	\N	\N	\N	\N	\N	39	\N	\N	\N	0.00	\N
10174	10004	-4421.29	2025-03-10	KA 0310	t	f	\N	Zahlung	1	\N	\N	40	\N	\N	\N	0.00	\N
10176	10036	240	2025-03-05	\N	t	f	\N	\N	12	\N	\N	29	\N	\N	\N	0.00	\N
10176	10043	225	2025-03-05	\N	t	f	\N	\N	13	\N	\N	30	\N	\N	\N	0.00	\N
10176	10101	140	2025-03-05	\N	t	f	\N	\N	4	\N	\N	31	\N	\N	\N	0.00	\N
10176	10055	-140	2025-03-05	\N	t	f	\N	\N	4	\N	\N	32	\N	\N	\N	0.00	\N
10176	10150	-489.47	2025-03-05	\N	t	f	\N	\N	\N	\N	\N	33	\N	\N	\N	0.00	\N
10176	10152	18.23	2025-03-05	\N	t	f	\N	\N	\N	\N	\N	34	\N	\N	\N	0.00	\N
10176	10153	6.24	2025-03-05	\N	t	f	\N	\N	\N	\N	\N	35	\N	\N	\N	0.00	\N
10176	10150	200	2025-03-10	\N	t	f	\N	\N	\N	\N	\N	41	\N	\N	\N	0.00	\N
10176	10004	-200	2025-03-10	KA 0310	t	f	\N	Zahlung	1	\N	\N	42	\N	\N	\N	0.00	\N
10175	10035	1199.13	2025-02-10	\N	t	f	\N	\N	11	\N	\N	20	\N	\N	\N	0.00	\N
10175	10101	800	2025-02-10	\N	t	f	\N	\N	2	\N	\N	21	\N	\N	\N	0.00	\N
10175	10036	199.86	2025-02-10	\N	t	f	\N	\N	10	\N	\N	22	\N	\N	\N	0.00	\N
10175	10101	75	2025-02-10	\N	t	f	\N	\N	3	\N	\N	23	\N	\N	\N	0.00	\N
10175	10055	-75	2025-02-10	\N	t	f	\N	\N	3	\N	\N	24	\N	\N	\N	0.00	\N
10175	10054	-800	2025-02-10	\N	t	f	\N	\N	2	\N	\N	25	\N	\N	\N	0.00	\N
10175	10150	-1512.31	2025-02-10	\N	t	f	\N	\N	\N	\N	\N	26	\N	\N	\N	0.00	\N
10175	10152	113.32	2025-02-10	\N	t	f	\N	\N	\N	\N	\N	28	\N	\N	\N	0.00	\N
10175	10150	1512.31	2025-03-05	\N	t	f	\N	\N	\N	\N	\N	43	\N	\N	\N	0.00	\N
10175	10154	-1617.44	2025-03-05	EUR-1	t	f	\N		1	\N	\N	44	\N	\N	\N	0.00	\N
10175	10154	113.22	2025-03-05	EUR-1	t	t	\N	\N	\N	\N	\N	45	\N	\N	\N	0.00	\N
10175	10122	-8.09	2025-03-05	\N	t	t	\N	\N	\N	\N	\N	46	\N	\N	\N	0.00	\N
10169	10101	-8000	2025-01-15	\N	t	f	\N	\N	2	\N	\N	2	\N	\N	\N	0.00	\N
10169	10101	-750	2025-01-15	\N	t	f	\N	\N	3	\N	\N	3	\N	\N	\N	0.00	\N
10169	10101	-700	2025-01-15	\N	t	f	\N	\N	4	\N	\N	4	\N	\N	\N	0.00	\N
10169	10015	10176.95	2025-01-15	\N	t	f	\N	\N	\N	\N	\N	5	\N	\N	\N	0.00	\N
10169	10152	-708.75	2025-01-15	\N	t	f	\N	\N	\N	\N	\N	6	\N	\N	\N	0.00	\N
10169	10153	-18.2	2025-01-15	\N	t	f	\N	\N	\N	\N	\N	7	\N	\N	\N	0.00	\N
10169	10015	-10176.95	2025-02-14	\N	t	f	\N	\N	\N	\N	\N	47	\N	\N	\N	0.00	\N
10169	10004	10176.95	2025-02-14	ZA 0214	t	f	\N		1	\N	\N	48	\N	\N	\N	0.00	\N
10178	10077	-500	2025-03-31		t	f	\N	Reparatur	\N	\N	\N	49		0	0	0.00	\N
10178	10004	500	2025-03-31		t	f	\N		\N	\N	\N	50		0	0	0.00	\N
10179	10035	-4839.13	2025-12-31	JA-2025	t	f	\N	\N	\N	\N	\N	51	\N	\N	\N	0.00	\N
10179	10043	-675	2025-12-31	JA-2025	t	f	\N	\N	\N	\N	\N	52	\N	\N	\N	0.00	\N
10179	10036	-439.86	2025-12-31	JA-2025	t	f	\N	\N	\N	\N	\N	53	\N	\N	\N	0.00	\N
10179	10054	3200	2025-12-31	JA-2025	t	f	\N	\N	\N	\N	\N	54	\N	\N	\N	0.00	\N
10179	10077	500	2025-12-31	JA-2025	t	f	\N	\N	\N	\N	\N	55	\N	\N	\N	0.00	\N
10179	10122	8.09	2025-12-31	JA-2025	t	f	\N	\N	\N	\N	\N	56	\N	\N	\N	0.00	\N
10179	10055	230	2025-12-31	JA-2025	t	f	\N	\N	\N	\N	\N	57	\N	\N	\N	0.00	\N
10179	10031	2015.9	2025-12-31	JA-2025	t	f	\N	\N	\N	\N	\N	58	\N	\N	\N	0.00	\N
10180	10035	1190.16	2026-01-15	\N	t	f	\N	\N	15	\N	\N	59	\N	\N	\N	0.00	\N
10180	10101	800	2026-01-15	\N	t	f	\N	\N	2	\N	\N	60	\N	\N	\N	0.00	\N
10180	10054	-800	2026-01-15	\N	t	f	\N	\N	2	\N	\N	61	\N	\N	\N	0.00	\N
10180	10150	-1286.56	2026-01-15	\N	t	f	\N	\N	\N	\N	\N	62	\N	\N	\N	0.00	\N
10180	10152	96.4	2026-01-15	\N	t	f	\N	\N	\N	\N	\N	63	\N	\N	\N	0.00	\N
\.


--
-- Data for Name: acc_trans_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.acc_trans_log (trans_id, chart_id, amount, transdate, source, approved, fx_transaction, project_id, memo, id, cleared, vr_id, entry_id, tax, taxamount, tax_chart_id, ts, lineamount) FROM stdin;
\.


--
-- Data for Name: acc_trans_log_deleted; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.acc_trans_log_deleted (trans_id, chart_id, amount, transdate, source, approved, fx_transaction, project_id, memo, id, cleared, vr_id, entry_id, tax, taxamount, tax_chart_id, ts, lineamount) FROM stdin;
\.


--
-- Data for Name: address; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.address (id, trans_id, address1, address2, city, state, zipcode, country, post_office, is_migrated) FROM stdin;
2	10004	Paradeplatz 8		Zürich		8001	CH	\N	t
3	10158	Bahnhofstrasse 10		Zürich		8001	CH		t
4	10159	Rue du Lac 5		Genève		1201	CH		t
5	10160	Industriestrasse 3		Basel		4051	CH		t
6	10161	Hauptstrasse 7		München		80331	DE		t
\.


--
-- Data for Name: ap; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ap (id, invnumber, transdate, vendor_id, taxincluded, amount, netamount, paid, datepaid, duedate, invoice, ordnumber, curr, notes, employee_id, till, quonumber, intnotes, department_id, shipvia, language_code, ponumber, shippingpoint, terms, approved, cashdiscount, discountterms, waybill, warehouse_id, description, onhold, exchangerate, dcn, bank_id, paymentmethod_id, fxamount, fxpaid, linetax, ts) FROM stdin;
10177	ES-889	2025-02-20	10161	f	285.12	263.76	0	\N	2025-03-06	t		EUR		0	\N			10157		\N			14	t	0	0		10156		f	0.942		10139	0	302.68	0	f	2026-10-16 15:23:35.594974
10169	R-5001	2025-01-15	10160	f	10176.95	9450	10176.95	2025-02-14	2025-02-14	t	P-1001	CHF		0	\N			10157		\N			30	t	0	0		10155		f	1		10004	0	10176.95	10176.95	f	2026-10-16 15:23:24.652783
\.


--
-- Data for Name: ap_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ap_log (id, invnumber, transdate, vendor_id, taxincluded, amount, netamount, paid, datepaid, duedate, invoice, ordnumber, curr, notes, employee_id, till, quonumber, intnotes, department_id, shipvia, language_code, ponumber, shippingpoint, terms, approved, cashdiscount, discountterms, waybill, warehouse_id, description, onhold, exchangerate, dcn, bank_id, paymentmethod_id, fxamount, fxpaid, linetax, ts) FROM stdin;
\.


--
-- Data for Name: ap_log_deleted; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ap_log_deleted (id, invnumber, transdate, vendor_id, taxincluded, amount, netamount, paid, datepaid, duedate, invoice, ordnumber, curr, notes, employee_id, till, quonumber, intnotes, department_id, shipvia, language_code, ponumber, shippingpoint, terms, approved, cashdiscount, discountterms, waybill, warehouse_id, description, onhold, exchangerate, dcn, bank_id, paymentmethod_id, fxamount, fxpaid, linetax, ts) FROM stdin;
\.


--
-- Data for Name: ar; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ar (id, invnumber, transdate, customer_id, taxincluded, amount, netamount, paid, datepaid, duedate, invoice, shippingpoint, terms, notes, curr, ordnumber, employee_id, till, quonumber, intnotes, department_id, shipvia, language_code, ponumber, approved, cashdiscount, discountterms, waybill, warehouse_id, description, onhold, exchangerate, dcn, bank_id, paymentmethod_id, fxamount, fxpaid, linetax, ts) FROM stdin;
10174	RE-2025-001	2025-02-10	10158	f	4421.29	4090	4421.29	2025-03-10	2025-03-12	t		30		CHF	S-1001	0	\N			10157	Post	\N	PO-MA-77	t	0	0		10155		f	1	\N	10004	0	4421.29	4421.29	f	2026-10-16 15:23:30.454311
10176	RE-2025-003	2025-03-05	10158	f	489.47	465	200	2025-03-10	2025-04-04	t		30		CHF		0	\N			10157		\N		t	0	0		10155		f	1	\N	10004	0	489.47	200	f	2026-10-16 15:23:34.031909
10175	RE-2025-002	2025-02-10	10159	f	1512.31	1398.99	1512.31	2025-03-05	2025-02-20	t		10		EUR		0	\N			10157		\N		t	0	0		10156		f	0.935	\N	10154	0	1617.45	1617.44	f	2026-10-16 15:23:32.510315
10180	RE-2026-001	2026-01-15	10159	f	1286.56	1190.16	0	\N	2026-01-25	t		10		EUR		0	\N			10157		\N		t	0	0		10156		f	0.928	\N	10139	0	1386.38	0	f	2026-10-16 15:23:40.947164
\.


--
-- Data for Name: ar_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ar_log (id, invnumber, transdate, customer_id, taxincluded, amount, netamount, paid, datepaid, duedate, invoice, shippingpoint, terms, notes, curr, ordnumber, employee_id, till, quonumber, intnotes, department_id, shipvia, language_code, ponumber, approved, cashdiscount, discountterms, waybill, warehouse_id, description, onhold, exchangerate, dcn, bank_id, paymentmethod_id, fxamount, fxpaid, linetax, ts) FROM stdin;
\.


--
-- Data for Name: ar_log_deleted; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ar_log_deleted (id, invnumber, transdate, customer_id, taxincluded, amount, netamount, paid, datepaid, duedate, invoice, shippingpoint, terms, notes, curr, ordnumber, employee_id, till, quonumber, intnotes, department_id, shipvia, language_code, ponumber, approved, cashdiscount, discountterms, waybill, warehouse_id, description, onhold, exchangerate, dcn, bank_id, paymentmethod_id, fxamount, fxpaid, linetax, ts) FROM stdin;
\.


--
-- Data for Name: assembly; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.assembly (id, parts_id, qty, bom, adj, aid) FROM stdin;
2	10163	1	f	t	10167
3	10164	1	f	t	10167
\.


--
-- Data for Name: audittrail; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.audittrail (trans_id, tablename, reference, formname, action, transdate, employee_id) FROM stdin;
\.


--
-- Data for Name: bank; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.bank (id, name, iban, bic, address_id, dcn, rvc, membernumber, qriban, strdbkginf, invdescriptionqr) FROM stdin;
10004	Credit Suisse	CH9300762011623852957	CRESCHZZ80A	2			4711	CH4431999123000889012		
\.


--
-- Data for Name: bank_account; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.bank_account (id, bic, iban, account, bank, branch, country, country_iso, city, state, zip, address, description, chart_id, inactive, currency, blink_permission_id, blink_account_id) FROM stdin;
\.


--
-- Data for Name: banking_export_event; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.banking_export_event (id, status, bank_account_id, source_type, exported_when, is_manual, export_message_id, export_submission_id) FROM stdin;
\.


--
-- Data for Name: banking_import_event; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.banking_import_event (id, status, bank_account_id, imported_iban, imported_currency, imported_owner, total_credit, total_debit, transactions_count, imported_when, source_type, is_manual, filename, file_content, delegated_to) FROM stdin;
\.


--
-- Data for Name: blink_export_process; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.blink_export_process (id, bank_account_id, process_type, status, error, created_at, last_modified_at) FROM stdin;
\.


--
-- Data for Name: blink_export_process_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.blink_export_process_log (id, blink_export_process_id, processed_target_id, processed_payload, error, banking_export_event_id, correlation_id) FROM stdin;
\.


--
-- Data for Name: blink_import_process; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.blink_import_process (id, bank_account_id, status, error, created_at, last_modified_at) FROM stdin;
\.


--
-- Data for Name: blink_import_process_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.blink_import_process_log (id, blink_import_process_id, processed_target_id, processed_payload, error, banking_import_event_id, correlation_id) FROM stdin;
\.


--
-- Data for Name: booking_to_settlement; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.booking_to_settlement (id, booking_id, settlement_id) FROM stdin;
\.


--
-- Data for Name: br; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.br (id, batchnumber, description, batch, transdate, apprdate, amount, managerid, employee_id) FROM stdin;
\.


--
-- Data for Name: build; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.build (id, reference, transdate, department_id, warehouse_id, employee_id) FROM stdin;
10171	Build 1	2025-01-22	10157	10155	0
\.


--
-- Data for Name: business; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.business (id, description, discount) FROM stdin;
\.


--
-- Data for Name: cargo; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cargo (id, trans_id, package, netweight, grossweight, volume) FROM stdin;
5	10168		0	20	0
6	10168		0	5	0
2	10169		0	20	0
3	10169		0	5	0
11	10172		0	8	0
13	10172		0	2.1	0
14	10173		0	8	0
5	10174		0	8	0
9	10174		0	2.1	0
10	10175		0.5	0.1	0
11	10175		2	2	0
14	10177		2	0.1	0
15	10180		2	2	0
\.


--
-- Data for Name: chart; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.chart (id, accno, description, charttype, category, link, gifi_accno, contra, allow_gl, symbol_link, parent_id) FROM stdin;
10001	10000	AKTIVEN	H	A		1	f	t	\N	\N
10002	11000	UMLAUFSVERMÖGEN	H	A		10000	f	t	\N	\N
10003	11100	Flüssige Mittel	H	A		11000	f	t	\N	\N
10004	11102	Bank CS Kt. 177929-11	A	A	AR_paid:AP_paid	11100	f	t	\N	10003
10005	11110	Forderungen	H	A		11000	f	t	\N	\N
10006	11120	Vorräte und angefangene Arbeiten	H	A		11000	f	t	\N	\N
10007	11128	Angefangene Arbeiten	A	A		11120	f	t	\N	10006
10008	11130	Aktive Rechnungsabgrenzung	A	A		11000	f	t	\N	10006
10009	14000	ANLAGEVERMÖGEN	H	A		10000	f	t	\N	\N
10010	18000	AKTIVIERTER AUFWAND UND AKTIVE BERICHTIGUNGSPOSTEN	H	A		10000	f	t	\N	\N
10011	18182	Entwicklungsaufwand	A	A		18000	f	t	\N	10010
10012	20000	PASSIVEN	H	L		2	f	t	\N	\N
10013	21000	FREMDKAPITAL KURZFRISTIG	H	L		20000	f	t	\N	\N
10014	21200	Kurzfristige Verbindlichkeiten aus Lieferungen und Leistungen	H	L		21000	f	t	\N	\N
10015	21201	Lieferanten	A	L	AP	21200	f	t	\N	10014
10016	21202	Personalaufwand	A	L	AP	21200	f	t	\N	10014
10017	21203	Sozialversicherungen	A	L	AP	21200	f	t	\N	10014
10018	21205	Leasing	A	L	AP	21200	f	t	\N	10014
10019	21210	Kurzfristige Finanzverbindlichkeiten	H	L		21000	f	t	\N	\N
10020	21220	Andere kurzfristige Verbindlichkeiten	H	L		21000	f	t	\N	\N
10021	21222	MWST (3,6)	A	L	AR_tax:AP_tax:IC_taxpart:IC_taxservice	21220	f	t	\N	10020
10022	21229	Gewinnausschüttung	A	L		21220	f	t	\N	10020
10023	21230	Passive Rechnungsabgrenzung, kurzfristige Rückstellungen	H	L		21000	f	t	\N	\N
10024	21235	Rückstellungen	A	L		21230	f	t	\N	10023
10025	24000	FREMDKAPITAL LANGFRISTIG	H	L		20000	f	t	\N	\N
10026	24256	Gesellschafter	A	L		24000	f	t	\N	10025
10027	28000	EIGENKAPITAL	H	Q		20000	f	t	\N	\N
10028	28280	Stammkapital	A	Q		28000	f	t	\N	10027
10029	28290	Reserven, Bilanzgewinn	H	Q		28000	f	t	\N	\N
10030	28291	Reserven	A	Q		28290	f	t	\N	10029
10031	28295	Gewinnvortrag	A	Q		28290	f	t	\N	10029
10032	28296	Jahresgewinn	A	Q		28290	f	t	\N	10029
10034	31000	PRODUKTIONSERTRAG	H	I		30000	f	t	\N	\N
10033	30000	BETRIEBSERTRAG AUS LIEFERUNGEN UND LEISTUNGEN	H	I		30000	f	t	\N	\N
10035	31001	Computer	A	I	AR_amount:IC_sale	31000	f	t	\N	10034
10036	31005	Übrige Produkte	A	I	AR_amount:IC_sale	31000	f	t	\N	10034
10037	32000	HANDELSERTRAG	H	I		30000	f	t	\N	\N
10038	32001	Hardware	A	I	AR_amount:IC_sale	32000	f	t	\N	10037
10039	32002	Software OSS	A	I	AR_amount:IC_sale	32000	f	t	\N	10037
10040	32003	Software kommerz.	A	I	AR_amount:IC_sale	32000	f	t	\N	10037
10041	32005	Übrige	A	I	AR_amount:IC_sale	32000	f	t	\N	10037
10042	34000	DIENSTLEISTUNGSERTRAG	H	I		30000	f	t	\N	\N
10043	34001	Beratung	A	I	AR_amount:IC_income	34000	f	t	\N	10042
10044	34002	Installation	A	I	AR_amount:IC_income	34000	f	t	\N	10042
10045	36000	ÜBRIGER ERTRAG	H	I		30000	f	t	\N	\N
10046	37000	EIGENLEISTUNGEN UND EIGENVERBRAUCH	H	I		30000	f	t	\N	\N
10047	37001	Eigenleistungen	A	I		37000	f	t	\N	10046
10048	37002	Eigenverbrauch	A	I		37000	f	t	\N	10046
10049	38000	BESTANDESÄNDERUNGEN ANGEFANGENE UND FERTIGGESTELLTE ARBEITUNG AUS PRODUKTION UND DIENSTLEISTUNG	H	I		30000	f	t	\N	\N
10050	38001	Bestandesänderungen	A	I		38000	f	t	\N	10049
10051	39000	ERTRAGSMINDERUNGEN AUS PRODUKTIONS-, HANDELS- UND DIENSTLEISTUNGSERTRÄGEN	H	I		30000	f	t	\N	\N
10052	40000	AUFWAND FÜR MATERIAL, WAREN UND DIENSTLEISTUNGEN	H	E		40000	f	t	\N	\N
10053	41000	MATERIALAUFWAND	H	E		40000	f	t	\N	\N
10054	41001	Computer	A	E	AP_amount:IC_cogs	41000	f	t	\N	10053
10055	41005	Übrige Produkte	A	E	AP_amount:IC_cogs	41000	f	t	\N	10053
10056	42000	HANDELSWARENAUFWAND	H	E		40000	f	t	\N	\N
10057	42001	Hardware	A	E	AP_amount:IC_cogs	42000	f	t	\N	10056
10058	42002	Software OSS	A	I	AP_amount:IC_cogs	32000	f	t	\N	10056
10059	42003	Software kommerz.	A	I	AP_amount:IC_cogs	42000	f	t	\N	10056
10060	42005	Übrige	A	E	AP_amount:IC_cogs	42000	f	t	\N	10056
10061	44000	AUFWAND FÜR DRITTLEISTUNGEN	H	E		40000	f	t	\N	\N
10062	46000	ÜBRIGER AUFWAND	H	E		40000	f	t	\N	\N
10063	47000	DIREKTE EINKAUFSSPESEN	H	E		40000	f	t	\N	\N
10064	47001	Einkaufsspesen	A	E	AP_amount:IC_expense	47000	f	t	\N	10063
10065	48000	BESTANDESVERÄNDERUNGEN, MATERIAL- UND WARENVERLUSTE	H	E		40000	f	t	\N	\N
10066	48001	Bestandesänderungen	A	E		48000	f	t	\N	10065
10067	49000	AUFWANDMINDERUNGEN	H	E		40000	f	t	\N	\N
10068	49005	Aufwandminderungen	A	E	AP_amount:IC_expense	49000	f	t	\N	10067
10069	50000	PERSONALAUFWAND	H	E		50000	f	t	\N	\N
10070	57000	SOZIALVERSICHERUNGSAUFWAND	H	E		50000	f	t	\N	\N
10071	58000	ÜBRIGER PERSONALAUFWAND	H	A		58000	f	t	\N	\N
10072	58005	Sonstiger Personalaufwand	A	E		58000	f	t	\N	10071
10073	59000	ARBEITSLEISTUNGEN DRITTER	H	E		50000	f	t	\N	\N
10074	60000	SONSTIGER BETRIEBSAUFWAND	H	E		60000	f	t	\N	\N
10075	61000	RAUMAUFWAND	H	E		60000	f	t	\N	\N
10076	61900	UNTERHALT, REPARATUREN, ERSATZ, LEASINGAUFWAND MOBILE SACHANLAGEN	H	E		60000	f	t	\N	\N
10077	61901	Unterhalt	A	E	AP_amount	61900	f	t	\N	10076
10078	62000	FAHRZEUG- UND TRANSPORTAUFWAND	H	E		60000	f	t	\N	\N
10079	62002	Transportaufwand	A	E	AP_amount	62000	f	t	\N	10078
10080	63000	SACHVERSICHERUNGEN, ABGABEN, GEBÜHREN, BEWILLIGUNGEN	H	E		60000	f	t	\N	\N
10081	65000	VERWALTUNGS- UND INFORMATIKAUFWAND	H	E		60000	f	t	\N	\N
10082	66000	WERBEAUFWAND	H	E		60000	f	t	\N	\N
10083	67000	ÜBRIGER BETRIEBSAUFWAND	H	E		60000	f	t	\N	\N
10084	67001	Übriger Betriebsaufwand	A	E		67000	f	t	\N	10083
10085	68000	FINANZERFOLG	H	E		60000	f	t	\N	\N
10086	68001	Finanzaufwand	A	E		68000	f	t	\N	10085
10087	68002	Bankspesen	A	E		68000	f	t	\N	10085
10088	68005	Finanzertrag	A	E		68000	f	t	\N	10085
10089	69000	ABSCHREIBUNGEN	H	E		60000	f	t	\N	\N
10090	69001	Abschreibungen	A	E		69000	f	t	\N	10089
10091	80000	AUSSERORDENTLICHER UND BETRIEBSFREMDER ERFOLG, STEUERN	H	I		80000	f	t	\N	\N
10092	80001	Ausserordentlicher Ertrag	A	I		80000	f	t	\N	10091
10093	80002	Ausserordentlicher Aufwand	A	I		80000	f	t	\N	10091
10094	89000	STEUERAUFWAND	H	E		80000	f	t	\N	\N
10095	89001	Steuern	A	E		80000	f	t	\N	10094
10096	90000	ABSCHLUSS	H	A		90000	f	t	\N	\N
10097	91000	ERFOLGSRECHNUNG	H	I		91000	f	t	\N	\N
10098	92000	BILANZ	H	A		92000	f	t	\N	\N
10099	93000	GEWINNVERWENDUNG	H	A		93000	f	t	\N	\N
10100	99000	SAMMEL- UND FEHLBUCHUNGEN	H	A		99000	f	t	\N	\N
10101	11121	Warenvorräte	A	A	IC	11120	f	t	\N	10006
10102	44001	Aufwand für Drittleistungen	A	E	AP_amount:IC_expense	44000	f	t	\N	10061
10103	63001	Betriebsversicherungen	A	E	AP_amount:IC_expense	63000	f	t	\N	10080
10104	57004	Unfallversicherung	A	E	AP_amount:IC_expense	57000	f	t	\N	10070
10105	57005	Krankentaggeldversicherung	A	E	AP_amount:IC_expense	57000	f	t	\N	10070
10106	57003	Berufliche Vorsorge	A	E	AP_amount:IC_expense	57000	f	t	\N	10070
10107	57002	FAK	A	E	AP_amount:IC_income:IC_expense	57000	f	t	\N	10070
10108	65009	Übriger Verwaltungsaufwand	A	E	AP_amount:IC_expense	65000	f	t	\N	10081
10109	65003	Porti	A	E	AP_amount:IC_expense	65000	f	t	\N	10081
10110	65002	Telekomm	A	E	AP_amount:IC_expense	65000	f	t	\N	10081
10111	65001	Büromaterial	A	E	AP_amount:IC_expense	65000	f	t	\N	10081
10112	18181	Gründungsaufwand	A	A	IC_expense	18000	f	t	\N	10010
10113	50001	Löhne und Gehälter	A	E	IC_expense	50000	f	t	\N	10069
10114	50002	Erfolgsbeteiligungen	A	E	IC_expense	50000	f	t	\N	10069
10115	21216	Gesellschafter	A	L	AP	21210	f	t	\N	10019
10116	62001	Fahrzeugaufwand	A	E	AP_amount:IC_expense	62000	f	t	\N	10078
10117	58003	Spesen	A	E	IC_expense	58000	f	t	\N	10071
10118	65004	Fachliteratur	A	E	AP_amount:IC_expense	65000	f	t	\N	10081
10119	39001	Skonti	A	I	IC_sale:IC_cogs:IC_income:IC_expense	39000	f	t	\N	10051
10120	39002	Rabatte, Preisnachlässe	A	I	IC_sale:IC_cogs:IC_income:IC_expense	39000	f	t	\N	10051
10121	36005	Kursgewinn	A	I	IC_sale:IC_cogs:IC_income	39000	f	t	\N	10045
10122	39006	Kursverlust	A	E	IC_sale:IC_cogs:IC_expense	39000	f	t	\N	10051
10123	39005	Verluste aus Forderungen	A	E	IC_sale:IC_cogs:IC_expense	39000	f	t	\N	10051
10124	14151	Mobiliar und Einrichtungen	A	A	IC	14150	f	t	\N	10009
10125	14152	Büromaschinen, EDV	A	A	IC	14150	f	t	\N	10009
10126	11119	Verrechnungssteuer	A	A		11110	f	t	\N	10005
10127	11118	MWST Vorsteuer auf Investitionen	A	A		11110	f	t	\N	10005
10128	36004	Versand	A	I	IC_income	36000	f	t	\N	10045
10129	36001	Reisezeit	A	I	IC_income	36000	f	t	\N	10045
10130	36002	Reise (Fahrt)	A	I	IC_income	36000	f	t	\N	10045
10131	11117	MWST Vorsteuer auf Aufwand	A	A		11110	f	t	\N	10005
10132	21228	Geschuldete Steuern	A	L	AP	21220	f	t	\N	10020
10133	21223	MWST (7,6)	A	L	AR_tax:AP_tax:IC_taxpart:IC_expense:IC_taxservice	21220	f	t	\N	10020
10134	57001	AHV, IV, EO, ALV	A	E	AP_amount:IC_income:IC_expense	57000	f	t	\N	10070
10135	21221	MWST (2,4)	A	L	AR_tax:AP_tax:IC_taxpart:IC_taxservice	21220	f	t	\N	10020
10136	21224	MWST (7.6) 1/2	A	L	AR_tax:AP_tax:IC_taxpart:IC_expense:IC_taxservice	21220	f	t	\N	10020
10137	66001	Werbeaufwand	A	E	AP_amount:IC_expense	66000	f	t	\N	10082
10138	21217	Privat	A	L	AP	21210	f	t	\N	10019
10139	11101	Kasse	A	A	AR_paid:AP_paid	11100	f	t	\N	10003
10140	50005	Leistungen von Sozialversicherung	A	E	AP_amount:IC_income:IC_expense	50000	f	t	\N	10069
10141	65005	Informatikaufwand	A	E	AP_amount:IC_expense	65000	f	t	\N	10081
10142	39004	Rundungsdifferenzen	A	I	AR_paid:AP_paid	39000	f	t	\N	10051
10143	11111	Debitoren	A	A	AR	11110	f	t	\N	10005
10144	61001	Miete	A	E	IC_expense	61000	f	t	\N	10075
10145	61002	Reinigung	A	E	IC_expense	61000	f	t	\N	10075
10146	61005	Übriger Raumaufwand	A	E	IC_expense	61000	f	t	\N	10075
10147	36003	Essen	A	I	IC_income	36000	f	t	\N	10045
10148	21231	Passive Rechnungsabgrenzung	A	L		21230	f	t	\N	10023
10149	67002	Produkteentwicklung	A	E		67000	f	t	\N	10083
10150	11001	Debitoren	A	A	AR	\N	f	t	\N	\N
10151	11701	Vorsteuer	A	A	AP_tax:IC_taxpart:IC_taxservice	\N	f	t	\N	\N
10152	22100	MWST 8,1%	A	L	AR_tax:AP_tax:IC_taxpart:IC_taxservice	\N	f	t	\N	\N
10153	22101	MWST 2,6%	A	L	AR_tax:AP_tax:IC_taxpart:IC_taxservice	\N	f	t	\N	\N
10154	11103	Bank EUR	A	A	AR_paid:AP_paid	\N	f	t	\N	\N
\.


--
-- Data for Name: chat; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.chat (id, trans_id, message, employee_id, creation_date) FROM stdin;
\.


--
-- Data for Name: contact; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.contact (id, trans_id, salutation, firstname, lastname, contacttitle, occupation, phone, fax, mobile, email, gender, parent_id, typeofcontact) FROM stdin;
2	10158									info@muster.invalid	M	\N	company
3	10159										M	\N	company
4	10160										M	\N	company
5	10161										M	\N	company
\.


--
-- Data for Name: credits; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.credits (id, reference, description, transdate, accno, amount) FROM stdin;
\.


--
-- Data for Name: curr; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.curr (rn, curr, "precision") FROM stdin;
1	CHF	2
2	EUR	2
3	USD	2
\.


--
-- Data for Name: customer; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customer (id, name, contact, phone, fax, email, notes, terms, taxincluded, customernumber, cc, bcc, business_id, taxnumber, sic_code, discount, creditlimit, iban, bic, employee_id, language_code, pricegroup_id, curr, startdate, enddate, arap_accno_id, payment_accno_id, discount_accno_id, cashdiscount, discountterms, threshold, paymentmethod_id, remittancevoucher, dispatch_id, last_modified, income_accno_id, payment_clearing_accno_id, reminderstop) FROM stdin;
10158	Muster AG	 			info@muster.invalid		30	f	K-101			0			0	0	CH9300762011623852957	POFICHBEXXX	0	\N	0	CHF	2024-01-01	\N	\N	\N	\N	0	0	0	0	t	0	2026-10-16 15:23:18.136335+02	10036	\N	t
10159	Dupont SARL	 					10	f	K-102			0			0.05	0	CH5604835012345678009	CRESCHZZ80A	0	\N	0	EUR	2024-01-01	\N	\N	\N	\N	0	0	0	0	t	0	2026-10-16 15:23:18.462182+02	\N	\N	f
\.


--
-- Data for Name: customercart; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customercart (cart_id, customer_id, parts_id, qty, price, taxaccounts) FROM stdin;
\.


--
-- Data for Name: customerlogin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customerlogin (id, login, passwd, session, session_exp, customer_id) FROM stdin;
\.


--
-- Data for Name: customertax; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customertax (customer_id, chart_id) FROM stdin;
10158	10152
10158	10153
10159	10152
10159	10153
\.


--
-- Data for Name: debits; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.debits (id, reference, description, transdate, accno, amount) FROM stdin;
\.


--
-- Data for Name: debitscredits; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.debitscredits (id, reference, description, transdate, debit_accno, credit_accno, amount) FROM stdin;
\.


--
-- Data for Name: defaults; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.defaults (fldname, fldvalue) FROM stdin;
inventory_accno_id	10101
income_accno_id	10044
expense_accno_id	10060
fxgain_accno_id	10121
fxloss_accno_id	10122
weightunit	kg
precision	2
version	2.8.52
company	Test Treuhand GmbH
address	Musterstrasse 1\n8000 Zürich
businessnumber	CHE-123.456.789
sinumber	1000
vinumber	5000
glnumber	G-1000
partnumber	A-100
employeenumber	M-1
customernumber	K-102
vendornumber	L-102
ponumber	P-1001
sonumber	S-1001
\.


--
-- Data for Name: department; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.department (id, description, role) FROM stdin;
10157	Hauptsitz	P
\.


--
-- Data for Name: dispatch; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dispatch (id, description) FROM stdin;
\.


--
-- Data for Name: dpt_trans; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dpt_trans (trans_id, department_id) FROM stdin;
10158	10157
10159	10157
10160	10157
10161	10157
10168	10157
10169	10157
10172	10157
10173	10157
10174	10157
10175	10157
10176	10157
10177	10157
10178	10157
10179	10157
10180	10157
\.


--
-- Data for Name: employee; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.employee (id, login, name, address1, address2, city, state, zipcode, country, workphone, workfax, workmobile, homephone, startdate, enddate, notes, role, sales, email, ssn, iban, bic, managerid, employeenumber, dob, closedto) FROM stdin;
10162	\N	Anna Beispiel	Seeweg 2		Luzern		6003	CH					2024-01-01	\N		manager	f	anna@example.invalid		CH9300762011623852957	POFICHBEXXX	0	M-7	\N	\N
\.


--
-- Data for Name: exchangerate; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.exchangerate (curr, transdate, buy, sell) FROM stdin;
EUR	2025-01-15	0.94	0.95
USD	2025-01-15	0.9	0.91
EUR	2025-02-10	0.935	0.945
EUR	2025-02-20	0	0.942
EUR	2025-03-05	0.93	0.94
EUR	2026-01-15	0.928	0.939
\.


--
-- Data for Name: exported_payment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.exported_payment (id, banking_export_event_id, rma_payment_id, payload, export_instruction_id) FROM stdin;
\.


--
-- Data for Name: fifo; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fifo (trans_id, transdate, parts_id, qty, costprice, sellprice, warehouse_id, invoice_id) FROM stdin;
\.


--
-- Data for Name: filtered; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.filtered (trans_id, entry_id, entry_id2, debit, credit) FROM stdin;
\.


--
-- Data for Name: financial_year; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.financial_year (id, start_date, end_date, status, yearend_id) FROM stdin;
1	2025-01-01	2025-12-31	CLOSED	1
2	2026-01-01	2026-12-31	CURRENT_FINANCIAL_YEAR	\N
\.


--
-- Data for Name: gifi; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.gifi (accno, description) FROM stdin;
1	AKTIVEN
2	PASSIVEN
4	AUFWAND FÜR MATERIAL, WAREN UND DIENSTLEISTUNGEN
5	PERSONALAUFWAND
10000	ANLAGEVERMÖGEN
11000	Forderungen
11100	Bank
11110	MWST Vorsteuer auf Investitionen
11120	Angefangene Arbeiten
14150	Büromaschinen, EDV
18000	Gründungsaufwand
20000	FREMDKAPITAL LANGFRISTIG
21000	Kurzfristige Finanzverbindlichkeiten
21200	Sozialversicherungen
21210	Gesellschafter
21220	MWST (3,6)
21230	Passive Rechnungsabgrenzung
24000	Gesellschafter
28000	Stammkapital
28290	Gewinnvortrag
30000	ÜBRIGER ERTRAG
31000	Computer
32000	Software kommerz.
34000	Beratung
36000	Essen
37000	Eigenleistungen
38000	Bestandesänderungen
39000	Rabatte, Preisnachlässe
40000	AUFWANDMINDERUNGEN
41000	Übrige Produkte
42000	Software kommerz.
44000	Aufwand für Drittleistungen
47000	Einkaufsspesen
48000	Bestandesänderungen
49000	Aufwandminderungen
50000	Löhne und Gehälter
57000	FAK
58000	Spesen
60000	VERWALTUNGS- UND INFORMATIKAUFWAND
61000	Reinigung
61900	Unterhalt
62000	Fahrzeugaufwand
63000	Betriebsversicherungen
65000	Übriger Verwaltungsaufwand
66000	Werbeaufwand
67000	Produkteentwicklung
68000	Finanzaufwand
69000	Abschreibungen
80000	AUSSERORDENTLICHER UND BETRIEBSFREMDER ERFOLG, STEUERN
90000	ABSCHLUSS
91000	ERFOLGSRECHNUNG
92000	BILANZ
93000	GEWINNVERWENDUNG
99000	SAMMEL- UND FEHLBUCHUNGEN
\.


--
-- Data for Name: gl; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.gl (id, reference, description, transdate, employee_id, notes, department_id, approved, curr, exchangerate, ts, onhold) FROM stdin;
10178	G-2025-01	Unterhalt Büro	2025-03-31	\N		10157	t	CHF	1	2026-10-16 15:23:39.110585	f
10179	JA-2025	Jahresabschluss 2025	2025-12-31	\N	\N	10157	t	CHF	\N	2026-10-16 15:23:39.566484	\N
\.


--
-- Data for Name: gl_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.gl_log (id, reference, description, transdate, employee_id, notes, department_id, approved, curr, exchangerate, ts, onhold) FROM stdin;
\.


--
-- Data for Name: gl_log_deleted; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.gl_log_deleted (id, reference, description, transdate, employee_id, notes, department_id, approved, curr, exchangerate, ts, onhold) FROM stdin;
\.


--
-- Data for Name: imported_balance; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.imported_balance (id, banking_import_event_id, balance_type, amount, balance_currency, credit_debit, date) FROM stdin;
\.


--
-- Data for Name: imported_transaction; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.imported_transaction (id, parent_imported_transaction_id, banking_import_event_id, amount, currency, credit_debit, booking_date, status, reversal_indicator, transaction_ref, bank_domain_code, bank_family_code, bank_sub_family_code, transaction_text, origin_amount, origin_currency, exchange_rate, related_party_name, related_party_address, end_to_end_id, purpose, remittance_ref, remittance_type, hashcode, suppression) FROM stdin;
\.


--
-- Data for Name: imported_transaction_to_booking; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.imported_transaction_to_booking (imported_transaction_id, booking_id, ledger_type, exchange_rate) FROM stdin;
\.


--
-- Data for Name: inventory; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.inventory (id, warehouse_id, parts_id, trans_id, orderitems_id, qty, shippingdate, employee_id, department_id, warehouse_id2, serialnumber, itemnotes, cost, linetype, description, invoice_id, cogs) FROM stdin;
2	10155	10163	10168	5	10	2025-01-10	0	10157	\N	\N	\N	\N	0	\N	\N	\N
3	10155	10164	10168	6	50	2025-01-10	0	10157	\N	\N	\N	\N	0	\N	\N	\N
4	10155	10166	10168	7	20	2025-01-10	0	10157	\N	\N	\N	\N	0	\N	\N	\N
5	10155	10163	10169	1	10	2025-01-15	0	10157	\N			800	0	Laptop	2	\N
6	10155	10164	10169	1	50	2025-01-15	0	10157	\N			15	0	Maus	3	\N
7	10155	10166	10169	1	20	2025-01-15	0	10157	\N			35	0	Fachbuch	4	\N
8	10156	10163	10170	\N	3	2025-01-20	0	10157	10155			800	1	Laptop	\N	\N
9	10155	10163	10170	\N	-3	2025-01-20	0	10157	10156			800	2	Laptop	\N	\N
10	10156	10164	10170	\N	10	2025-01-20	0	10157	10155			15	1	Maus	\N	\N
11	10155	10164	10170	\N	-10	2025-01-20	0	10157	10156			15	2	Maus	\N	\N
12	10155	10163	10171	\N	-2	2025-01-22	0	10157	\N	\N	\N	\N	4	\N	\N	\N
13	10155	10164	10171	\N	-2	2025-01-22	0	10157	\N	\N	\N	\N	4	\N	\N	\N
14	10155	10167	10171	\N	2	2025-01-22	0	10157	\N	\N	\N	\N	5	\N	\N	\N
15	10155	10163	10174	1	-2	2025-02-10	0	10157	\N			\N	0	Laptop	5	\N
16	10155	10165	10174	1	-3	2025-02-10	0	10157	\N			\N	0	Beratung	6	\N
17	10155	10167	10174	1	-1	2025-02-10	0	10157	\N			\N	0	Bürokit	9	\N
18	10156	10164	10175	1	-5	2025-02-10	0	10157	\N			\N	0	Maus	10	\N
19	10156	10163	10175	1	-1	2025-02-10	0	10157	\N			\N	0	Laptop	11	\N
20	10155	10166	10176	1	-4	2025-03-05	0	10157	\N			\N	0	Fachbuch	12	\N
21	10155	10165	10176	1	-1.5	2025-03-05	0	10157	\N			\N	0	Beratung	13	\N
22	10156	10164	10177	1	20	2025-02-20	0	10157	\N			13.19	0	Maus	14	\N
23	10156	10163	10180	1	-1	2026-01-15	0	10157	\N			\N	0	Laptop	15	\N
\.


--
-- Data for Name: invoice; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.invoice (id, trans_id, parts_id, description, qty, allocated, sellprice, fxsellprice, discount, assemblyitem, unit, project_id, deliverydate, serialnumber, itemnotes, lineitemdetail, ordernumber, ponumber, transdate, lastcost, warehouse_id, cogs) FROM stdin;
5	10174	10163	Laptop	2	-2	1200	1200	0	f	Stk	\N	2025-02-15			f			2025-02-10	\N	10155	\N
6	10174	10165	Beratung	3	-2	150	150	0	f	h	\N	2025-02-15			f			2025-02-10	\N	10155	\N
7	10174	10164	Maus	1	-1	0	0	\N	t	Stk	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
8	10174	10163	Laptop	1	-1	0	0	\N	t	Stk	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
9	10174	10167	Bürokit	1	-2	1240	1240	0	f	Set	\N	2025-02-15			f			2025-02-10	\N	10155	\N
3	10169	10164	Maus	-50	6	15	15	0	f	Stk	\N	2025-01-20			f			2025-01-15	\N	10155	\N
10	10175	10164	Maus	5	-5	42.08	45	0.05	f	Stk	\N	\N			f			2025-02-10	\N	10156	\N
11	10175	10163	Laptop	1	-1	1262.25	1350	0.05	f	Stk	\N	\N			f			2025-02-10	\N	10156	\N
4	10169	10166	Fachbuch	-20	4	35	35	0	f	Stk	\N	2025-01-20			f			2025-01-15	\N	10155	\N
12	10176	10166	Fachbuch	4	-4	60	60	0	f	Stk	\N	\N			f			2025-03-05	\N	10155	\N
13	10176	10165	Beratung	1.5	-4	150	150	0	f	h	\N	\N			f			2025-03-05	\N	10155	\N
14	10177	10164	Maus	-20	0	13.19	14	0	f	Stk	\N	\N			f			2025-02-20	\N	10156	\N
2	10169	10163	Laptop	-10	5	800	800	0	f	Stk	\N	2025-01-20			f			2025-01-15	\N	10155	\N
15	10180	10163	Laptop	1	-1	1252.8	1350	0.05	f	Stk	\N	\N			f			2026-01-15	\N	10156	\N
\.


--
-- Data for Name: invoice_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.invoice_log (id, trans_id, parts_id, description, qty, allocated, sellprice, fxsellprice, discount, assemblyitem, unit, project_id, deliverydate, serialnumber, itemnotes, lineitemdetail, ordernumber, ponumber, transdate, lastcost, warehouse_id, cogs, ts) FROM stdin;
\.


--
-- Data for Name: invoice_log_deleted; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.invoice_log_deleted (trans_id, chart_id, amount, transdate, source, approved, fx_transaction, project_id, memo, id, cleared, vr_id, entry_id, tax, taxamount, tax_chart_id, ts) FROM stdin;
\.


--
-- Data for Name: invoicetax; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.invoicetax (trans_id, invoice_id, chart_id, taxamount, amount) FROM stdin;
10169	2	10152	648	8000
10169	3	10152	60.75	750
10169	4	10153	18.2	700
10174	5	10152	194.4	2400
10174	6	10152	36.45	450
10174	9	10152	100.44	1240
10175	10	10152	16.18866	199.86
10175	11	10152	97.13034	1199.14
10176	12	10153	6.24	240
10176	13	10152	18.225	225
10177	14	10152	21.36456	263.76
10180	15	10152	96.40296	1190.16
\.


--
-- Data for Name: jcitems; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.jcitems (id, project_id, parts_id, description, qty, allocated, sellprice, fxsellprice, serialnumber, checkedin, checkedout, employee_id, notes) FROM stdin;
\.


--
-- Data for Name: language; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.language (code, description) FROM stdin;
\.


--
-- Data for Name: lastused; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lastused (id, report, cols, login) FROM stdin;
\.


--
-- Data for Name: makemodel; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.makemodel (parts_id, make, model) FROM stdin;
\.


--
-- Data for Name: oe; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.oe (id, ordnumber, transdate, vendor_id, customer_id, amount, netamount, reqdate, taxincluded, shippingpoint, notes, curr, employee_id, closed, quotation, quonumber, intnotes, department_id, shipvia, language_code, ponumber, terms, waybill, warehouse_id, description, aa_id, exchangerate) FROM stdin;
10168	P-1001	2025-01-10	10160	0	10176.95	9450	2025-01-20	f			CHF	0	t	f			10157		\N		30		10155		10169	1
10173	S-1001	2025-02-01	0	10158	2594.4	2400	2025-02-15	f			CHF	0	f	f			10157	Post	\N	PO-MA-77	30		10155		\N	1
10172	S-1001	2025-02-01	0	10158	7015.69	6490	2025-02-15	f			CHF	0	t	f			10157	Post	\N	PO-MA-77	30		10155		10174	1
\.


--
-- Data for Name: orderitems; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.orderitems (id, trans_id, parts_id, description, qty, sellprice, discount, unit, project_id, reqdate, ship, serialnumber, itemnotes, lineitemdetail, ordernumber, ponumber) FROM stdin;
5	10168	10163	Laptop	10	800	0	Stk	\N	2025-01-20	10			f		
6	10168	10164	Maus	50	15	0	Stk	\N	2025-01-20	50			f		
7	10168	10166	Fachbuch	20	35	0	Stk	\N	2025-01-20	20			f		
11	10172	10163	Laptop	4	1200	0	Stk	\N	2025-02-15	2			f		
12	10172	10165	Beratung	3	150	0	h	\N	2025-02-15	3			f		
13	10172	10167	Bürokit	1	1240	0	Set	\N	2025-02-15	1			f		
14	10173	10163	Laptop	2	1200	0	Stk	\N	2025-02-15	0			f		
\.


--
-- Data for Name: parts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.parts (id, partnumber, description, unit, listprice, sellprice, lastcost, priceupdate, weight, onhand, notes, makemodel, assembly, alternate, rop, inventory_accno_id, income_accno_id, expense_accno_id, bin, obsolete, bom, image, drawing, microfiche, partsgroup_id, project_id, avgcost, tariff_hscode, countryorigin, barcode, toolnumber) FROM stdin;
10167	K-1	Bürokit	Set	0	1240	815	2026-10-16	2.1	1		f	t	f	0	\N	10035	\N		f	f				0	\N	\N				
10166	B-200	Fachbuch	Stk	0	60	35	2026-10-16	0	16		f	f	f	0	10101	10036	10055		f	f				0	\N	35				
10165	S-1	Beratung	h	0	150	0	2026-10-16	0	0		f	f	f	0	\N	10043	10102		f	f	\N	\N	\N	0	\N	\N	\N	\N	\N	\N
10164	A-101	Maus	Stk	0	40	13.19	2026-10-16	0.1	63		f	f	f	0	10101	10036	10055		f	f				0	\N	14.48				
10163	A-100	Laptop	Stk	1300	1200	800	2026-10-16	2	4		f	f	f	2	10101	10035	10054	R1	f	f				0	\N	800				
\.


--
-- Data for Name: partsattr; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.partsattr (parts_id, hotnew) FROM stdin;
\.


--
-- Data for Name: partscustomer; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.partscustomer (parts_id, customer_id, pricegroup_id, pricebreak, sellprice, validfrom, validto, curr) FROM stdin;
\.


--
-- Data for Name: partsgroup; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.partsgroup (id, partsgroup, pos) FROM stdin;
\.


--
-- Data for Name: partstax; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.partstax (parts_id, chart_id) FROM stdin;
10163	10152
10164	10152
10165	10152
10166	10153
10167	10152
\.


--
-- Data for Name: partsvendor; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.partsvendor (vendor_id, parts_id, partnumber, leadtime, lastcost, curr) FROM stdin;
\.


--
-- Data for Name: payment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payment (id, trans_id, exchangerate, paymentmethod_id) FROM stdin;
1	10174	1	0
1	10176	1	0
1	10175	0.93	0
1	10169	1	0
\.


--
-- Data for Name: paymentmethod; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.paymentmethod (id, description, fee, rn) FROM stdin;
\.


--
-- Data for Name: pricegroup; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pricegroup (id, pricegroup) FROM stdin;
\.


--
-- Data for Name: project; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.project (id, projectnumber, description, startdate, enddate, parts_id, production, completed, customer_id) FROM stdin;
\.


--
-- Data for Name: recurring; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.recurring (id, reference, startdate, nextdate, enddate, repeat, unit, howmany, payment, description) FROM stdin;
\.


--
-- Data for Name: recurringemail; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.recurringemail (id, formname, format, message) FROM stdin;
\.


--
-- Data for Name: recurringprint; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.recurringprint (id, formname, format, printer) FROM stdin;
\.


--
-- Data for Name: report; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.report (reportid, reportcode, reportdescription, login) FROM stdin;
\.


--
-- Data for Name: reportvars; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reportvars (reportid, reportvariable, reportvalue) FROM stdin;
\.


--
-- Data for Name: search_irrelevant_words; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.search_irrelevant_words (id, search_target, word) FROM stdin;
1	RELATED_PARTY	sÃ rl
2	RELATED_PARTY	sa
3	RELATED_PARTY	gmbh
4	RELATED_PARTY	ag
5	RELATED_PARTY	sarl
6	RELATED_PARTY	sagl
7	RELATED_PARTY	gbr
8	RELATED_PARTY	ohg
9	RELATED_PARTY	partg
10	RELATED_PARTY	ug
11	RELATED_PARTY	ggmbh
12	RELATED_PARTY	llc
13	COMMON	the
14	COMMON	a
15	COMMON	an
16	COMMON	and
17	COMMON	der
18	COMMON	die
19	COMMON	das
20	COMMON	und
21	COMMON	ein
22	COMMON	eine
23	COMMON	le
24	COMMON	la
25	COMMON	et
26	COMMON	un
27	COMMON	une
\.


--
-- Data for Name: semaphore; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.semaphore (id, login, module, expires) FROM stdin;
\.


--
-- Data for Name: shipto; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.shipto (trans_id, shiptoname, shiptoaddress1, shiptoaddress2, shiptocity, shiptostate, shiptozipcode, shiptocountry, shiptocontact, shiptophone, shiptofax, shiptoemail) FROM stdin;
\.


--
-- Data for Name: sic; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sic (code, sictype, description) FROM stdin;
\.


--
-- Data for Name: status; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.status (trans_id, formname, printed, emailed, spoolfile) FROM stdin;
\.


--
-- Data for Name: tax; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tax (chart_id, rate, taxnumber, validto, reversecharge_id, vatkey, formdigit, validfrom, id, inactive) FROM stdin;
10021	0.036	\N	2023-12-31	\N	\N	0	\N	1	f
10133	0.076	\N	2023-12-31	\N	\N	0	\N	2	f
10135	0.024	\N	2023-12-31	\N	\N	0	\N	3	f
10136	0.076	\N	2023-12-31	\N	\N	0	\N	4	f
10152	0.081	CHE-123.456.789 MWST	\N	\N	\N	0	2024-01-01	5	f
10153	0.026	CHE-123.456.789 MWST	\N	\N	\N	0	2024-01-01	6	f
\.


--
-- Data for Name: translation; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.translation (trans_id, language_code, description) FROM stdin;
\.


--
-- Data for Name: trf; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.trf (id, transdate, trfnumber, description, notes, department_id, from_warehouse_id, to_warehouse_id, employee_id, delivereddate) FROM stdin;
10170	2025-01-20	T-1	Umlagerung Filiale Bern		10157	10155	10156	0	\N
\.


--
-- Data for Name: vat_settlement; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.vat_settlement (id, vat_form_id, period_from, period_to, creation_date, data, xml, type, meldecenter_data) FROM stdin;
\.


--
-- Data for Name: vendor; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.vendor (id, name, contact, phone, fax, email, notes, terms, taxincluded, vendornumber, cc, bcc, gifi_accno, business_id, taxnumber, sic_code, discount, creditlimit, iban, bic, employee_id, language_code, pricegroup_id, curr, startdate, enddate, arap_accno_id, payment_accno_id, discount_accno_id, cashdiscount, discountterms, threshold, paymentmethod_id, remittancevoucher, dispatch_id, last_modified, expense_accno_id, early_payment_discount, payment_clearing_accno_id, reminderstop) FROM stdin;
10160	Lieferant GmbH	 					30	f	L-101				0			0	0	CH4431999123000889012	UBSWCHZH80A	0	\N	0	CHF	2024-01-01	\N	\N	\N	\N	0	0	0	0	t	0	2026-10-16 15:23:18.807318+02	10054	0.0200	10004	t
10161	Euro Supply GmbH	 					14	f	L-102				0			0	0	DE89370400440532013000	COBADEFFXXX	0	\N	0	EUR	2024-01-01	\N	\N	\N	\N	0	0	0	0	t	0	2026-10-16 15:23:19.14466+02	\N	\N	\N	f
\.


--
-- Data for Name: vendortax; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.vendortax (vendor_id, chart_id) FROM stdin;
10160	10152
10160	10153
10161	10152
10161	10153
\.


--
-- Data for Name: vr; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.vr (br_id, trans_id, id, vouchernumber) FROM stdin;
\.


--
-- Data for Name: warehouse; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.warehouse (id, description) FROM stdin;
10155	Lager Zürich
10156	Lager Bern
\.


--
-- Data for Name: xabschluss; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.xabschluss (id, xml, data, status) FROM stdin;
\.


--
-- Data for Name: xabschluss_history; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.xabschluss_history (id, xml, data) FROM stdin;
\.


--
-- Data for Name: xcontrolling_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.xcontrolling_log (id, trans_id, controlling_key, checked, checked_timestamp, checked_hash, checked_login_ref, checked_by_ibp_user_id) FROM stdin;
\.


--
-- Data for Name: yearend; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.yearend (trans_id, transdate, id) FROM stdin;
10179	2025-12-31	1
\.


--
-- Name: addressid; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.addressid', 6, true);


--
-- Name: assemblyid; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.assemblyid', 3, true);


--
-- Name: bank_account_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.bank_account_id_seq', 1, false);


--
-- Name: banking_export_event_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.banking_export_event_id_seq', 1, false);


--
-- Name: banking_import_event_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.banking_import_event_id_seq', 1, false);


--
-- Name: blink_export_process_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.blink_export_process_id_seq', 1, false);


--
-- Name: blink_export_process_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.blink_export_process_log_id_seq', 1, false);


--
-- Name: blink_import_process_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.blink_import_process_id_seq', 1, false);


--
-- Name: blink_import_process_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.blink_import_process_log_id_seq', 1, false);


--
-- Name: booking_to_settlement_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.booking_to_settlement_id_seq', 1, false);


--
-- Name: chat_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.chat_id_seq', 1, false);


--
-- Name: contactid; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.contactid', 5, true);


--
-- Name: credits_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.credits_id_seq', 1, false);


--
-- Name: customerloginid; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.customerloginid', 1, true);


--
-- Name: debits_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.debits_id_seq', 1, false);


--
-- Name: debitscredits_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.debitscredits_id_seq', 1, false);


--
-- Name: entry_id; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.entry_id', 64, true);


--
-- Name: exported_payment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.exported_payment_id_seq', 1, false);


--
-- Name: financial_year_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.financial_year_id_seq', 2, true);


--
-- Name: id; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.id', 10180, true);


--
-- Name: imported_balance_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.imported_balance_id_seq', 1, false);


--
-- Name: imported_transaction_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.imported_transaction_id_seq', 1, false);


--
-- Name: inventoryid; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.inventoryid', 23, true);


--
-- Name: invoiceid; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.invoiceid', 15, true);


--
-- Name: jcitemsid; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.jcitemsid', 1, true);


--
-- Name: lastused_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.lastused_id_seq', 1, false);


--
-- Name: orderitemsid; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.orderitemsid', 14, true);


--
-- Name: search_irrelevant_words_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.search_irrelevant_words_id_seq', 27, true);


--
-- Name: tax_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tax_id_seq', 6, true);


--
-- Name: vat_settlement_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.vat_settlement_id_seq', 1, false);


--
-- Name: xabschluss_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.xabschluss_history_id_seq', 1, false);


--
-- Name: xabschluss_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.xabschluss_id_seq', 1, false);


--
-- Name: xcontrolling_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.xcontrolling_log_id_seq', 1, false);


--
-- Name: yearend_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.yearend_id_seq', 1, true);


--
-- Name: address address_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.address
    ADD CONSTRAINT address_pkey PRIMARY KEY (id);


--
-- Name: bank_account bank_account_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bank_account
    ADD CONSTRAINT bank_account_pkey PRIMARY KEY (id);


--
-- Name: banking_export_event banking_export_event_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.banking_export_event
    ADD CONSTRAINT banking_export_event_pkey PRIMARY KEY (id);


--
-- Name: banking_import_event banking_import_event_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.banking_import_event
    ADD CONSTRAINT banking_import_event_pkey PRIMARY KEY (id);


--
-- Name: blink_export_process_log blink_export_process_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blink_export_process_log
    ADD CONSTRAINT blink_export_process_log_pkey PRIMARY KEY (id);


--
-- Name: blink_export_process blink_export_process_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blink_export_process
    ADD CONSTRAINT blink_export_process_pkey PRIMARY KEY (id);


--
-- Name: blink_import_process_log blink_import_process_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blink_import_process_log
    ADD CONSTRAINT blink_import_process_log_pkey PRIMARY KEY (id);


--
-- Name: blink_import_process blink_import_process_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blink_import_process
    ADD CONSTRAINT blink_import_process_pkey PRIMARY KEY (id);


--
-- Name: booking_to_settlement booking_to_settlement_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.booking_to_settlement
    ADD CONSTRAINT booking_to_settlement_pkey PRIMARY KEY (id);


--
-- Name: br br_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.br
    ADD CONSTRAINT br_pkey PRIMARY KEY (id);


--
-- Name: build build_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.build
    ADD CONSTRAINT build_pkey PRIMARY KEY (id);


--
-- Name: chat chat_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.chat
    ADD CONSTRAINT chat_pkey PRIMARY KEY (id);


--
-- Name: contact contact_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contact
    ADD CONSTRAINT contact_pkey PRIMARY KEY (id);


--
-- Name: curr curr_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.curr
    ADD CONSTRAINT curr_pkey PRIMARY KEY (curr);


--
-- Name: customer customer_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer
    ADD CONSTRAINT customer_pkey PRIMARY KEY (id);


--
-- Name: customerlogin customerlogin_login_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customerlogin
    ADD CONSTRAINT customerlogin_login_key UNIQUE (login);


--
-- Name: customerlogin customerlogin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customerlogin
    ADD CONSTRAINT customerlogin_pkey PRIMARY KEY (id);


--
-- Name: customerlogin customerlogin_session_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customerlogin
    ADD CONSTRAINT customerlogin_session_key UNIQUE (session);


--
-- Name: exported_payment exported_payment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.exported_payment
    ADD CONSTRAINT exported_payment_pkey PRIMARY KEY (id);


--
-- Name: financial_year financial_year_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.financial_year
    ADD CONSTRAINT financial_year_pkey PRIMARY KEY (id);


--
-- Name: imported_balance imported_balance_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.imported_balance
    ADD CONSTRAINT imported_balance_pkey PRIMARY KEY (id);


--
-- Name: imported_transaction imported_transaction_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.imported_transaction
    ADD CONSTRAINT imported_transaction_pkey PRIMARY KEY (id);


--
-- Name: invoice invoice_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoice
    ADD CONSTRAINT invoice_pkey PRIMARY KEY (id);


--
-- Name: lastused lastused_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lastused
    ADD CONSTRAINT lastused_pkey PRIMARY KEY (id);


--
-- Name: paymentmethod paymentmethod_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.paymentmethod
    ADD CONSTRAINT paymentmethod_pkey PRIMARY KEY (id);


--
-- Name: report report_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.report
    ADD CONSTRAINT report_pkey PRIMARY KEY (reportid);


--
-- Name: search_irrelevant_words search_irrelevant_words_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.search_irrelevant_words
    ADD CONSTRAINT search_irrelevant_words_pkey PRIMARY KEY (id);


--
-- Name: tax tax_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tax
    ADD CONSTRAINT tax_pkey PRIMARY KEY (id);


--
-- Name: trf trf_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trf
    ADD CONSTRAINT trf_pkey PRIMARY KEY (id);


--
-- Name: vat_settlement vat_settlement_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vat_settlement
    ADD CONSTRAINT vat_settlement_pkey PRIMARY KEY (id);


--
-- Name: vendor vendor_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vendor
    ADD CONSTRAINT vendor_pkey PRIMARY KEY (id);


--
-- Name: xabschluss_history xabschluss_history_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.xabschluss_history
    ADD CONSTRAINT xabschluss_history_pkey PRIMARY KEY (id);


--
-- Name: xabschluss xabschluss_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.xabschluss
    ADD CONSTRAINT xabschluss_pkey PRIMARY KEY (id);


--
-- Name: yearend yearend_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.yearend
    ADD CONSTRAINT yearend_pkey PRIMARY KEY (id);


--
-- Name: acc_trans_chart_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX acc_trans_chart_id_key ON public.acc_trans USING btree (chart_id);


--
-- Name: acc_trans_chart_id_transdate_approved_trans_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX acc_trans_chart_id_transdate_approved_trans_id ON public.acc_trans USING btree (chart_id, transdate, approved, trans_id, amount);


--
-- Name: acc_trans_source_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX acc_trans_source_key ON public.acc_trans USING btree (lower(source));


--
-- Name: acc_trans_trans_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX acc_trans_trans_id_key ON public.acc_trans USING btree (trans_id);


--
-- Name: acc_trans_transdate_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX acc_trans_transdate_key ON public.acc_trans USING btree (transdate);


--
-- Name: ap_employee_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ap_employee_id_key ON public.ap USING btree (employee_id);


--
-- Name: ap_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ap_id_key ON public.ap USING btree (id);


--
-- Name: ap_invnumber_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ap_invnumber_key ON public.ap USING btree (invnumber);


--
-- Name: ap_ordnumber_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ap_ordnumber_key ON public.ap USING btree (ordnumber);


--
-- Name: ap_quonumber_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ap_quonumber_key ON public.ap USING btree (quonumber);


--
-- Name: ap_transdate_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ap_transdate_key ON public.ap USING btree (transdate);


--
-- Name: ap_vendor_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ap_vendor_id_key ON public.ap USING btree (vendor_id);


--
-- Name: ar_customer_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ar_customer_id_key ON public.ar USING btree (customer_id);


--
-- Name: ar_employee_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ar_employee_id_key ON public.ar USING btree (employee_id);


--
-- Name: ar_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ar_id_key ON public.ar USING btree (id);


--
-- Name: ar_invnumber_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ar_invnumber_key ON public.ar USING btree (invnumber);


--
-- Name: ar_ordnumber_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ar_ordnumber_key ON public.ar USING btree (ordnumber);


--
-- Name: ar_quonumber_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ar_quonumber_key ON public.ar USING btree (quonumber);


--
-- Name: ar_transdate_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ar_transdate_key ON public.ar USING btree (transdate);


--
-- Name: assembly_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX assembly_id_key ON public.assembly USING btree (id);


--
-- Name: audittrail_trans_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX audittrail_trans_id_key ON public.audittrail USING btree (trans_id);


--
-- Name: cargo_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX cargo_id_key ON public.cargo USING btree (id, trans_id);


--
-- Name: chart_accno_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX chart_accno_key ON public.chart USING btree (accno);


--
-- Name: chart_category_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX chart_category_key ON public.chart USING btree (category);


--
-- Name: chart_gifi_accno_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX chart_gifi_accno_key ON public.chart USING btree (gifi_accno);


--
-- Name: chart_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX chart_id_key ON public.chart USING btree (id);


--
-- Name: chart_link_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX chart_link_key ON public.chart USING btree (link);


--
-- Name: customer_contact_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX customer_contact_key ON public.customer USING btree (lower((contact)::text));


--
-- Name: customer_customer_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX customer_customer_id_key ON public.customertax USING btree (customer_id);


--
-- Name: customer_customernumber_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX customer_customernumber_key ON public.customer USING btree (customernumber);


--
-- Name: customer_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX customer_name_key ON public.customer USING btree (lower((name)::text));


--
-- Name: department_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX department_id_key ON public.department USING btree (id);


--
-- Name: employee_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX employee_id_key ON public.employee USING btree (id);


--
-- Name: employee_login_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX employee_login_key ON public.employee USING btree (login);


--
-- Name: employee_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX employee_name_key ON public.employee USING btree (lower((name)::text));


--
-- Name: exchangerate_ct_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX exchangerate_ct_key ON public.exchangerate USING btree (curr, transdate);


--
-- Name: fifo_parts_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fifo_parts_id ON public.fifo USING btree (parts_id);


--
-- Name: fifo_trans_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fifo_trans_id ON public.fifo USING btree (trans_id);


--
-- Name: gifi_accno_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX gifi_accno_key ON public.gifi USING btree (accno);


--
-- Name: gl_description_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX gl_description_key ON public.gl USING btree (lower(description));


--
-- Name: gl_employee_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX gl_employee_id_key ON public.gl USING btree (employee_id);


--
-- Name: gl_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX gl_id_key ON public.gl USING btree (id);


--
-- Name: gl_reference_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX gl_reference_key ON public.gl USING btree (reference);


--
-- Name: gl_transdate_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX gl_transdate_key ON public.gl USING btree (transdate);


--
-- Name: inventory_invoice_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX inventory_invoice_id ON public.inventory USING btree (invoice_id);


--
-- Name: inventory_parts_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX inventory_parts_id_key ON public.inventory USING btree (parts_id);


--
-- Name: invoice_parts_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX invoice_parts_id ON public.invoice USING btree (parts_id);


--
-- Name: invoice_qty; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX invoice_qty ON public.invoice USING btree (qty);


--
-- Name: invoice_trans_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX invoice_trans_id_key ON public.invoice USING btree (trans_id);


--
-- Name: jcitems_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX jcitems_id_key ON public.jcitems USING btree (id);


--
-- Name: language_code_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX language_code_key ON public.language USING btree (code);


--
-- Name: makemodel_make_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX makemodel_make_key ON public.makemodel USING btree (lower(make));


--
-- Name: makemodel_model_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX makemodel_model_key ON public.makemodel USING btree (lower(model));


--
-- Name: makemodel_parts_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX makemodel_parts_id_key ON public.makemodel USING btree (parts_id);


--
-- Name: oe_employee_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX oe_employee_id_key ON public.oe USING btree (employee_id);


--
-- Name: oe_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX oe_id_key ON public.oe USING btree (id);


--
-- Name: oe_ordnumber_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX oe_ordnumber_key ON public.oe USING btree (ordnumber);


--
-- Name: oe_transdate_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX oe_transdate_key ON public.oe USING btree (transdate);


--
-- Name: orderitems_trans_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX orderitems_trans_id_key ON public.orderitems USING btree (trans_id);


--
-- Name: parts_description_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX parts_description_key ON public.parts USING btree (lower(description));


--
-- Name: parts_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX parts_id_key ON public.parts USING btree (id);


--
-- Name: parts_partnumber_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX parts_partnumber_key ON public.parts USING btree (lower(partnumber));


--
-- Name: partscustomer_customer_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX partscustomer_customer_id_key ON public.partscustomer USING btree (customer_id);


--
-- Name: partscustomer_parts_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX partscustomer_parts_id_key ON public.partscustomer USING btree (parts_id);


--
-- Name: partsgroup_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX partsgroup_id_key ON public.partsgroup USING btree (id);


--
-- Name: partsgroup_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX partsgroup_key ON public.partsgroup USING btree (partsgroup);


--
-- Name: partstax_parts_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX partstax_parts_id_key ON public.partstax USING btree (parts_id);


--
-- Name: partsvendor_parts_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX partsvendor_parts_id_key ON public.partsvendor USING btree (parts_id);


--
-- Name: partsvendor_vendor_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX partsvendor_vendor_id_key ON public.partsvendor USING btree (vendor_id);


--
-- Name: pricegroup_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX pricegroup_id_key ON public.pricegroup USING btree (id);


--
-- Name: pricegroup_pricegroup_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX pricegroup_pricegroup_key ON public.pricegroup USING btree (pricegroup);


--
-- Name: project_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX project_id_key ON public.project USING btree (id);


--
-- Name: projectnumber_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX projectnumber_key ON public.project USING btree (projectnumber);


--
-- Name: shipto_trans_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX shipto_trans_id_key ON public.shipto USING btree (trans_id);


--
-- Name: status_trans_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX status_trans_id_key ON public.status USING btree (trans_id);


--
-- Name: translation_trans_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX translation_trans_id_key ON public.translation USING btree (trans_id);


--
-- Name: vendor_contact_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX vendor_contact_key ON public.vendor USING btree (lower((contact)::text));


--
-- Name: vendor_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX vendor_name_key ON public.vendor USING btree (lower((name)::text));


--
-- Name: vendor_vendornumber_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX vendor_vendornumber_key ON public.vendor USING btree (vendornumber);


--
-- Name: vendortax_vendor_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX vendortax_vendor_id_key ON public.vendortax USING btree (vendor_id);


--
-- Name: customer trg_set_last_modified_customer; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_set_last_modified_customer BEFORE UPDATE ON public.customer FOR EACH ROW EXECUTE FUNCTION public.update_last_modified_column();


--
-- Name: vendor trg_set_last_modified_vendor; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_set_last_modified_vendor BEFORE UPDATE ON public.vendor FOR EACH ROW EXECUTE FUNCTION public.update_last_modified_column();


--
-- Name: acc_trans acc_trans_imported_transaction_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.acc_trans
    ADD CONSTRAINT acc_trans_imported_transaction_id_fkey FOREIGN KEY (imported_transaction_id) REFERENCES public.imported_transaction(id);


--
-- Name: banking_export_event banking_export_event_bank_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.banking_export_event
    ADD CONSTRAINT banking_export_event_bank_account_id_fkey FOREIGN KEY (bank_account_id) REFERENCES public.bank_account(id);


--
-- Name: banking_import_event banking_import_event_bank_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.banking_import_event
    ADD CONSTRAINT banking_import_event_bank_account_id_fkey FOREIGN KEY (bank_account_id) REFERENCES public.bank_account(id);


--
-- Name: blink_export_process blink_export_process_bank_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blink_export_process
    ADD CONSTRAINT blink_export_process_bank_account_id_fkey FOREIGN KEY (bank_account_id) REFERENCES public.bank_account(id);


--
-- Name: blink_export_process_log blink_export_process_log_banking_export_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blink_export_process_log
    ADD CONSTRAINT blink_export_process_log_banking_export_event_id_fkey FOREIGN KEY (banking_export_event_id) REFERENCES public.banking_export_event(id);


--
-- Name: blink_export_process_log blink_export_process_log_blink_export_process_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blink_export_process_log
    ADD CONSTRAINT blink_export_process_log_blink_export_process_id_fkey FOREIGN KEY (blink_export_process_id) REFERENCES public.blink_export_process(id);


--
-- Name: blink_import_process blink_import_process_bank_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blink_import_process
    ADD CONSTRAINT blink_import_process_bank_account_id_fkey FOREIGN KEY (bank_account_id) REFERENCES public.bank_account(id);


--
-- Name: blink_import_process_log blink_import_process_log_banking_import_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blink_import_process_log
    ADD CONSTRAINT blink_import_process_log_banking_import_event_id_fkey FOREIGN KEY (banking_import_event_id) REFERENCES public.banking_import_event(id);


--
-- Name: blink_import_process_log blink_import_process_log_blink_import_process_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blink_import_process_log
    ADD CONSTRAINT blink_import_process_log_blink_import_process_id_fkey FOREIGN KEY (blink_import_process_id) REFERENCES public.blink_import_process(id);


--
-- Name: booking_to_settlement booking_to_settlement_settlement_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.booking_to_settlement
    ADD CONSTRAINT booking_to_settlement_settlement_id_fkey FOREIGN KEY (settlement_id) REFERENCES public.vat_settlement(id);


--
-- Name: exported_payment exported_payment_banking_export_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.exported_payment
    ADD CONSTRAINT exported_payment_banking_export_event_id_fkey FOREIGN KEY (banking_export_event_id) REFERENCES public.banking_export_event(id);


--
-- Name: financial_year fk_yearend; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.financial_year
    ADD CONSTRAINT fk_yearend FOREIGN KEY (yearend_id) REFERENCES public.yearend(id) ON DELETE SET NULL;


--
-- Name: imported_balance imported_balance_banking_import_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.imported_balance
    ADD CONSTRAINT imported_balance_banking_import_event_id_fkey FOREIGN KEY (banking_import_event_id) REFERENCES public.banking_import_event(id);


--
-- Name: imported_transaction imported_transaction_banking_import_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.imported_transaction
    ADD CONSTRAINT imported_transaction_banking_import_event_id_fkey FOREIGN KEY (banking_import_event_id) REFERENCES public.banking_import_event(id);


--
-- Name: imported_transaction imported_transaction_parent_imported_transaction_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.imported_transaction
    ADD CONSTRAINT imported_transaction_parent_imported_transaction_id_fkey FOREIGN KEY (parent_imported_transaction_id) REFERENCES public.imported_transaction(id);


--
-- Name: imported_transaction_to_booking imported_transaction_to_booking_imported_transaction_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.imported_transaction_to_booking
    ADD CONSTRAINT imported_transaction_to_booking_imported_transaction_id_fkey FOREIGN KEY (imported_transaction_id) REFERENCES public.imported_transaction(id);


--
-- Name: vr vr_br_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vr
    ADD CONSTRAINT vr_br_id_fkey FOREIGN KEY (br_id) REFERENCES public.br(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

