--
-- PostgreSQL database dump
--

-- Dumped from database version 15.13 (Homebrew)
-- Dumped by pg_dump version 15.13 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: rma_test_de; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE rma_test_de WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'C';


ALTER DATABASE rma_test_de OWNER TO postgres;

\connect rma_test_de

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: fuzzystrmatch; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS fuzzystrmatch WITH SCHEMA public;


--
-- Name: EXTENSION fuzzystrmatch; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION fuzzystrmatch IS 'determine similarities and distance between strings';


--
-- Name: financial_year_status_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.financial_year_status_enum AS ENUM (
    'OPEN',
    'CURRENT_FINANCIAL_YEAR',
    'CLOSED'
);


ALTER TYPE public.financial_year_status_enum OWNER TO postgres;

--
-- Name: settlement_type_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.settlement_type_enum AS ENUM (
    'NORMAL_SETTLEMENT',
    'CORRECTION_SETTLEMENT',
    'ANNUAL_RECONCILIATION'
);


ALTER TYPE public.settlement_type_enum OWNER TO postgres;

--
-- Name: to_filtered_tsvector(text, text, regconfig); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.to_filtered_tsvector(input text, filter_type text DEFAULT 'COMMON'::text, ts_config regconfig DEFAULT 'simple'::regconfig) RETURNS tsvector
    LANGUAGE plpgsql
    AS $$ DECLARE filtered_input TEXT; BEGIN SELECT string_agg(input_word, ' ') INTO filtered_input FROM unnest(string_to_array(input, ' ')) AS input_word WHERE lower(input_word) NOT IN (SELECT lower(word) FROM search_irrelevant_words WHERE search_target = 'COMMON' OR search_target = filter_type); RETURN to_tsvector(ts_config, filtered_input); END; $$;


ALTER FUNCTION public.to_filtered_tsvector(input text, filter_type text, ts_config regconfig) OWNER TO postgres;

--
-- Name: update_last_modified_column(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_last_modified_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
    new.last_modified := now();
    return new;
end;
$$;


ALTER FUNCTION public.update_last_modified_column() OWNER TO postgres;

--
-- Name: entry_id; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.entry_id
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.entry_id OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: acc_trans; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.acc_trans (
    trans_id integer,
    chart_id integer NOT NULL,
    amount double precision,
    transdate date DEFAULT CURRENT_DATE,
    source text,
    approved boolean DEFAULT true,
    fx_transaction boolean DEFAULT false,
    project_id integer,
    memo text,
    id integer,
    cleared date,
    vr_id integer,
    entry_id integer DEFAULT nextval('public.entry_id'::regclass),
    tax text,
    taxamount double precision,
    tax_chart_id integer,
    lineamount numeric(12,2) DEFAULT 0,
    imported_transaction_id integer
);


ALTER TABLE public.acc_trans OWNER TO postgres;

--
-- Name: acc_trans_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.acc_trans_log (
    trans_id integer,
    chart_id integer,
    amount double precision,
    transdate date,
    source text,
    approved boolean,
    fx_transaction boolean,
    project_id integer,
    memo text,
    id integer,
    cleared date,
    vr_id integer,
    entry_id integer,
    tax text,
    taxamount double precision,
    tax_chart_id integer,
    ts timestamp without time zone DEFAULT now(),
    lineamount numeric(12,2) DEFAULT 0
);


ALTER TABLE public.acc_trans_log OWNER TO postgres;

--
-- Name: acc_trans_log_deleted; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.acc_trans_log_deleted (
    trans_id integer,
    chart_id integer,
    amount double precision,
    transdate date,
    source text,
    approved boolean,
    fx_transaction boolean,
    project_id integer,
    memo text,
    id integer,
    cleared date,
    vr_id integer,
    entry_id integer,
    tax text,
    taxamount double precision,
    tax_chart_id integer,
    ts timestamp without time zone DEFAULT now(),
    lineamount numeric(12,2) DEFAULT 0
);


ALTER TABLE public.acc_trans_log_deleted OWNER TO postgres;

--
-- Name: addressid; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.addressid
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.addressid OWNER TO postgres;

--
-- Name: address; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.address (
    id integer DEFAULT nextval('public.addressid'::regclass) NOT NULL,
    trans_id integer,
    address1 character varying(64),
    address2 character varying(64),
    city character varying(64),
    state character varying(32),
    zipcode character varying(32),
    country character varying(32),
    post_office character varying(64),
    is_migrated boolean DEFAULT true
);


ALTER TABLE public.address OWNER TO postgres;

--
-- Name: id; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.id
    START WITH 10000
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.id OWNER TO postgres;

--
-- Name: ap; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ap (
    id integer DEFAULT nextval('public.id'::regclass),
    invnumber text,
    transdate date DEFAULT CURRENT_DATE,
    vendor_id integer,
    taxincluded boolean DEFAULT false,
    amount double precision,
    netamount double precision,
    paid double precision,
    datepaid date,
    duedate date,
    invoice boolean DEFAULT false,
    ordnumber text,
    curr character(3),
    notes text,
    employee_id integer,
    till character varying(20),
    quonumber text,
    intnotes text,
    department_id integer DEFAULT 0,
    shipvia text,
    language_code character varying(6),
    ponumber text,
    shippingpoint text,
    terms smallint DEFAULT 0,
    approved boolean DEFAULT true,
    cashdiscount real,
    discountterms smallint,
    waybill text,
    warehouse_id integer,
    description text,
    onhold boolean DEFAULT false,
    exchangerate double precision,
    dcn text,
    bank_id integer,
    paymentmethod_id integer,
    fxamount double precision DEFAULT 0,
    fxpaid double precision DEFAULT 0,
    linetax boolean DEFAULT false,
    ts timestamp without time zone DEFAULT now()
);


ALTER TABLE public.ap OWNER TO postgres;

--
-- Name: ap_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ap_log (
    id integer,
    invnumber text,
    transdate date,
    vendor_id integer,
    taxincluded boolean,
    amount double precision,
    netamount double precision,
    paid double precision,
    datepaid date,
    duedate date,
    invoice boolean,
    ordnumber text,
    curr character(3),
    notes text,
    employee_id integer,
    till character varying(20),
    quonumber text,
    intnotes text,
    department_id integer,
    shipvia text,
    language_code character varying(6),
    ponumber text,
    shippingpoint text,
    terms smallint,
    approved boolean,
    cashdiscount real,
    discountterms smallint,
    waybill text,
    warehouse_id integer,
    description text,
    onhold boolean,
    exchangerate double precision,
    dcn text,
    bank_id integer,
    paymentmethod_id integer,
    fxamount double precision,
    fxpaid double precision,
    linetax boolean,
    ts timestamp without time zone
);


ALTER TABLE public.ap_log OWNER TO postgres;

--
-- Name: ap_log_deleted; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ap_log_deleted (
    id integer,
    invnumber text,
    transdate date,
    vendor_id integer,
    taxincluded boolean,
    amount double precision,
    netamount double precision,
    paid double precision,
    datepaid date,
    duedate date,
    invoice boolean,
    ordnumber text,
    curr character(3),
    notes text,
    employee_id integer,
    till character varying(20),
    quonumber text,
    intnotes text,
    department_id integer,
    shipvia text,
    language_code character varying(6),
    ponumber text,
    shippingpoint text,
    terms smallint,
    approved boolean,
    cashdiscount real,
    discountterms smallint,
    waybill text,
    warehouse_id integer,
    description text,
    onhold boolean,
    exchangerate double precision,
    dcn text,
    bank_id integer,
    paymentmethod_id integer,
    fxamount double precision,
    fxpaid double precision,
    linetax boolean,
    ts timestamp without time zone
);


ALTER TABLE public.ap_log_deleted OWNER TO postgres;

--
-- Name: ar; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ar (
    id integer DEFAULT nextval('public.id'::regclass),
    invnumber text,
    transdate date DEFAULT CURRENT_DATE,
    customer_id integer,
    taxincluded boolean,
    amount double precision,
    netamount double precision,
    paid double precision,
    datepaid date,
    duedate date,
    invoice boolean DEFAULT false,
    shippingpoint text,
    terms smallint DEFAULT 0,
    notes text,
    curr character(3),
    ordnumber text,
    employee_id integer,
    till character varying(20),
    quonumber text,
    intnotes text,
    department_id integer DEFAULT 0,
    shipvia text,
    language_code character varying(6),
    ponumber text,
    approved boolean DEFAULT true,
    cashdiscount real,
    discountterms smallint,
    waybill text,
    warehouse_id integer,
    description text,
    onhold boolean DEFAULT false,
    exchangerate double precision,
    dcn text,
    bank_id integer,
    paymentmethod_id integer,
    fxamount double precision DEFAULT 0,
    fxpaid double precision DEFAULT 0,
    linetax boolean DEFAULT false,
    ts timestamp without time zone DEFAULT now()
);


ALTER TABLE public.ar OWNER TO postgres;

--
-- Name: ar_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ar_log (
    id integer,
    invnumber text,
    transdate date,
    customer_id integer,
    taxincluded boolean,
    amount double precision,
    netamount double precision,
    paid double precision,
    datepaid date,
    duedate date,
    invoice boolean,
    shippingpoint text,
    terms smallint,
    notes text,
    curr character(3),
    ordnumber text,
    employee_id integer,
    till character varying(20),
    quonumber text,
    intnotes text,
    department_id integer,
    shipvia text,
    language_code character varying(6),
    ponumber text,
    approved boolean,
    cashdiscount real,
    discountterms smallint,
    waybill text,
    warehouse_id integer,
    description text,
    onhold boolean,
    exchangerate double precision,
    dcn text,
    bank_id integer,
    paymentmethod_id integer,
    fxamount double precision,
    fxpaid double precision,
    linetax boolean,
    ts timestamp without time zone
);


ALTER TABLE public.ar_log OWNER TO postgres;

--
-- Name: ar_log_deleted; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ar_log_deleted (
    id integer,
    invnumber text,
    transdate date,
    customer_id integer,
    taxincluded boolean,
    amount double precision,
    netamount double precision,
    paid double precision,
    datepaid date,
    duedate date,
    invoice boolean,
    shippingpoint text,
    terms smallint,
    notes text,
    curr character(3),
    ordnumber text,
    employee_id integer,
    till character varying(20),
    quonumber text,
    intnotes text,
    department_id integer,
    shipvia text,
    language_code character varying(6),
    ponumber text,
    approved boolean,
    cashdiscount real,
    discountterms smallint,
    waybill text,
    warehouse_id integer,
    description text,
    onhold boolean,
    exchangerate double precision,
    dcn text,
    bank_id integer,
    paymentmethod_id integer,
    fxamount double precision,
    fxpaid double precision,
    linetax boolean,
    ts timestamp without time zone
);


ALTER TABLE public.ar_log_deleted OWNER TO postgres;

--
-- Name: assemblyid; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.assemblyid
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.assemblyid OWNER TO postgres;

--
-- Name: assembly; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.assembly (
    id integer DEFAULT nextval('public.assemblyid'::regclass),
    parts_id integer,
    qty double precision,
    bom boolean,
    adj boolean,
    aid integer
);


ALTER TABLE public.assembly OWNER TO postgres;

--
-- Name: audittrail; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.audittrail (
    trans_id integer,
    tablename text,
    reference text,
    formname text,
    action text,
    transdate timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    employee_id integer
);


ALTER TABLE public.audittrail OWNER TO postgres;

--
-- Name: bank; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.bank (
    id integer,
    name character varying(64),
    iban character varying(34),
    bic character varying(11),
    address_id integer DEFAULT nextval('public.addressid'::regclass),
    dcn text,
    rvc text,
    membernumber text,
    qriban text,
    strdbkginf text,
    invdescriptionqr text
);


ALTER TABLE public.bank OWNER TO postgres;

--
-- Name: bank_account; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.bank_account (
    id integer NOT NULL,
    bic text,
    iban text,
    account text,
    bank text,
    branch text,
    country text,
    country_iso text,
    city text,
    state text,
    zip text,
    address text,
    description text,
    chart_id integer,
    inactive boolean,
    currency character varying(3),
    blink_permission_id bigint,
    blink_account_id text
);


ALTER TABLE public.bank_account OWNER TO postgres;

--
-- Name: bank_account_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.bank_account ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.bank_account_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: banking_export_event; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.banking_export_event (
    id integer NOT NULL,
    status text NOT NULL,
    bank_account_id integer NOT NULL,
    source_type text NOT NULL,
    exported_when timestamp without time zone NOT NULL,
    is_manual boolean NOT NULL,
    export_message_id text NOT NULL,
    export_submission_id text
);


ALTER TABLE public.banking_export_event OWNER TO postgres;

--
-- Name: banking_export_event_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.banking_export_event_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.banking_export_event_id_seq OWNER TO postgres;

--
-- Name: banking_export_event_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.banking_export_event_id_seq OWNED BY public.banking_export_event.id;


--
-- Name: banking_import_event; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.banking_import_event (
    id integer NOT NULL,
    status text NOT NULL,
    bank_account_id integer,
    imported_iban text,
    imported_currency text,
    imported_owner text,
    total_credit double precision,
    total_debit double precision,
    transactions_count integer,
    imported_when timestamp without time zone NOT NULL,
    source_type text NOT NULL,
    is_manual boolean NOT NULL,
    filename text,
    file_content text,
    delegated_to text
);


ALTER TABLE public.banking_import_event OWNER TO postgres;

--
-- Name: banking_import_event_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.banking_import_event ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.banking_import_event_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: blink_export_process; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.blink_export_process (
    id integer NOT NULL,
    bank_account_id integer NOT NULL,
    process_type text NOT NULL,
    status text NOT NULL,
    error jsonb,
    created_at timestamp without time zone NOT NULL,
    last_modified_at timestamp without time zone
);


ALTER TABLE public.blink_export_process OWNER TO postgres;

--
-- Name: blink_export_process_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.blink_export_process_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.blink_export_process_id_seq OWNER TO postgres;

--
-- Name: blink_export_process_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.blink_export_process_id_seq OWNED BY public.blink_export_process.id;


--
-- Name: blink_export_process_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.blink_export_process_log (
    id integer NOT NULL,
    blink_export_process_id bigint NOT NULL,
    processed_target_id text NOT NULL,
    processed_payload jsonb NOT NULL,
    error jsonb,
    banking_export_event_id bigint,
    correlation_id character varying(255)
);


ALTER TABLE public.blink_export_process_log OWNER TO postgres;

--
-- Name: blink_export_process_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.blink_export_process_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.blink_export_process_log_id_seq OWNER TO postgres;

--
-- Name: blink_export_process_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.blink_export_process_log_id_seq OWNED BY public.blink_export_process_log.id;


--
-- Name: blink_import_process; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.blink_import_process (
    id integer NOT NULL,
    bank_account_id bigint NOT NULL,
    status text NOT NULL,
    error jsonb,
    created_at timestamp without time zone NOT NULL,
    last_modified_at timestamp without time zone
);


ALTER TABLE public.blink_import_process OWNER TO postgres;

--
-- Name: blink_import_process_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.blink_import_process_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.blink_import_process_id_seq OWNER TO postgres;

--
-- Name: blink_import_process_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.blink_import_process_id_seq OWNED BY public.blink_import_process.id;


--
-- Name: blink_import_process_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.blink_import_process_log (
    id integer NOT NULL,
    blink_import_process_id bigint NOT NULL,
    processed_target_id text NOT NULL,
    processed_payload jsonb NOT NULL,
    error jsonb,
    banking_import_event_id bigint,
    correlation_id character varying(255)
);


ALTER TABLE public.blink_import_process_log OWNER TO postgres;

--
-- Name: blink_import_process_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.blink_import_process_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.blink_import_process_log_id_seq OWNER TO postgres;

--
-- Name: blink_import_process_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.blink_import_process_log_id_seq OWNED BY public.blink_import_process_log.id;


--
-- Name: booking_to_settlement; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.booking_to_settlement (
    id integer NOT NULL,
    booking_id integer NOT NULL,
    settlement_id integer NOT NULL
);


ALTER TABLE public.booking_to_settlement OWNER TO postgres;

--
-- Name: booking_to_settlement_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.booking_to_settlement_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.booking_to_settlement_id_seq OWNER TO postgres;

--
-- Name: booking_to_settlement_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.booking_to_settlement_id_seq OWNED BY public.booking_to_settlement.id;


--
-- Name: br; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.br (
    id integer DEFAULT nextval('public.id'::regclass) NOT NULL,
    batchnumber text,
    description text,
    batch text,
    transdate date DEFAULT CURRENT_DATE,
    apprdate date,
    amount double precision,
    managerid integer,
    employee_id integer
);


ALTER TABLE public.br OWNER TO postgres;

--
-- Name: build; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.build (
    id integer DEFAULT nextval('public.id'::regclass) NOT NULL,
    reference text,
    transdate date,
    department_id integer,
    warehouse_id integer,
    employee_id integer
);


ALTER TABLE public.build OWNER TO postgres;

--
-- Name: business; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.business (
    id integer DEFAULT nextval('public.id'::regclass),
    description text,
    discount real
);


ALTER TABLE public.business OWNER TO postgres;

--
-- Name: cargo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cargo (
    id integer NOT NULL,
    trans_id integer NOT NULL,
    package text,
    netweight double precision,
    grossweight double precision,
    volume double precision
);


ALTER TABLE public.cargo OWNER TO postgres;

--
-- Name: chart; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.chart (
    id integer DEFAULT nextval('public.id'::regclass),
    accno text NOT NULL,
    description text,
    charttype character(1) DEFAULT 'A'::bpchar,
    category character(1),
    link text,
    gifi_accno text,
    contra boolean DEFAULT false,
    allow_gl boolean DEFAULT true,
    symbol_link character varying(128),
    parent_id integer
);


ALTER TABLE public.chart OWNER TO postgres;

--
-- Name: chat; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.chat (
    id integer NOT NULL,
    trans_id integer NOT NULL,
    message character varying(1024) NOT NULL,
    employee_id integer NOT NULL,
    creation_date timestamp without time zone NOT NULL
);


ALTER TABLE public.chat OWNER TO postgres;

--
-- Name: chat_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.chat_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.chat_id_seq OWNER TO postgres;

--
-- Name: chat_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.chat_id_seq OWNED BY public.chat.id;


--
-- Name: contactid; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.contactid
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.contactid OWNER TO postgres;

--
-- Name: contact; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.contact (
    id integer DEFAULT nextval('public.contactid'::regclass) NOT NULL,
    trans_id integer NOT NULL,
    salutation character varying(32),
    firstname character varying(32),
    lastname character varying(32),
    contacttitle character varying(32),
    occupation character varying(32),
    phone character varying(20),
    fax character varying(20),
    mobile character varying(20),
    email text,
    gender character(1) DEFAULT 'M'::bpchar,
    parent_id integer,
    typeofcontact character varying(20)
);


ALTER TABLE public.contact OWNER TO postgres;

--
-- Name: credits; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.credits (
    id integer NOT NULL,
    reference text,
    description text,
    transdate date,
    accno text,
    amount numeric(12,2)
);


ALTER TABLE public.credits OWNER TO postgres;

--
-- Name: credits_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.credits_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.credits_id_seq OWNER TO postgres;

--
-- Name: credits_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.credits_id_seq OWNED BY public.credits.id;


--
-- Name: curr; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.curr (
    rn integer,
    curr character(3) NOT NULL,
    "precision" smallint
);


ALTER TABLE public.curr OWNER TO postgres;

--
-- Name: customer; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customer (
    id integer DEFAULT nextval('public.id'::regclass) NOT NULL,
    name character varying(128),
    contact character varying(64),
    phone character varying(20),
    fax character varying(20),
    email text,
    notes text,
    terms smallint DEFAULT 0,
    taxincluded boolean DEFAULT false,
    customernumber character varying(32),
    cc text,
    bcc text,
    business_id integer,
    taxnumber character varying(32),
    sic_code character varying(6),
    discount real,
    creditlimit double precision DEFAULT 0,
    iban character varying(34),
    bic character varying(11),
    employee_id integer,
    language_code character varying(6),
    pricegroup_id integer,
    curr character(3),
    startdate date,
    enddate date,
    arap_accno_id integer,
    payment_accno_id integer,
    discount_accno_id integer,
    cashdiscount real,
    discountterms smallint,
    threshold double precision,
    paymentmethod_id integer,
    remittancevoucher boolean,
    dispatch_id integer,
    last_modified timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    income_accno_id integer,
    payment_clearing_accno_id integer,
    reminderstop boolean DEFAULT false
);


ALTER TABLE public.customer OWNER TO postgres;

--
-- Name: customercart; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customercart (
    cart_id character varying(32),
    customer_id integer,
    parts_id integer,
    qty double precision DEFAULT 0,
    price double precision DEFAULT 0,
    taxaccounts text
);


ALTER TABLE public.customercart OWNER TO postgres;

--
-- Name: customerloginid; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.customerloginid
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.customerloginid OWNER TO postgres;

--
-- Name: customerlogin; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customerlogin (
    id integer DEFAULT nextval('public.customerloginid'::regclass) NOT NULL,
    login character varying(100),
    passwd character(32),
    session character(32),
    session_exp character varying(20),
    customer_id integer
);


ALTER TABLE public.customerlogin OWNER TO postgres;

--
-- Name: customertax; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customertax (
    customer_id integer,
    chart_id integer
);


ALTER TABLE public.customertax OWNER TO postgres;

--
-- Name: debits; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.debits (
    id integer NOT NULL,
    reference text,
    description text,
    transdate date,
    accno text,
    amount numeric(12,2)
);


ALTER TABLE public.debits OWNER TO postgres;

--
-- Name: debits_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.debits_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.debits_id_seq OWNER TO postgres;

--
-- Name: debits_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.debits_id_seq OWNED BY public.debits.id;


--
-- Name: debitscredits; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.debitscredits (
    id integer NOT NULL,
    reference text,
    description text,
    transdate date,
    debit_accno text,
    credit_accno text,
    amount numeric(12,2)
);


ALTER TABLE public.debitscredits OWNER TO postgres;

--
-- Name: debitscredits_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.debitscredits_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.debitscredits_id_seq OWNER TO postgres;

--
-- Name: debitscredits_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.debitscredits_id_seq OWNED BY public.debitscredits.id;


--
-- Name: defaults; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.defaults (
    fldname text,
    fldvalue text
);


ALTER TABLE public.defaults OWNER TO postgres;

--
-- Name: department; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.department (
    id integer DEFAULT nextval('public.id'::regclass),
    description text,
    role character(1) DEFAULT 'P'::bpchar
);


ALTER TABLE public.department OWNER TO postgres;

--
-- Name: dispatch; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dispatch (
    id integer DEFAULT nextval('public.id'::regclass),
    description text
);


ALTER TABLE public.dispatch OWNER TO postgres;

--
-- Name: dpt_trans; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dpt_trans (
    trans_id integer,
    department_id integer
);


ALTER TABLE public.dpt_trans OWNER TO postgres;

--
-- Name: employee; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.employee (
    id integer DEFAULT nextval('public.id'::regclass),
    login text,
    name character varying(64),
    address1 character varying(64),
    address2 character varying(64),
    city character varying(64),
    state character varying(32),
    zipcode character varying(32),
    country character varying(32),
    workphone character varying(20),
    workfax character varying(20),
    workmobile character varying(20),
    homephone character varying(20),
    startdate date DEFAULT CURRENT_DATE,
    enddate date,
    notes text,
    role character varying(20),
    sales boolean DEFAULT false,
    email text,
    ssn character varying(20),
    iban character varying(34),
    bic character varying(11),
    managerid integer,
    employeenumber character varying(32),
    dob date,
    closedto date
);


ALTER TABLE public.employee OWNER TO postgres;

--
-- Name: exchangerate; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.exchangerate (
    curr character(3),
    transdate date,
    buy double precision,
    sell double precision
);


ALTER TABLE public.exchangerate OWNER TO postgres;

--
-- Name: exported_payment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.exported_payment (
    id integer NOT NULL,
    banking_export_event_id bigint NOT NULL,
    rma_payment_id integer,
    payload jsonb NOT NULL,
    export_instruction_id text NOT NULL
);


ALTER TABLE public.exported_payment OWNER TO postgres;

--
-- Name: exported_payment_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.exported_payment_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.exported_payment_id_seq OWNER TO postgres;

--
-- Name: exported_payment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.exported_payment_id_seq OWNED BY public.exported_payment.id;


--
-- Name: fifo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fifo (
    trans_id integer,
    transdate date,
    parts_id integer,
    qty double precision,
    costprice double precision,
    sellprice double precision,
    warehouse_id integer,
    invoice_id integer
);


ALTER TABLE public.fifo OWNER TO postgres;

--
-- Name: filtered; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.filtered (
    trans_id integer,
    entry_id integer DEFAULT 0,
    entry_id2 integer DEFAULT 0,
    debit double precision DEFAULT 0,
    credit double precision DEFAULT 0
);


ALTER TABLE public.filtered OWNER TO postgres;

--
-- Name: financial_year; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.financial_year (
    id integer NOT NULL,
    start_date date,
    end_date date,
    status public.financial_year_status_enum,
    yearend_id integer
);


ALTER TABLE public.financial_year OWNER TO postgres;

--
-- Name: financial_year_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.financial_year_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.financial_year_id_seq OWNER TO postgres;

--
-- Name: financial_year_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.financial_year_id_seq OWNED BY public.financial_year.id;


--
-- Name: gifi; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.gifi (
    accno text,
    description text
);


ALTER TABLE public.gifi OWNER TO postgres;

--
-- Name: gl; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.gl (
    id integer DEFAULT nextval('public.id'::regclass),
    reference text,
    description text,
    transdate date DEFAULT CURRENT_DATE,
    employee_id integer,
    notes text,
    department_id integer DEFAULT 0,
    approved boolean DEFAULT true,
    curr character(3),
    exchangerate double precision,
    ts timestamp without time zone DEFAULT now(),
    onhold boolean
);


ALTER TABLE public.gl OWNER TO postgres;

--
-- Name: gl_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.gl_log (
    id integer,
    reference text,
    description text,
    transdate date,
    employee_id integer,
    notes text,
    department_id integer,
    approved boolean,
    curr character(3),
    exchangerate double precision,
    ts timestamp without time zone,
    onhold boolean
);


ALTER TABLE public.gl_log OWNER TO postgres;

--
-- Name: gl_log_deleted; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.gl_log_deleted (
    id integer,
    reference text,
    description text,
    transdate date,
    employee_id integer,
    notes text,
    department_id integer,
    approved boolean,
    curr character(3),
    exchangerate double precision,
    ts timestamp without time zone,
    onhold boolean
);


ALTER TABLE public.gl_log_deleted OWNER TO postgres;

--
-- Name: imported_balance; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.imported_balance (
    id integer NOT NULL,
    banking_import_event_id integer NOT NULL,
    balance_type text NOT NULL,
    amount double precision NOT NULL,
    balance_currency text NOT NULL,
    credit_debit text NOT NULL,
    date date NOT NULL
);


ALTER TABLE public.imported_balance OWNER TO postgres;

--
-- Name: imported_balance_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.imported_balance ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.imported_balance_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: imported_transaction; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.imported_transaction (
    id integer NOT NULL,
    parent_imported_transaction_id integer,
    banking_import_event_id integer NOT NULL,
    amount double precision NOT NULL,
    currency text NOT NULL,
    credit_debit text NOT NULL,
    booking_date date NOT NULL,
    status text NOT NULL,
    reversal_indicator boolean,
    transaction_ref text,
    bank_domain_code text,
    bank_family_code text,
    bank_sub_family_code text,
    transaction_text text,
    origin_amount double precision,
    origin_currency character varying(3),
    exchange_rate double precision,
    related_party_name text,
    related_party_address jsonb,
    end_to_end_id text,
    purpose text,
    remittance_ref text,
    remittance_type text,
    hashcode integer NOT NULL,
    suppression text DEFAULT 'NONE'::text NOT NULL
);


ALTER TABLE public.imported_transaction OWNER TO postgres;

--
-- Name: imported_transaction_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.imported_transaction ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.imported_transaction_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: imported_transaction_to_booking; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.imported_transaction_to_booking (
    imported_transaction_id integer NOT NULL,
    booking_id integer NOT NULL,
    ledger_type character varying(2) NOT NULL,
    exchange_rate double precision
);


ALTER TABLE public.imported_transaction_to_booking OWNER TO postgres;

--
-- Name: inventoryid; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.inventoryid
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.inventoryid OWNER TO postgres;

--
-- Name: inventory; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.inventory (
    id integer DEFAULT nextval('public.inventoryid'::regclass),
    warehouse_id integer,
    parts_id integer,
    trans_id integer,
    orderitems_id integer,
    qty double precision,
    shippingdate date,
    employee_id integer,
    department_id integer,
    warehouse_id2 integer,
    serialnumber text,
    itemnotes text,
    cost double precision,
    linetype character(1) DEFAULT '0'::bpchar,
    description text,
    invoice_id integer,
    cogs double precision
);


ALTER TABLE public.inventory OWNER TO postgres;

--
-- Name: invoiceid; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.invoiceid
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.invoiceid OWNER TO postgres;

--
-- Name: invoice; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.invoice (
    id integer DEFAULT nextval('public.invoiceid'::regclass) NOT NULL,
    trans_id integer,
    parts_id integer,
    description text,
    qty double precision,
    allocated double precision,
    sellprice double precision,
    fxsellprice double precision,
    discount real,
    assemblyitem boolean DEFAULT false,
    unit character varying(5),
    project_id integer,
    deliverydate date,
    serialnumber text,
    itemnotes text,
    lineitemdetail boolean,
    ordernumber text,
    ponumber text,
    transdate date,
    lastcost double precision,
    warehouse_id integer,
    cogs double precision
);


ALTER TABLE public.invoice OWNER TO postgres;

--
-- Name: invoice_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.invoice_log (
    id integer,
    trans_id integer,
    parts_id integer,
    description text,
    qty double precision,
    allocated double precision,
    sellprice double precision,
    fxsellprice double precision,
    discount real,
    assemblyitem boolean,
    unit character varying(5),
    project_id integer,
    deliverydate date,
    serialnumber text,
    itemnotes text,
    lineitemdetail boolean,
    ordernumber text,
    ponumber text,
    transdate date,
    lastcost double precision,
    warehouse_id integer,
    cogs double precision,
    ts timestamp without time zone DEFAULT now()
);


ALTER TABLE public.invoice_log OWNER TO postgres;

--
-- Name: invoice_log_deleted; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.invoice_log_deleted (
    trans_id integer,
    chart_id integer,
    amount double precision,
    transdate date,
    source text,
    approved boolean,
    fx_transaction boolean,
    project_id integer,
    memo text,
    id integer,
    cleared date,
    vr_id integer,
    entry_id integer,
    tax text,
    taxamount double precision,
    tax_chart_id integer,
    ts timestamp without time zone DEFAULT now()
);


ALTER TABLE public.invoice_log_deleted OWNER TO postgres;

--
-- Name: invoicetax; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.invoicetax (
    trans_id integer,
    invoice_id integer,
    chart_id integer,
    taxamount double precision,
    amount double precision
);


ALTER TABLE public.invoicetax OWNER TO postgres;

--
-- Name: jcitemsid; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.jcitemsid
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.jcitemsid OWNER TO postgres;

--
-- Name: jcitems; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.jcitems (
    id integer DEFAULT nextval('public.jcitemsid'::regclass),
    project_id integer,
    parts_id integer,
    description text,
    qty double precision,
    allocated double precision,
    sellprice double precision,
    fxsellprice double precision,
    serialnumber text,
    checkedin timestamp with time zone,
    checkedout timestamp with time zone,
    employee_id integer,
    notes text
);


ALTER TABLE public.jcitems OWNER TO postgres;

--
-- Name: language; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.language (
    code character varying(6),
    description text
);


ALTER TABLE public.language OWNER TO postgres;

--
-- Name: lastused; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lastused (
    id integer NOT NULL,
    report character varying(40),
    cols text,
    login character varying(255)
);


ALTER TABLE public.lastused OWNER TO postgres;

--
-- Name: lastused_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.lastused_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.lastused_id_seq OWNER TO postgres;

--
-- Name: lastused_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.lastused_id_seq OWNED BY public.lastused.id;


--
-- Name: makemodel; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.makemodel (
    parts_id integer,
    make text,
    model text
);


ALTER TABLE public.makemodel OWNER TO postgres;

--
-- Name: oe; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.oe (
    id integer DEFAULT nextval('public.id'::regclass),
    ordnumber text,
    transdate date DEFAULT CURRENT_DATE,
    vendor_id integer,
    customer_id integer,
    amount double precision,
    netamount double precision,
    reqdate date,
    taxincluded boolean,
    shippingpoint text,
    notes text,
    curr character(3),
    employee_id integer,
    closed boolean DEFAULT false,
    quotation boolean DEFAULT false,
    quonumber text,
    intnotes text,
    department_id integer DEFAULT 0,
    shipvia text,
    language_code character varying(6),
    ponumber text,
    terms smallint DEFAULT 0,
    waybill text,
    warehouse_id integer,
    description text,
    aa_id integer,
    exchangerate double precision
);


ALTER TABLE public.oe OWNER TO postgres;

--
-- Name: orderitemsid; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.orderitemsid
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.orderitemsid OWNER TO postgres;

--
-- Name: orderitems; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.orderitems (
    id integer DEFAULT nextval('public.orderitemsid'::regclass),
    trans_id integer,
    parts_id integer,
    description text,
    qty double precision,
    sellprice double precision,
    discount real,
    unit character varying(5),
    project_id integer,
    reqdate date,
    ship double precision,
    serialnumber text,
    itemnotes text,
    lineitemdetail boolean,
    ordernumber text,
    ponumber text
);


ALTER TABLE public.orderitems OWNER TO postgres;

--
-- Name: parts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.parts (
    id integer DEFAULT nextval('public.id'::regclass),
    partnumber text,
    description text,
    unit character varying(5),
    listprice double precision,
    sellprice double precision,
    lastcost double precision,
    priceupdate date DEFAULT CURRENT_DATE,
    weight double precision,
    onhand double precision DEFAULT 0,
    notes text,
    makemodel boolean DEFAULT false,
    assembly boolean DEFAULT false,
    alternate boolean DEFAULT false,
    rop double precision,
    inventory_accno_id integer,
    income_accno_id integer,
    expense_accno_id integer,
    bin text,
    obsolete boolean DEFAULT false,
    bom boolean DEFAULT false,
    image text,
    drawing text,
    microfiche text,
    partsgroup_id integer,
    project_id integer,
    avgcost double precision,
    tariff_hscode text,
    countryorigin text,
    barcode text,
    toolnumber text
);


ALTER TABLE public.parts OWNER TO postgres;

--
-- Name: partsattr; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.partsattr (
    parts_id integer,
    hotnew character varying(3)
);


ALTER TABLE public.partsattr OWNER TO postgres;

--
-- Name: partscustomer; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.partscustomer (
    parts_id integer,
    customer_id integer,
    pricegroup_id integer,
    pricebreak double precision,
    sellprice double precision,
    validfrom date,
    validto date,
    curr character(3)
);


ALTER TABLE public.partscustomer OWNER TO postgres;

--
-- Name: partsgroup; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.partsgroup (
    id integer DEFAULT nextval('public.id'::regclass),
    partsgroup text,
    pos boolean DEFAULT true
);


ALTER TABLE public.partsgroup OWNER TO postgres;

--
-- Name: partstax; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.partstax (
    parts_id integer,
    chart_id integer
);


ALTER TABLE public.partstax OWNER TO postgres;

--
-- Name: partsvendor; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.partsvendor (
    vendor_id integer,
    parts_id integer,
    partnumber text,
    leadtime smallint,
    lastcost double precision,
    curr character(3)
);


ALTER TABLE public.partsvendor OWNER TO postgres;

--
-- Name: payment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payment (
    id integer NOT NULL,
    trans_id integer NOT NULL,
    exchangerate double precision DEFAULT 1,
    paymentmethod_id integer
);


ALTER TABLE public.payment OWNER TO postgres;

--
-- Name: paymentmethod; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.paymentmethod (
    id integer DEFAULT nextval('public.id'::regclass) NOT NULL,
    description text,
    fee double precision,
    rn integer
);


ALTER TABLE public.paymentmethod OWNER TO postgres;

--
-- Name: pricegroup; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pricegroup (
    id integer DEFAULT nextval('public.id'::regclass),
    pricegroup text
);


ALTER TABLE public.pricegroup OWNER TO postgres;

--
-- Name: project; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.project (
    id integer DEFAULT nextval('public.id'::regclass),
    projectnumber text,
    description text,
    startdate date,
    enddate date,
    parts_id integer,
    production double precision DEFAULT 0,
    completed double precision DEFAULT 0,
    customer_id integer
);


ALTER TABLE public.project OWNER TO postgres;

--
-- Name: recurring; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.recurring (
    id integer,
    reference text,
    startdate date,
    nextdate date,
    enddate date,
    repeat smallint,
    unit character varying(6),
    howmany integer,
    payment boolean DEFAULT false,
    description text
);


ALTER TABLE public.recurring OWNER TO postgres;

--
-- Name: recurringemail; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.recurringemail (
    id integer,
    formname text,
    format text,
    message text
);


ALTER TABLE public.recurringemail OWNER TO postgres;

--
-- Name: recurringprint; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.recurringprint (
    id integer,
    formname text,
    format text,
    printer text
);


ALTER TABLE public.recurringprint OWNER TO postgres;

--
-- Name: report; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.report (
    reportid integer DEFAULT nextval('public.id'::regclass) NOT NULL,
    reportcode text,
    reportdescription text,
    login text
);


ALTER TABLE public.report OWNER TO postgres;

--
-- Name: reportvars; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reportvars (
    reportid integer NOT NULL,
    reportvariable text,
    reportvalue text
);


ALTER TABLE public.reportvars OWNER TO postgres;

--
-- Name: search_irrelevant_words; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.search_irrelevant_words (
    id integer NOT NULL,
    search_target text NOT NULL,
    word text NOT NULL
);


ALTER TABLE public.search_irrelevant_words OWNER TO postgres;

--
-- Name: search_irrelevant_words_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.search_irrelevant_words_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.search_irrelevant_words_id_seq OWNER TO postgres;

--
-- Name: search_irrelevant_words_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.search_irrelevant_words_id_seq OWNED BY public.search_irrelevant_words.id;


--
-- Name: semaphore; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.semaphore (
    id integer,
    login text,
    module text,
    expires character varying(10)
);


ALTER TABLE public.semaphore OWNER TO postgres;

--
-- Name: shipto; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.shipto (
    trans_id integer,
    shiptoname character varying(64),
    shiptoaddress1 character varying(64),
    shiptoaddress2 character varying(64),
    shiptocity character varying(64),
    shiptostate character varying(32),
    shiptozipcode character varying(32),
    shiptocountry character varying(32),
    shiptocontact character varying(64),
    shiptophone character varying(20),
    shiptofax character varying(20),
    shiptoemail text
);


ALTER TABLE public.shipto OWNER TO postgres;

--
-- Name: sic; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sic (
    code character varying(6),
    sictype character(1),
    description text
);


ALTER TABLE public.sic OWNER TO postgres;

--
-- Name: status; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.status (
    trans_id integer,
    formname text,
    printed boolean DEFAULT false,
    emailed boolean DEFAULT false,
    spoolfile text
);


ALTER TABLE public.status OWNER TO postgres;

--
-- Name: tax; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tax (
    chart_id integer,
    rate double precision,
    taxnumber text,
    validto date,
    reversecharge_id integer,
    vatkey character varying(5),
    formdigit integer DEFAULT 0,
    validfrom date,
    id integer NOT NULL,
    inactive boolean DEFAULT false
);


ALTER TABLE public.tax OWNER TO postgres;

--
-- Name: tax_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tax_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tax_id_seq OWNER TO postgres;

--
-- Name: tax_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tax_id_seq OWNED BY public.tax.id;


--
-- Name: translation; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.translation (
    trans_id integer,
    language_code character varying(6),
    description text
);


ALTER TABLE public.translation OWNER TO postgres;

--
-- Name: trf; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.trf (
    id integer DEFAULT nextval('public.id'::regclass) NOT NULL,
    transdate date,
    trfnumber text,
    description text,
    notes text,
    department_id integer,
    from_warehouse_id integer,
    to_warehouse_id integer DEFAULT 0,
    employee_id integer DEFAULT 0,
    delivereddate date
);


ALTER TABLE public.trf OWNER TO postgres;

--
-- Name: vat_settlement; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.vat_settlement (
    id integer NOT NULL,
    vat_form_id integer,
    period_from date,
    period_to date,
    creation_date timestamp without time zone,
    data json,
    xml bytea,
    type public.settlement_type_enum,
    meldecenter_data json
);


ALTER TABLE public.vat_settlement OWNER TO postgres;

--
-- Name: vat_settlement_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.vat_settlement_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.vat_settlement_id_seq OWNER TO postgres;

--
-- Name: vat_settlement_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.vat_settlement_id_seq OWNED BY public.vat_settlement.id;


--
-- Name: vendor; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.vendor (
    id integer DEFAULT nextval('public.id'::regclass) NOT NULL,
    name character varying(128),
    contact character varying(64),
    phone character varying(20),
    fax character varying(20),
    email text,
    notes text,
    terms smallint DEFAULT 0,
    taxincluded boolean DEFAULT false,
    vendornumber character varying(32),
    cc text,
    bcc text,
    gifi_accno character varying(30),
    business_id integer,
    taxnumber character varying(32),
    sic_code character varying(6),
    discount real,
    creditlimit double precision DEFAULT 0,
    iban character varying(34),
    bic character varying(11),
    employee_id integer,
    language_code character varying(6),
    pricegroup_id integer,
    curr character(3),
    startdate date,
    enddate date,
    arap_accno_id integer,
    payment_accno_id integer,
    discount_accno_id integer,
    cashdiscount real,
    discountterms smallint,
    threshold double precision,
    paymentmethod_id integer,
    remittancevoucher boolean,
    dispatch_id integer,
    last_modified timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    expense_accno_id integer,
    early_payment_discount numeric(5,4),
    payment_clearing_accno_id integer,
    reminderstop boolean DEFAULT false
);


ALTER TABLE public.vendor OWNER TO postgres;

--
-- Name: vendortax; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.vendortax (
    vendor_id integer,
    chart_id integer
);


ALTER TABLE public.vendortax OWNER TO postgres;

--
-- Name: vr; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.vr (
    br_id integer,
    trans_id integer NOT NULL,
    id integer DEFAULT nextval('public.id'::regclass) NOT NULL,
    vouchernumber text
);


ALTER TABLE public.vr OWNER TO postgres;

--
-- Name: warehouse; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.warehouse (
    id integer DEFAULT nextval('public.id'::regclass),
    description text
);


ALTER TABLE public.warehouse OWNER TO postgres;

--
-- Name: xabschluss; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.xabschluss (
    id integer NOT NULL,
    xml text,
    data jsonb,
    status text DEFAULT 'NEW'::text
);


ALTER TABLE public.xabschluss OWNER TO postgres;

--
-- Name: TABLE xabschluss; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.xabschluss IS 'nagebootst door rma_create.pl (testset PyBalans)';


--
-- Name: xabschluss_history; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.xabschluss_history (
    id integer NOT NULL,
    xml text,
    data jsonb
);


ALTER TABLE public.xabschluss_history OWNER TO postgres;

--
-- Name: xabschluss_history_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.xabschluss_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.xabschluss_history_id_seq OWNER TO postgres;

--
-- Name: xabschluss_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.xabschluss_history_id_seq OWNED BY public.xabschluss_history.id;


--
-- Name: xabschluss_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.xabschluss_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.xabschluss_id_seq OWNER TO postgres;

--
-- Name: xabschluss_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.xabschluss_id_seq OWNED BY public.xabschluss.id;


--
-- Name: xcontrolling_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.xcontrolling_log (
    id integer NOT NULL,
    trans_id integer NOT NULL,
    controlling_key character varying(32) NOT NULL,
    checked boolean DEFAULT false,
    checked_timestamp timestamp without time zone,
    checked_hash character varying(64),
    checked_login_ref integer,
    checked_by_ibp_user_id bigint
);


ALTER TABLE public.xcontrolling_log OWNER TO postgres;

--
-- Name: xcontrolling_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.xcontrolling_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.xcontrolling_log_id_seq OWNER TO postgres;

--
-- Name: xcontrolling_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.xcontrolling_log_id_seq OWNED BY public.xcontrolling_log.id;


--
-- Name: yearend; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.yearend (
    trans_id integer,
    transdate date,
    id integer NOT NULL
);


ALTER TABLE public.yearend OWNER TO postgres;

--
-- Name: yearend_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.yearend_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.yearend_id_seq OWNER TO postgres;

--
-- Name: yearend_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.yearend_id_seq OWNED BY public.yearend.id;


--
-- Name: banking_export_event id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.banking_export_event ALTER COLUMN id SET DEFAULT nextval('public.banking_export_event_id_seq'::regclass);


--
-- Name: blink_export_process id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blink_export_process ALTER COLUMN id SET DEFAULT nextval('public.blink_export_process_id_seq'::regclass);


--
-- Name: blink_export_process_log id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blink_export_process_log ALTER COLUMN id SET DEFAULT nextval('public.blink_export_process_log_id_seq'::regclass);


--
-- Name: blink_import_process id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blink_import_process ALTER COLUMN id SET DEFAULT nextval('public.blink_import_process_id_seq'::regclass);


--
-- Name: blink_import_process_log id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blink_import_process_log ALTER COLUMN id SET DEFAULT nextval('public.blink_import_process_log_id_seq'::regclass);


--
-- Name: booking_to_settlement id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.booking_to_settlement ALTER COLUMN id SET DEFAULT nextval('public.booking_to_settlement_id_seq'::regclass);


--
-- Name: chat id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.chat ALTER COLUMN id SET DEFAULT nextval('public.chat_id_seq'::regclass);


--
-- Name: credits id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.credits ALTER COLUMN id SET DEFAULT nextval('public.credits_id_seq'::regclass);


--
-- Name: debits id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.debits ALTER COLUMN id SET DEFAULT nextval('public.debits_id_seq'::regclass);


--
-- Name: debitscredits id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.debitscredits ALTER COLUMN id SET DEFAULT nextval('public.debitscredits_id_seq'::regclass);


--
-- Name: exported_payment id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.exported_payment ALTER COLUMN id SET DEFAULT nextval('public.exported_payment_id_seq'::regclass);


--
-- Name: financial_year id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.financial_year ALTER COLUMN id SET DEFAULT nextval('public.financial_year_id_seq'::regclass);


--
-- Name: lastused id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lastused ALTER COLUMN id SET DEFAULT nextval('public.lastused_id_seq'::regclass);


--
-- Name: search_irrelevant_words id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.search_irrelevant_words ALTER COLUMN id SET DEFAULT nextval('public.search_irrelevant_words_id_seq'::regclass);


--
-- Name: tax id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tax ALTER COLUMN id SET DEFAULT nextval('public.tax_id_seq'::regclass);


--
-- Name: vat_settlement id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vat_settlement ALTER COLUMN id SET DEFAULT nextval('public.vat_settlement_id_seq'::regclass);


--
-- Name: xabschluss id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.xabschluss ALTER COLUMN id SET DEFAULT nextval('public.xabschluss_id_seq'::regclass);


--
-- Name: xabschluss_history id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.xabschluss_history ALTER COLUMN id SET DEFAULT nextval('public.xabschluss_history_id_seq'::regclass);


--
-- Name: xcontrolling_log id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.xcontrolling_log ALTER COLUMN id SET DEFAULT nextval('public.xcontrolling_log_id_seq'::regclass);


--
-- Name: yearend id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.yearend ALTER COLUMN id SET DEFAULT nextval('public.yearend_id_seq'::regclass);


--
-- Data for Name: acc_trans; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.acc_trans (trans_id, chart_id, amount, transdate, source, approved, fx_transaction, project_id, memo, id, cleared, vr_id, entry_id, tax, taxamount, tax_chart_id, lineamount, imported_transaction_id) FROM stdin;
10260	10188	-1000	2025-04-01	\N	t	f	\N	\N	2	\N	\N	2	\N	\N	\N	0.00	\N
10260	10188	-360	2025-04-01	\N	t	f	\N	\N	3	\N	\N	3	\N	\N	\N	0.00	\N
10260	10248	1575.2	2025-04-01	\N	t	f	\N	\N	\N	\N	\N	4	\N	\N	\N	0.00	\N
10260	10019	-190	2025-04-01	\N	t	f	\N	\N	\N	\N	\N	5	\N	\N	\N	0.00	\N
10260	10017	-25.2	2025-04-01	\N	t	f	\N	\N	\N	\N	\N	6	\N	\N	\N	0.00	\N
10261	10254	445	2025-04-10	\N	t	f	\N	\N	4	\N	\N	7	\N	\N	\N	0.00	\N
10261	10188	250	2025-04-10	\N	t	f	\N	\N	2	\N	\N	8	\N	\N	\N	0.00	\N
10261	10253	250	2025-04-10	\N	t	f	\N	\N	5	\N	\N	9	\N	\N	\N	0.00	\N
10261	10188	120	2025-04-10	\N	t	f	\N	\N	3	\N	\N	10	\N	\N	\N	0.00	\N
10261	10135	-120	2025-04-10	\N	t	f	\N	\N	3	\N	\N	11	\N	\N	\N	0.00	\N
10261	10135	-250	2025-04-10	\N	t	f	\N	\N	2	\N	\N	12	\N	\N	\N	0.00	\N
10261	10011	-797.05	2025-04-10	\N	t	f	\N	\N	\N	\N	\N	13	\N	\N	\N	0.00	\N
10261	10252	17.5	2025-04-10	\N	t	f	\N	\N	\N	\N	\N	14	\N	\N	\N	0.00	\N
10261	10022	84.55	2025-04-10	\N	t	f	\N	\N	\N	\N	\N	15	\N	\N	\N	0.00	\N
10261	10011	797.05	2025-04-20	\N	t	f	\N	\N	\N	\N	\N	16	\N	\N	\N	0.00	\N
10261	10010	-797.05	2025-04-20	Bank 0420	t	f	\N		1	\N	\N	17	\N	\N	\N	0.00	\N
\.


--
-- Data for Name: acc_trans_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.acc_trans_log (trans_id, chart_id, amount, transdate, source, approved, fx_transaction, project_id, memo, id, cleared, vr_id, entry_id, tax, taxamount, tax_chart_id, ts, lineamount) FROM stdin;
\.


--
-- Data for Name: acc_trans_log_deleted; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.acc_trans_log_deleted (trans_id, chart_id, amount, transdate, source, approved, fx_transaction, project_id, memo, id, cleared, vr_id, entry_id, tax, taxamount, tax_chart_id, ts, lineamount) FROM stdin;
\.


--
-- Data for Name: address; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.address (id, trans_id, address1, address2, city, state, zipcode, country, post_office, is_migrated) FROM stdin;
2	10256	Alexanderplatz 1		Berlin		10178	DE		t
3	10257	Hafenstraße 9		Hamburg		20457	DE		t
\.


--
-- Data for Name: ap; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ap (id, invnumber, transdate, vendor_id, taxincluded, amount, netamount, paid, datepaid, duedate, invoice, ordnumber, curr, notes, employee_id, till, quonumber, intnotes, department_id, shipvia, language_code, ponumber, shippingpoint, terms, approved, cashdiscount, discountterms, waybill, warehouse_id, description, onhold, exchangerate, dcn, bank_id, paymentmethod_id, fxamount, fxpaid, linetax, ts) FROM stdin;
10260	GH-1001	2025-04-01	10257	f	1575.2	1360	0	\N	2025-05-01	t		EUR		0	\N			0		\N			30	t	0	0		10255		f	1		10009	0	1575.2	0	f	2026-10-16 15:23:46.00468
\.


--
-- Data for Name: ap_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ap_log (id, invnumber, transdate, vendor_id, taxincluded, amount, netamount, paid, datepaid, duedate, invoice, ordnumber, curr, notes, employee_id, till, quonumber, intnotes, department_id, shipvia, language_code, ponumber, shippingpoint, terms, approved, cashdiscount, discountterms, waybill, warehouse_id, description, onhold, exchangerate, dcn, bank_id, paymentmethod_id, fxamount, fxpaid, linetax, ts) FROM stdin;
\.


--
-- Data for Name: ap_log_deleted; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ap_log_deleted (id, invnumber, transdate, vendor_id, taxincluded, amount, netamount, paid, datepaid, duedate, invoice, ordnumber, curr, notes, employee_id, till, quonumber, intnotes, department_id, shipvia, language_code, ponumber, shippingpoint, terms, approved, cashdiscount, discountterms, waybill, warehouse_id, description, onhold, exchangerate, dcn, bank_id, paymentmethod_id, fxamount, fxpaid, linetax, ts) FROM stdin;
\.


--
-- Data for Name: ar; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ar (id, invnumber, transdate, customer_id, taxincluded, amount, netamount, paid, datepaid, duedate, invoice, shippingpoint, terms, notes, curr, ordnumber, employee_id, till, quonumber, intnotes, department_id, shipvia, language_code, ponumber, approved, cashdiscount, discountterms, waybill, warehouse_id, description, onhold, exchangerate, dcn, bank_id, paymentmethod_id, fxamount, fxpaid, linetax, ts) FROM stdin;
10261	2025-001	2025-04-10	10256	f	797.05	695	797.05	2025-04-20	2025-04-24	t		14		EUR		0	\N			0		\N		t	0	0		10255		f	1	\N	10010	0	797.05	797.05	f	2026-10-16 15:23:47.792417
\.


--
-- Data for Name: ar_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ar_log (id, invnumber, transdate, customer_id, taxincluded, amount, netamount, paid, datepaid, duedate, invoice, shippingpoint, terms, notes, curr, ordnumber, employee_id, till, quonumber, intnotes, department_id, shipvia, language_code, ponumber, approved, cashdiscount, discountterms, waybill, warehouse_id, description, onhold, exchangerate, dcn, bank_id, paymentmethod_id, fxamount, fxpaid, linetax, ts) FROM stdin;
\.


--
-- Data for Name: ar_log_deleted; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ar_log_deleted (id, invnumber, transdate, customer_id, taxincluded, amount, netamount, paid, datepaid, duedate, invoice, shippingpoint, terms, notes, curr, ordnumber, employee_id, till, quonumber, intnotes, department_id, shipvia, language_code, ponumber, approved, cashdiscount, discountterms, waybill, warehouse_id, description, onhold, exchangerate, dcn, bank_id, paymentmethod_id, fxamount, fxpaid, linetax, ts) FROM stdin;
\.


--
-- Data for Name: assembly; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.assembly (id, parts_id, qty, bom, adj, aid) FROM stdin;
\.


--
-- Data for Name: audittrail; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.audittrail (trans_id, tablename, reference, formname, action, transdate, employee_id) FROM stdin;
\.


--
-- Data for Name: bank; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.bank (id, name, iban, bic, address_id, dcn, rvc, membernumber, qriban, strdbkginf, invdescriptionqr) FROM stdin;
\.


--
-- Data for Name: bank_account; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.bank_account (id, bic, iban, account, bank, branch, country, country_iso, city, state, zip, address, description, chart_id, inactive, currency, blink_permission_id, blink_account_id) FROM stdin;
\.


--
-- Data for Name: banking_export_event; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.banking_export_event (id, status, bank_account_id, source_type, exported_when, is_manual, export_message_id, export_submission_id) FROM stdin;
\.


--
-- Data for Name: banking_import_event; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.banking_import_event (id, status, bank_account_id, imported_iban, imported_currency, imported_owner, total_credit, total_debit, transactions_count, imported_when, source_type, is_manual, filename, file_content, delegated_to) FROM stdin;
\.


--
-- Data for Name: blink_export_process; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.blink_export_process (id, bank_account_id, process_type, status, error, created_at, last_modified_at) FROM stdin;
\.


--
-- Data for Name: blink_export_process_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.blink_export_process_log (id, blink_export_process_id, processed_target_id, processed_payload, error, banking_export_event_id, correlation_id) FROM stdin;
\.


--
-- Data for Name: blink_import_process; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.blink_import_process (id, bank_account_id, status, error, created_at, last_modified_at) FROM stdin;
\.


--
-- Data for Name: blink_import_process_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.blink_import_process_log (id, blink_import_process_id, processed_target_id, processed_payload, error, banking_import_event_id, correlation_id) FROM stdin;
\.


--
-- Data for Name: booking_to_settlement; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.booking_to_settlement (id, booking_id, settlement_id) FROM stdin;
\.


--
-- Data for Name: br; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.br (id, batchnumber, description, batch, transdate, apprdate, amount, managerid, employee_id) FROM stdin;
\.


--
-- Data for Name: build; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.build (id, reference, transdate, department_id, warehouse_id, employee_id) FROM stdin;
\.


--
-- Data for Name: business; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.business (id, description, discount) FROM stdin;
\.


--
-- Data for Name: cargo; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cargo (id, trans_id, package, netweight, grossweight, volume) FROM stdin;
\.


--
-- Data for Name: chart; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.chart (id, accno, description, charttype, category, link, gifi_accno, contra, allow_gl, symbol_link, parent_id) FROM stdin;
10069	1360	Geldtransit Bank 1	A	A		1360	f	t	\N	\N
10167	4910	Porto	A	E	AP_amount	4910	f	t	\N	\N
10001	420	Büroeinrichtung	A	A		420	f	t	\N	\N
10002	430	Ladeneinrichtung	A	A		430	f	t	\N	\N
10003	440	Werkzeuge	A	A		440	f	t	\N	\N
10004	450	Einbauten	A	A		450	f	t	\N	\N
10005	460	Gerüst- und Schalungsmaterial	A	A		460	f	t	\N	\N
10006	480	Geringwertige Wirtschaftsgüter bis DM 800,-	A	A		480	f	t	\N	\N
10007	490	Sonstige Betriebs- und Geschäftsausstattung	A	A		490	f	t	\N	\N
10008	650	Verb. gg. Kreditinstituten - Restlaufz. größer 5 Jahre	A	L		650	f	t	\N	\N
10009	1000	Kasse	A	A	AR_paid:AP_paid	1000	f	t	\N	\N
10010	1200	Bank-Giro	A	A	AR_paid:AP_paid	1200	f	t	\N	\N
10011	1400	Forderungen aus Lief. und Leist. Kundengruppe 0	A	A	AR	1400	f	t	\N	\N
10012	1540	Steuerüberzahlungen	A	A	AR	1540	f	t	\N	\N
10013	1542	Steuererstattungsansprüche gg. anderen EU-Ländern	A	A	AR	1542	f	t	\N	\N
10014	1545	Umsatzsteuerforderungen	A	A	AR	1545	f	t	\N	\N
10015	1548	Vorsteuer im Folgejahr abziehbar	A	A	AR	1548	f	t	\N	\N
10016	1570	Abziehbare Vorsteuer	A	A	AR_tax:AP_tax	1570	f	t	\N	\N
10017	1571	Abziehbare Vorsteuer, 7%	A	A	AR_tax:AP_tax:IC_taxpart:IC_taxservice	1571	f	t	\N	\N
10018	1575	Abziehbare Vorsteuer, 16%	A	A	AR_tax:AP_tax:IC_taxpart:IC_taxservice	1575	f	t	\N	\N
10020	1577	Vorsteuer nach allg. Durchschnittssätzen UStVA KZ 63	A	A	AR_tax:AP_tax	1577	f	t	\N	\N
10021	1775	Umsatzsteuer, 16%	A	L	AR_tax:AP_tax:IC_taxpart:IC_taxservice	1775	f	t	\N	\N
10023	1780	Umsatzsteuer - Vorauszahlungen	A	L		1780	f	t	\N	\N
10024	1781	Umsatzsteuer - Vorauszahlungen 1/11	A	L		1781	f	t	\N	\N
10025	1782	Nachsteuer, UStVA KZ 65	A	L		1782	f	t	\N	\N
10026	1789	Umsatzsteuer laufendes Jahr	A	L		1789	f	t	\N	\N
10027	1790	Umsatzsteuer Vorjahr	A	L		1790	f	t	\N	\N
10028	1791	Umsatzsteuer frühere Jahre	A	L		1791	f	t	\N	\N
10029	1820	Sonderausg. beschr. abzugsf. (Privat Vollhaft./Einzelu.)	A	 		1820	f	t	\N	\N
10030	1830	Sonderausg. unbeschr. abzugsf. (Privat Vollhaft./Einzelu.)	A	 		1830	f	t	\N	\N
10031	1840	Privatspenden (Privat Vollhafter / Einzelunternehmer)	A	 		1840	f	t	\N	\N
10032	1850	Außergewöhnliche Belastungen (Privat Vollhaft. / Einzelunt.)	A	 		1850	f	t	\N	\N
10033	1890	Privateinlagen (Privat Vollhafter / Einzelunternehmer)	A	 		1890	f	t	\N	\N
10034	2010	Betriebsfremde Aufw. (soweit nicht außerordentlich)	A	 		2010	f	t	\N	\N
10035	2020	Periodenfremde Aufw. (soweit nicht außerordentlich)	A	 		2020	f	t	\N	\N
10036	2100	Zinsen und ähnliche Aufwendungen	A	 		2100	f	t	\N	\N
10037	2103	Steuerlich abzugsfähige, andere Nebenleistungen zu Steuern	A	 		2103	f	t	\N	\N
10038	2104	Steuerlich nicht abzugsfähige, andere Nebenleistungen zu Steuern	A	 		2104	f	t	\N	\N
10039	2107	Zinsaufwendungen §233a AO betriebliche Steuern	A	 		2107	f	t	\N	\N
10040	2108	Zinsaufw. §233a, §234, §237 AO Personenst. §8 GewStG	A	 		2108	f	t	\N	\N
10041	2109	Zinsaufwendungen an verbundene Unternehmen	A	 		2109	f	t	\N	\N
10042	2110	Zinsaufwendungen für kurzfristige Verbindlichkeiten	A	 		2110	f	t	\N	\N
10043	3410	Wareneingang, 16% Vorsteuer	A	 		3410	f	t	\N	\N
10044	3736	Erhaltene Skonti, 16% Vorsteuer	A	 		3736	f	t	\N	\N
10045	3740	Erhaltene Boni	A	 		3740	f	t	\N	\N
10046	3750	Erhaltene Boni,   7% Vorsteuer	A	 		3750	f	t	\N	\N
10047	3760	Erhaltene Boni, 15%+16% Vorsteuer	A	 		3760	f	t	\N	\N
10048	3762	Erhaltene Boni, 16% Vorsteuer	A	 		3762	f	t	\N	\N
10049	3764	Erhaltene Boni, 15% Vorsteuer	A	 		3764	f	t	\N	\N
10050	3800	Anschaffungsnebenkosten	A	 		3800	f	t	\N	\N
10051	3830	Leergut	A	 		3830	f	t	\N	\N
10052	3850	Zölle und Einfuhrabgaben	A	 		3850	f	t	\N	\N
10053	3960	Bestandsv. Roh-, Hilfs- u. Betriebsstoffe / bezogene Waren	A	 		3960	f	t	\N	\N
10054	3970	Bestand Roh-, Hilfs- und Betriebsstoffe	A	 		3970	f	t	\N	\N
10055	3980	Bestand Waren	A	 		3980	f	t	\N	\N
10056	3990	Verrechnete Stoffkosten	A	 		3990	f	t	\N	\N
10057	4000	Material- und Stoffverbrauch	A	E	AP_amount	4000	f	t	\N	\N
10058	4100	Löhne und Gehälter	A	E	AP_amount	4100	f	t	\N	\N
10059	4110	Löhne	A	E	AP_amount	4110	f	t	\N	\N
10060	4120	Gehälter	A	E	AP_amount	4120	f	t	\N	\N
10061	4124	Geschäftsführergehälter der GmbH-Gesellschafter	A	E	AP_amount	4124	f	t	\N	\N
10062	4125	Ehegattengehalt	A	E	AP_amount	4125	f	t	\N	\N
10063	4126	Tantiemen	A	E	AP_amount	4126	f	t	\N	\N
10064	4127	Geschäftsführergehälter	A	E	AP_amount	4127	f	t	\N	\N
10065	4128	Vergütungen an angestellte Mitunternehmer §15 EStG	A	E	AP_amount	4128	f	t	\N	\N
10066	4130	Gesetzliche soziale Aufwendungen	A	E	AP_amount	4130	f	t	\N	\N
10067	4137	Gesetzliche soziale Aufw. für Mitunternehmer §15 EStG	A	E	AP_amount	4137	f	t	\N	\N
10068	4138	Beiträge zur Berufsgenossenschaft	A	E	AP_amount	4138	f	t	\N	\N
10070	4140	Freiw. soziale Aufwendungen (lohnsteuerfrei)	A	E	AP_amount	4140	f	t	\N	\N
10071	4145	Freiw. soziale Aufwendungen (lohnsteuerpflichtig)	A	E	AP_amount	4145	f	t	\N	\N
10234	8950	Nicht steuerbare Umsätze	A	 		8950	f	t	\N	\N
10022	1776	Umsatzsteuer 19%	A	L	AR_tax:AP_tax:IC_taxpart:IC_taxservice	1776	f	t	\N	\N
10019	1576	Abziehbare Vorsteuer 19%	A	A	AR_tax:AP_tax:IC_taxpart:IC_taxservice	1576	f	t	\N	\N
10072	4149	Pauschale Lohnsteuer auf s. Bezüge (z.B. Fahrtkostenzuschuß)	A	E	AP_amount	4149	f	t	\N	\N
10073	4150	Krankengeldzuschüsse	A	E	AP_amount	4150	f	t	\N	\N
10074	4160	Versorgungskassen	A	E	AP_amount	4160	f	t	\N	\N
10075	4165	Aufwendungen für die Altersversorgung	A	E	AP_amount	4165	f	t	\N	\N
10076	4167	Pauschale Lohnsteuer auf s. Bezüge (z.B. Direktversicherung)	A	E	AP_amount	4167	f	t	\N	\N
10077	4168	Aufw. f. die Altersversorgung f. Mitunternehmer §15 EStG	A	E	AP_amount	4168	f	t	\N	\N
10078	4169	Aufwendungen für Unterstützung	A	E	AP_amount	4169	f	t	\N	\N
10079	4170	Vermögenswirksame Leistungen	A	E	AP_amount	4170	f	t	\N	\N
10080	4175	Fahrtkostenerstattung - Wohnung / Arbeitsstätte	A	E	AP_amount	4175	f	t	\N	\N
10081	4180	Bedienungsgelder	A	E	AP_amount	4180	f	t	\N	\N
10082	4190	Aushilfslöhne	A	E	AP_amount	4190	f	t	\N	\N
10083	4199	Lohnsteuer für Aushilfen	A	E	AP_amount	4199	f	t	\N	\N
10084	4200	Raumkosten	A	E	AP_amount	4200	f	t	\N	\N
10085	4210	Miete	A	E	AP_amount	4210	f	t	\N	\N
10086	4218	Gewerbesteuerlich zu berücks. Miete §8 GewStG	A	E	AP_amount	4218	f	t	\N	\N
10087	4219	Vergütung an Mitu. f. mietw. Überl. v. Wirtschaftsg. §15EStG	A	E	AP_amount	4219	f	t	\N	\N
10088	4220	Pacht	A	E	AP_amount	4220	f	t	\N	\N
10089	4228	Gewerbesteuerlich zu berücks. Pacht §8 GewStG	A	E	AP_amount	4228	f	t	\N	\N
10090	4229	Vergütung an Mitu. f. pachtw. Überl. v. Wirtschaftsg.§15EStG	A	E	AP_amount	4229	f	t	\N	\N
10091	4230	Heizung	A	E	AP_amount	4230	f	t	\N	\N
10092	4240	Gas, Strom, Wasser (Verwaltung, Vertrieb)	A	E	AP_amount	4240	f	t	\N	\N
10093	4250	Reinigung	A	E	AP_amount	4250	f	t	\N	\N
10094	4260	Instandhaltung betrieblicher Räume	A	E	AP_amount	4260	f	t	\N	\N
10095	4270	Abgaben für betrieblich genutzten Grundbesitz	A	E	AP_amount	4270	f	t	\N	\N
10096	4280	Sonstige Raumkosten	A	E	AP_amount	4280	f	t	\N	\N
10097	4320	Gewerbesteuer (Vorauszahlung)	A	E	AP_amount	4320	f	t	\N	\N
10098	4330	Gewerbeertragsteuer	A	E	AP_amount	4330	f	t	\N	\N
10099	4335	Gewerbekapitalsteuer	A	E	AP_amount	4335	f	t	\N	\N
10100	4340	Sonstige Betriebsteuern	A	E	AP_amount	4340	f	t	\N	\N
10101	4350	Verbrauchsteuer	A	E	AP_amount	4350	f	t	\N	\N
10102	4360	Versicherungen	A	E	AP_amount	4360	f	t	\N	\N
10103	4380	Beiträge	A	E	AP_amount	4380	f	t	\N	\N
10104	4390	Sonstige Abgaben	A	E	AP_amount	4390	f	t	\N	\N
10105	4396	Steuerlich abzugsfähige Verspätungszuschläge und Zwangsgelder	A	E	AP_amount	4396	f	t	\N	\N
10106	4397	Steuerlich nicht abzugsfähige Verspätungszuschläge und Zwangsgelder	A	E	AP_amount	4397	f	t	\N	\N
10107	4400	Besondere Kosten (zur freien Verfügung)	A	E	AP_amount	4400	f	t	\N	\N
10108	4500	Fahrzeugkosten	A	E	AP_amount	4500	f	t	\N	\N
10109	4510	Kfz-Steuern	A	E	AP_amount	4510	f	t	\N	\N
10110	4520	Kfz-Versicherungen	A	E	AP_amount	4520	f	t	\N	\N
10111	4530	Laufende Kfz-Betriebskosten	A	E	AP_amount	4530	f	t	\N	\N
10112	4540	Kfz-Reparaturen	A	E	AP_amount	4540	f	t	\N	\N
10113	4550	Garagenmieten	A	E	AP_amount	4550	f	t	\N	\N
10114	4570	Fremdfahrzeuge	A	E	AP_amount	4570	f	t	\N	\N
10115	4580	Sonstige Kfz-Kosten	A	E	AP_amount	4580	f	t	\N	\N
10116	4600	Werbe- und Reisekosten	A	E	AP_amount	4600	f	t	\N	\N
10117	4610	Werbekosten	A	E	AP_amount	4610	f	t	\N	\N
10118	4630	Geschenke bis DM 75,00	A	E	AP_amount	4630	f	t	\N	\N
10119	4635	Geschenke über DM 75,00	A	E	AP_amount	4635	f	t	\N	\N
10120	4638	Geschenke ausschließlich betrieblich genutzt	A	E	AP_amount	4638	f	t	\N	\N
10121	4640	Repräsentationskosten	A	E	AP_amount	4640	f	t	\N	\N
10122	4650	Bewirtungskosten	A	E	AP_amount	4650	f	t	\N	\N
10123	4653	Aufwerksamkeiten	A	E	AP_amount	4653	f	t	\N	\N
10124	4654	Nicht abzugsfähige Bewirtungskosten	A	E	AP_amount	4654	f	t	\N	\N
10125	4655	Nicht abzugsfähige Betriebsausgaben	A	E	AP_amount	4655	f	t	\N	\N
10126	4660	Reisekosten Arbeitnehmer	A	E	AP_amount	4660	f	t	\N	\N
10127	4666	Reisekost. Arbeitn., 12,3%/13,1% VSt  Verpfl.Mehr- / Übern.Aufw.	A	E	AP_amount	4666	f	t	\N	\N
10128	4667	Reisekost. Arbeitn., 9,8%/10,5% VSt Gesamtpauschal.	A	E	AP_amount	4667	f	t	\N	\N
10129	4670	Reisekosten Unternehmer	A	E	AP_amount	4670	f	t	\N	\N
10130	4675	Reisekosten Unternehmer, 9,8/10,5% VSt sonst.Gesamtpauschal.	A	E	AP_amount	4675	f	t	\N	\N
10131	4676	Reisekost. Untern., 12,3%/13,1% VSt Verpfl.Mehr- / Übern.Aufw.	A	E	AP_amount	4676	f	t	\N	\N
10132	4677	Reisekosten Unternehmer, 9,8%/10,5% VSt Verpfl.Mehraufw. Gesamtpauschal.	A	E	AP_amount	4677	f	t	\N	\N
10133	4678	Km-Geld Erstattung, Unternehmer, 5,7%/6,1% VSt	A	E	AP_amount	4678	f	t	\N	\N
10134	4685	Km-Geld-Erstattung, Arbeitnehmer  8,2%/8,7% VSt	A	E	AP_amount	4685	f	t	\N	\N
10135	4700	Kosten der Warenabgabe	A	E	AP_amount:IC_expense:IC_cogs	4700	f	t	\N	\N
10136	4710	Verpackungsmaterial	A	E	AP_amount	4710	f	t	\N	\N
10137	4730	Ausgangsfrachten	A	E	AP_amount	4730	f	t	\N	\N
10138	4750	Transportversicherungen	A	E	AP_amount	4750	f	t	\N	\N
10139	4760	Verkaufsprovisionen	A	E	AP_amount	4760	f	t	\N	\N
10140	4780	Fremdarbeiten	A	E	AP_amount	4780	f	t	\N	\N
10141	4790	Aufwand für Gewährleistungen	A	E	AP_amount	4790	f	t	\N	\N
10142	4800	Reparat. u. Inst. v. Maschinen u. technischen Anlagen	A	E	AP_amount	4800	f	t	\N	\N
10143	4805	Reparat. u. Inst. v. and. Anl. d. Betr.- u. Geschäftsausst.	A	E	AP_amount	4805	f	t	\N	\N
10144	4809	Sonstige Reparaturen und Instandhaltungen	A	E	AP_amount	4809	f	t	\N	\N
10145	4810	Mietleasing	A	E	AP_amount	4810	f	t	\N	\N
10146	4815	Kaufleasing	A	E	AP_amount	4815	f	t	\N	\N
10147	4820	Abschr. a. Aufw. f.d. Ingangs. u. Erw. des Geschäftsbetr.	A	E	AP_amount	4820	f	t	\N	\N
10148	4822	Abschr. a. immaterielle Vermögensgegenstände	A	E	AP_amount	4822	f	t	\N	\N
10149	4824	Abschreibung auf den Geschäfts- oder Firmenwert	A	E	AP_amount	4824	f	t	\N	\N
10150	4826	Außerplanm. Abschr. a. immaterielle Vermögensgegenstände	A	E	AP_amount	4826	f	t	\N	\N
10151	4830	Abschreibungen auf Sachanlagen	A	E	AP_amount	4830	f	t	\N	\N
10152	4840	Außerplanm. Abschreibungen auf Sachanlagen	A	E	AP_amount	4840	f	t	\N	\N
10153	4850	Abschr. a. Sachanl. aufgrund steuerl. Sondervorschriften	A	E	AP_amount	4850	f	t	\N	\N
10154	4855	Sofortabschreibung geringwertiger Wirtschaftsgüter	A	E	AP_amount	4855	f	t	\N	\N
10155	4860	Abschreibung auf aktivierte, geringwertige Wirtschaftsgüter	A	E	AP_amount	4860	f	t	\N	\N
10156	4865	Außerplanmäßige Abschr. a. aktivierte GWG	A	E	AP_amount	4865	f	t	\N	\N
10157	4870	Abschreibungen auf Finanzanlagen	A	E	AP_amount	4870	f	t	\N	\N
10158	4872	Abschr. aufgrund v. Verlustant. an Mitunt. §8 GewStG	A	E	AP_amount	4872	f	t	\N	\N
10159	4874	Abschr. a. Finanzanl. aufgrund steuerl. Sondervorschriften	A	E	AP_amount	4874	f	t	\N	\N
10160	4875	Abschreibungen auf Wertpapiere des Umlaufvermögens	A	E	AP_amount	4875	f	t	\N	\N
10161	4880	Abschr. a. Umlaufv. ohne Wertpapiere (soweit unübl. Höhe)	A	E	AP_amount	4880	f	t	\N	\N
10162	4882	Abschr. a. Umlaufv. steuerrechtl. bedingt (unübl. Höhe)	A	E	AP_amount	4882	f	t	\N	\N
10163	4887	Abschr. a. Umlaufv., steuerrechtlich bedingt (übl. Höhe)	A	E	AP_amount	4887	f	t	\N	\N
10164	4890	Vorwegn. künftiger Wertschw. im Umlaufv. (unübl. Höhe)	A	E	AP_amount	4890	f	t	\N	\N
10165	4900	Sonstige betriebliche Aufwendungen	A	E	AP_amount	4900	f	t	\N	\N
10166	4905	Sonstige Aufwendungen betrieblich und regelmäßig	A	E	AP_amount	4905	f	t	\N	\N
10168	4920	Telefon	A	E	AP_amount	4920	f	t	\N	\N
10169	4925	Telefax, Fernschreiber	A	E	AP_amount	4925	f	t	\N	\N
10170	4930	Bürobedarf	A	E	AP_amount	4930	f	t	\N	\N
10171	4940	Zeitschriften, Bücher	A	E	AP_amount	4940	f	t	\N	\N
10172	4945	Fortbildungskosten	A	E	AP_amount	4945	f	t	\N	\N
10173	4946	Freiwillige Sozialleistungen	A	E	AP_amount	4946	f	t	\N	\N
10174	4948	Vergütungen an freiberufliche Mitunternehmer §15 EStG	A	E	AP_amount	4948	f	t	\N	\N
10175	4950	Rechts- und Beratungskosten	A	E	AP_amount	4950	f	t	\N	\N
10176	4955	Buchführungskosten	A	E	AP_amount	4955	f	t	\N	\N
10177	4957	Abschluß- und Prüfungskosten	A	E	AP_amount	4957	f	t	\N	\N
10178	4960	Mieten für Einrichtungen	A	E	AP_amount	4960	f	t	\N	\N
10179	4968	Gewerbest. zu berücks. Miete f. Einrichtungen §8 GewStG	A	 		4968	f	t	\N	\N
10180	4969	Aufwendungen für Abraum- und Abfallbeseitigung	A	E	AP_amount	4969	f	t	\N	\N
10181	4970	Nebenkosten des Geldverkehrs	A	E	AP_amount	4970	f	t	\N	\N
10182	4980	Betriebsbedarf	A	E	AP_amount	4980	f	t	\N	\N
10183	4985	Werkzeuge und Kleingeräte	A	E	AP_amount	4985	f	t	\N	\N
10184	4996	Herstellungskosten	A	E	AP_amount	4996	f	t	\N	\N
10185	4997	Verwaltungskosten	A	E	AP_amount	4997	f	t	\N	\N
10186	4998	Vertriebskosten	A	E	AP_amount	4998	f	t	\N	\N
10187	4999	Gegenkonto 49960-49980	A	 		4999	f	t	\N	\N
10188	7140	Fertige Waren (Bestand)	A	A	IC	7140	f	t	\N	\N
10189	8100	Steuerfreie Umsätze o. VSt-Abzug §4 Nr.8 ff. UStG	A	I	AR_amount:IC_sale	8100	f	t	\N	\N
10190	8500	Provisionserlöse	A	I	AR_amount:IC_sale	8500	f	t	\N	\N
10191	8504	Provisionserlöse steuerfrei (§4 Nr.8ff UStG)	A	I	AR_amount:IC_sale	8504	f	t	\N	\N
10192	8505	Provisionserlöse steuerfrei (§4 Nr.5 UStG)	A	I	AR_amount:IC_sale	8505	f	t	\N	\N
10193	8506	Provisionserlöse,  7% USt	A	I	AR_amount:IC_sale	8506	f	t	\N	\N
10194	8507	Provisionserlöse, 15% Ust	A	I	AR_amount:IC_sale	8507	f	t	\N	\N
10195	8508	Provisionserlöse, 15%/16% USt	A	I	AR_amount:IC_sale	8508	f	t	\N	\N
10196	8509	Provisionserlöse, 16% Ust	A	I	AR_amount:IC_sale	8509	f	t	\N	\N
10197	8591	Sachbezüge,   7% USt (Waren)	A	I	AR_amount:IC_sale	8591	f	t	\N	\N
10198	8595	Sachbezüge, 15%/16% USt (Waren)	A	I	AR_amount:IC_sale	8595	f	t	\N	\N
10199	8596	Sachbezüge, 16% USt (Waren)	A	I	AR_amount:IC_sale	8596	f	t	\N	\N
10200	8597	Sachbezüge, 15% USt (Waren)	A	I	AR_amount:IC_sale	8597	f	t	\N	\N
10201	8630	Sonstige Erlöse betrieblich und regelmäßig, 7% USt	A	I	AR_amount:IC_sale	8630	f	t	\N	\N
10202	8645	Sonstige Erlöse betrieblich und regelmäßig, 16% Ust	A	I	AR_amount:IC_sale	8645	f	t	\N	\N
10203	8730	Gewährte Skonti	A	 		8730	f	t	\N	\N
10204	8731	Gewährte Skonti,  7% USt	A	 		8731	f	t	\N	\N
10205	8735	Gewährte Skonti, 16% Ust	A	 		8735	f	t	\N	\N
10206	8740	Gewährte Boni	A	 		8740	f	t	\N	\N
10207	8750	Gewährte Boni,  7% USt	A	 		8750	f	t	\N	\N
10208	8762	Gewährte Boni, 16% Ust	A	 		8762	f	t	\N	\N
10209	8770	Gewährte Rabatte	A	 		8770	f	t	\N	\N
10210	8780	Gewährte Rabatte,  7% USt	A	 		8780	f	t	\N	\N
10211	8792	Gewährte Rabatte, 16% Ust	A	 		8792	f	t	\N	\N
10212	8800	Erlöse aus Anlagenverkäufen	A	 		8800	f	t	\N	\N
10213	8801	Erlöse aus Anlagenverkäufen 15%/16% USt (bei Buchverlust)	A	 		8801	f	t	\N	\N
10214	8810	Erlöse aus Anlagenverkäufen 16% USt (bei Buchverlust)	A	 		8810	f	t	\N	\N
10215	8815	Erlöse aus Anlagenverkäufen 15% USt (bei Buchverlust)	A	 		8815	f	t	\N	\N
10216	8820	Erlöse aus Anlagenverkäufen 15%/16% USt (bei Buchgewinn)	A	 		8820	f	t	\N	\N
10217	8829	Erlöse aus Anlagenverkäufen (bei Buchgewinn)	A	 		8829	f	t	\N	\N
10218	8830	Erlöse aus Anlagenverkäufen 16% USt (bei Buchgewinn)	A	 		8830	f	t	\N	\N
10219	8835	Erlöse aus Anlagenverkäufen 15% USt (bei Buchgewinn)	A	 		8835	f	t	\N	\N
10220	8900	Eigenverbrauch	A	 		8900	f	t	\N	\N
10221	8905	Entnahme Gegenstände ohne USt	A	 		8905	f	t	\N	\N
10222	8908	Entnahme von Gegenstände, 16% USt §1 Abs.1 Nr.2a UStG	A	 		8908	f	t	\N	\N
10223	8909	Entnahme von Gegenstände, 15% USt §1 Abs.1 Nr.2a UStG	A	 		8909	f	t	\N	\N
10224	8910	Entnahme von Gegenstände, 15%/16% USt §1 Abs.1 Nr.2a UStG	A	 		8910	f	t	\N	\N
10225	8915	Entnahme von Gegenstände, 7% USt §1 Abs.1 Nr.2a UStG	A	 		8915	f	t	\N	\N
10226	8920	Entnahme v. sonst. Leist., 15%/16% USt §1 A.1 Nr.2b UStG	A	 		8920	f	t	\N	\N
10227	8930	Entnahme v. sonst. Leist., 7% USt §1 A.1 Nr.2b UStG	A	 		8930	f	t	\N	\N
10228	8937	Entnahme v. sonst. Leist., 16% USt §1 A.1 Nr.2b UStG	A	 		8937	f	t	\N	\N
10229	8938	Entnahme v. sonst. Leist., 15% USt §1 A.1 Nr.2b UStG	A	 		8938	f	t	\N	\N
10230	8939	Entnahme v. sonst. Leist., ohne USt §1 A.1 Nr.2b UStG	A	 		8939	f	t	\N	\N
10231	8941	Eigenverbr., 7% Ust §4 A.1 Nr.5 1-7, A.7 EStG	A	 		8941	f	t	\N	\N
10232	8942	Eigenverbr., 16% Ust  §4 A.1 Nr.5 1-7, A.7 EStG	A	 		8942	f	t	\N	\N
10233	8944	Eigenverbr., ohne Ust §4 A.1 Nr.5 1-7, A.7 EStG	A	 		8944	f	t	\N	\N
10235	8955	Umsatzsteuervergütungen	A	 		8955	f	t	\N	\N
10236	8960	Bestandsveränd. - unfertige Erzeugnisse	A	 		8960	f	t	\N	\N
10237	8970	Bestandsveränd. - unfertige Leistungen	A	 		8970	f	t	\N	\N
10238	8975	Bestandsveränd. - in Ausführung befindliche Bauaufträge	A	 		8975	f	t	\N	\N
10239	8977	Bestandsveränd. - in Arbeit befindliche Aufträge	A	 		8977	f	t	\N	\N
10240	8980	Bestandsveränd. - fertige Erzeugnisse	A	 		8980	f	t	\N	\N
10241	8990	Bestandsveränd. - andere aktivierte Eigenleistungen	A	 		8990	f	t	\N	\N
10242	9000	Saldenvorträge Sachkonten	A	 		9000	f	t	\N	\N
10243	9008	Saldenvorträge Debitoren	A	 		9008	f	t	\N	\N
10244	9009	Saldenvorträge Kreditoren	A	 		9009	f	t	\N	\N
10245	9100	Saldovortragskonto der Statistikkonten	A	 		9100	f	t	\N	\N
10246	1800	Privatentn. allg. (Privat Vollhafter / Einzelunternehmer)	A	Q		1800	f	t	\N	\N
10247	2000	Außerordentliche Aufwendungen	A	A		2000	f	t	\N	\N
10248	1600	Verb. aus Lief. und Leist. Lieferantengruppe 0	A	L	AP	1600	f	t	\N	\N
10249	3400	Wareneingang, 16% Vorsteuer	A	E	AP_amount	3400	f	t	\N	\N
10250	8400	Umsatzerlöse 16%	A	I	AR_amount:IC_sale	8400	f	t	\N	\N
10251	8840	Erträge aus Kursdifferenzen	A	I	AR_amount:IC_sale:IC_income	8840	f	t	\N	\N
10252	1771	Umsatzsteuer 7%	A	L	AR_tax:IC_taxpart:IC_taxservice	\N	f	t	\N	\N
10253	8300	Erlöse 7% USt	A	I	AR_amount:IC_sale	\N	f	t	\N	\N
10254	8401	Erlöse 19% USt	A	I	AR_amount:IC_sale:IC_income	\N	f	t	\N	\N
\.


--
-- Data for Name: chat; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.chat (id, trans_id, message, employee_id, creation_date) FROM stdin;
\.


--
-- Data for Name: contact; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.contact (id, trans_id, salutation, firstname, lastname, contacttitle, occupation, phone, fax, mobile, email, gender, parent_id, typeofcontact) FROM stdin;
2	10256										M	\N	company
3	10257										M	\N	company
\.


--
-- Data for Name: credits; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.credits (id, reference, description, transdate, accno, amount) FROM stdin;
\.


--
-- Data for Name: curr; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.curr (rn, curr, "precision") FROM stdin;
1	EUR	2
2	CHF	2
\.


--
-- Data for Name: customer; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customer (id, name, contact, phone, fax, email, notes, terms, taxincluded, customernumber, cc, bcc, business_id, taxnumber, sic_code, discount, creditlimit, iban, bic, employee_id, language_code, pricegroup_id, curr, startdate, enddate, arap_accno_id, payment_accno_id, discount_accno_id, cashdiscount, discountterms, threshold, paymentmethod_id, remittancevoucher, dispatch_id, last_modified, income_accno_id, payment_clearing_accno_id, reminderstop) FROM stdin;
10256	Beispiel KG	 					14	f	DK-2			0			0	0	DE89370400440532013000	COBADEFFXXX	0	\N	0	EUR	2024-01-01	\N	\N	\N	\N	0	0	0	0	t	0	2026-10-16 15:23:43.192449+02	10254	\N	f
\.


--
-- Data for Name: customercart; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customercart (cart_id, customer_id, parts_id, qty, price, taxaccounts) FROM stdin;
\.


--
-- Data for Name: customerlogin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customerlogin (id, login, passwd, session, session_exp, customer_id) FROM stdin;
\.


--
-- Data for Name: customertax; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customertax (customer_id, chart_id) FROM stdin;
10256	10252
10256	10022
\.


--
-- Data for Name: debits; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.debits (id, reference, description, transdate, accno, amount) FROM stdin;
\.


--
-- Data for Name: debitscredits; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.debitscredits (id, reference, description, transdate, debit_accno, credit_accno, amount) FROM stdin;
\.


--
-- Data for Name: defaults; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.defaults (fldname, fldvalue) FROM stdin;
inventory_accno_id	10188
income_accno_id	10250
expense_accno_id	10135
fxgain_accno_id	10251
fxloss_accno_id	10251
weightunit	kg
precision	2
version	2.8.52
company	Test Handel GmbH
address	Teststraße 1\n10115 Berlin
businessnumber	DE123456789
sinumber	2000
vinumber	6000
partnumber	D-100
customernumber	DK-2
vendornumber	DL-2
\.


--
-- Data for Name: department; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.department (id, description, role) FROM stdin;
\.


--
-- Data for Name: dispatch; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dispatch (id, description) FROM stdin;
\.


--
-- Data for Name: dpt_trans; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dpt_trans (trans_id, department_id) FROM stdin;
\.


--
-- Data for Name: employee; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.employee (id, login, name, address1, address2, city, state, zipcode, country, workphone, workfax, workmobile, homephone, startdate, enddate, notes, role, sales, email, ssn, iban, bic, managerid, employeenumber, dob, closedto) FROM stdin;
\.


--
-- Data for Name: exchangerate; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.exchangerate (curr, transdate, buy, sell) FROM stdin;
\.


--
-- Data for Name: exported_payment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.exported_payment (id, banking_export_event_id, rma_payment_id, payload, export_instruction_id) FROM stdin;
\.


--
-- Data for Name: fifo; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fifo (trans_id, transdate, parts_id, qty, costprice, sellprice, warehouse_id, invoice_id) FROM stdin;
\.


--
-- Data for Name: filtered; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.filtered (trans_id, entry_id, entry_id2, debit, credit) FROM stdin;
\.


--
-- Data for Name: financial_year; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.financial_year (id, start_date, end_date, status, yearend_id) FROM stdin;
1	2025-01-01	2025-12-31	CURRENT_FINANCIAL_YEAR	\N
\.


--
-- Data for Name: gifi; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.gifi (accno, description) FROM stdin;
0001	Aufw. f. die Ingangsetzung u. Erweit. des Geschäftsbetr.
0002	Aufw. f. die Währungsumstellung auf den EURO
0010	Konzess., gew. Schutzr. u. ähnl. Rechte/Werte sowie Liz.
0015	Konzessionen
0020	Gewerbliche Schutzrechte
0025	Ähnliche Rechte und Werte
0027	EDV-Software
0030	Lizenzen an gewerbl. Schutzr. u. ähnl. Rechten u. Werten
0035	Geschäfts- oder Firmenwert
0038	Anzahlungen auf Geschäfts- oder Firmenwert
0039	Anzahlungen auf immaterielle Vermögensgegenstände
0040	Verschmelzungsmehrwert
0050	Grundst., gl. Rechte/Bauten einschl. Bauten a. fr. Grundst.
0060	Grundstücke und grundstücksgleiche Rechte ohne Bauten
0065	Unbebaute Grundstücke
0070	Grundstücksgleiche Rechte (Erbbaurecht, Dauerwohnrecht)
0075	Grundstücke mit Substanzverzehr
0079	Anzahl. a. Grundst. u. grundstücksgl. Rechte ohne Bauten
0080	Bauten auf eigenen Grundst. und grundstücksgl. Rechten
0085	Grundstückswerte eigener bebauter Grundsstücke
0090	Geschäftsbauten
0100	Fabrikbauten
0110	Garagen
0111	Außenanlagen
0112	Hof- u. Wegebefestigungen
0113	Einrichtungen für Geschäfts- u. Fabrikbauten
0115	Andere Bauten
0120	Geschäfts-, Fabrik- u. andere Bauten im Bau
0129	Anz. a. Geschäfts-, Fabrik-, u.a. Bauten a. eig. Grundst+Rechte
0140	Wohnbauten
0145	Garagen
0146	Außenanlagen
0147	Hof- und Wegebefestigungen
0148	Einrichtungen für Wohnbauten
0150	Wohnbauten im Bau
0159	Anz. auf Wohnbauten auf eig. Grundstücken u. grundst.gl. Rechten
0160	Bauten auf fremden Grundstücken
0165	Geschäftsbauten
0170	Fabrikbauten
0175	Garagen
0176	Außenanlagen
0177	Hof- und Wegebefestigen
0178	Einrichtungen für Geschäfts- und Fabrikbauten
0179	Andere Bauten
0180	Geschäfts-, Fabrik- und andere Bauten im Bau
0189	Anzahl. a. Geschäfts-, Fabrik-, u.a. Bauten a. fr. Grundst.
0190	Wohnbauten
0191	Garagen
0192	Außenanlagen
0193	Hof- und Wegebefestigungen
0194	Einrichtungen für Wohnbauten
0195	Wohnbauten im Bau
0199	Anzahlungen auf Wohnbauten auf fremden Grundstücken
0200	Technische Anlagen und Maschinen
0210	Maschinen
0220	Maschinengebundene Werkzeuge
0240	Maschinelle Anlagen
0260	Transportanlagen und ähnliches
0280	Betriebsvorrichtungen
0290	Technische Anlagen und Maschinen im Bau
0299	Anzahlungen auf technische Anlagen und Maschinen
0300	Andere  Anlagen, Betriebs- und Geschäftsausstattung
0310	Andere Anlagen
0320	Pkw
0350	Lkw
0380	Sonstige Transportmittel
0400	Betriebsausstattung
0410	Geschäftsausstattung
0420	Büroeinrichtung
0430	Ladeneinrichtung
0440	Werkzeuge
0450	Einbauten
0460	Gerüst- und Schalungsmaterial
0480	Geringwertige Wirtschaftsgüter bis DM 800,-
0490	Sonstige Betriebs- und Geschäftsausstattung
0498	Andere Anlagen, Betriebs- und Geschäftsausstatt. im Bau
0499	Anzahl. a. andere Anlagen, Betriebs- u. Geschäftsausstatt.
0500	Anteile an verbundenen Unternehmen (Anlagevermögen)
0504	Anteile an herrschender oder mit Mehrheit beteiligter Gesellschaft
0505	Ausleihungen an verbundene Unternehmen
0510	Beteiligungen
0513	Typisch stille Beteiligungen
0516	Atypisch stille Beteiligungen
0517	Andere Beteiligungen an Kapitalgesellschaften
0518	Andere Beteiligungen an Personengesellschaften
0519	Beteiligung einer GmbH&CoKG an einer Komplementär GmbH
0520	Ausleihung an Untern. m.d.e. Beteiligungsverhältnis besteht
0525	Wertpapiere des Anlagevermögens
0530	Wertpapiere mit Gewinnbeteiligungsansprüchen
0535	Festverzinsliche Wertpapiere
0540	Sonstige Ausleihungen
0550	Darlehen / Sonstige Ausleihungen
0570	Genossenschaftsanteile zum langfristigen Verbleib
0580	Ausleihungen an Gesellschafter
0590	Ausleihungen an nahestehende Personen
0595	Rückdeckungsanspr. a. Lebensvers. z. langfrist. Verbleib
0600	Anleihen nicht konvertibel
0601	Anleihen nicht konvertibel - Restlaufzeit bis 1 Jahr
0605	Anleihen nicht konvertibel - Restlaufzeit 1 bis 5 Jahre
0610	Anleihen nicht konvertibel - Restlaufzeit größer 5 Jahre
0615	Anleihen konvertibel
0616	Anleihen konvertibel - Restlaufzeit bis 1 Jahr
0620	Anleihen konvertibel - Restlaufzeit 1 bis 5 Jahre
0625	Anleihen konvertibel - Restlaufzeit größer 5 Jahre
0630	Verbindlichkeiten gegenüber Kreditinstituten
0631	Verb. gg. Kreditinstituten - Restlaufz. bis 1 Jahr
0640	Verb. gg. Kreditinstituten - Restlaufz. 1 bis 5 Jahre
0650	Verb. gg. Kreditinstituten - Restlaufz. größer 5 Jahre
0660	Verbindlichkeiten gg. Kreditinst. aus TZ-Verträgen
0661	Verb. gg. Kreditinst. aus TZ-Verträgen - Restl. bis 1 J.
0670	Verb. gg. Kreditinst. aus TZ-Verträgen - Restl. 1 bis 5 J.
0680	Verb. gg. Kreditinst. aus TZ-Verträgen - Restl. größer 5 J.
0700	Verbindlichkeiten gg. verbundenen Unternehmen
0701	Verb. gg. verbundenen Unternehmen - Restlaufz. b. 1 J.
0705	Verb. gg. verbundenen Unternehmen - Restlaufz. 1 b. 5 J.
0710	Verb. gg. verb. Untern. - Restlaufz. gr. 5 J.
0715	Verb. gg. Untern. mit denen ein Beteiligungsverh. besteht
0716	Verb. gg. U. m.d.e. Beteiligungsv. best. - Restl. b. 1 J
0720	Verb. gg. U. m.d.e. Beteiligungsv. best. - Restl. 1 b. 5  J
0725	Verb. gg. U. m.d.e. Beteiligungsv. best. - Restl. gr. 5  J
0730	Verbindlichkeiten gegenüber Gesellschaftern
0731	Verb. gg. Gesellschaftern - Restlaufz. bis 1 Jahr
0740	Verb. gg. Gesellschaftern - Restlaufz. 1 bis 5 Jahre
0750	Verb. gg. Gesellschaftern - Restlaufz. größer 5 Jahre
0755	Verb. gg. Gesellschaftern für offene Ausschüttungen
0760	Darlehen typisch stiller Gesellschafter
0761	Darlehen typ. stiller Gesellschafter - Restlaufz. bis 1 Jahr
0764	Darlehen typ. stiller Gesellschafter - Restlaufz. 1 bis 5 J.
0767	Darlehen typ. stiller Gesellschafter - Restlaufz. größer 5 J.
0770	Darlehen atypisch stiller Gesellschafter
0771	Darlehen atyp. stiller Gesellsch.- Restlaufz. bis 1 J.
0774	Darlehen atyp. stiller Gesellsch.- Restlaufz. 1 bis 5 J.
0777	Darlehen atyp. stiller Gesellsch.- Restlaufz. größer 5 J.
0780	Partiarische Darlehen
0781	Partiarische Darlehen - Restlaufzeit bis 1 Jahr
0784	Partiarische Darlehen - Restlaufzeit 1 bis 5 Jahre
0787	Partiarische Darlehen - Restlaufzeit größer 5 Jahre
0800	Gezeichnetes Kapital
0801	Ausst. Einl. a.d. gez. Kapital, nicht eingef. (Aktivausw.)
0810	Ausst. Einl. a.d. gez. Kapital, eingeford. (Aktivausw.)
0820	Ausst. Einl. a.d. gez. Kapital, nicht eingef. (Passivausw.)
0830	Ausst. Einl. a.d. gez. Kapital, eingef. (Passivausw.)
0839	Eingeforderte Nachschüsse
0840	Kapitalrücklage
0841	Kapitalrückl. durch Ausgabe von Anteilen über Nennbetrag
0842	Kap.Rückl. Schuldver. f. Wandl.- u. Optionsr. z. Erw. v. Ant
0843	Kapitalrückl. d. Zuzahl. gg. Gewähr e. Vorzuges f. Anteile
0844	Kapitalrückl. d. andere Zuzahlungen in das Eigenkapital
0845	Eingefordertes Nachschußkapital
0846	Gesetzliche Rücklage
0847	Gesetzliche Rücklage 50/45% Vorbelastung
0848	Gesetzliche Rücklage 30% Vorbelastung
0849	Gesetzliche Rücklage 0% Vorbelastung
0850	Rücklage für eigene Anteile
0851	Satzungsmäßige Rücklagen
0852	Satzungsmäßige Rücklage 50/45% Vorbelastung
0853	Satzungsmäßige Rücklage 30% Vorbelastung
0854	Satzungsmäßige Rücklage 0% Vorbelastung
0855	Andere Gewinnrücklagen 50/45% Vorbelastung
0856	Eigenkapitalanteil von Wertaufholungen
0857	Eigenkapitalanteil von Preissteigerungsrücklagen
0858	Andere Gewinnrücklagen 30% Vorbelastung
0859	Andere Gewinnrücklagen 0% Vorbelastung
0860	Gewinnvortrag vor Verwendung
0862	Gewinnvortrag 50/45% Vorbelastung
0864	Gewinnvortrag 30% Vorbelastung
0866	Gewinnvortrag 0% Vorbelastung
0868	Verlustvortrag vor Verwendung
0869	Vorträge auf neue Rechnung (Bilanz)
0870	Festkapital (Personenges. Vollhafter / Einzelu.)
0880	Variables Kapital  (Personenges. Vollhaft. / Einzelu.)
0890	Gesellsch.-Darlehen (Personenges. Vollhaft. / Einzelu.)
0900	Kommandit-Kapital (Personenges. Teilhafter)
0910	Verlustausgleichskonto (Personenges. Teilhafter)
0920	Gesellschafter-Darlehen (Personenges. Teilhafter)
0930	Sonderposten mit Rücklageanteil
0931	Sonderposten mit Rücklageanteil §6b EStG
0932	Sonderposten mit Rücklageanteil Abschnitt 35 EStR
0933	Sonderposten mit Rücklageanteil §6dEStG
0934	Sonderposten mit Rücklageanteil §1 EntwLStG
0935	Sonderposten mit Rücklageanteil §3 Ausl-InvG
0936	Sonderposten mit Rücklageanteil §7d EStG
0937	Sonderposten mit Rücklageanteil §79 EStDV
0938	Sonderposten mit Rücklageanteil §80 EStDV
0939	Sonderposten mit Rücklageanteil §81 EStDV
0940	Sonderposten mit Rücklageanteil §82 EStDV
0941	Sonderposten mit Rücklageanteil §82a EStDV
0942	Sonderposten mit Rücklageanteil §82d EStDV
0943	Sonderposten mit Rücklageanteil §82e EStDV
0944	Sonderposten mit Rücklageanteil §14 BerlinFG
0945	Sonderposten mit Rücklageanteil §3 ZonenRFG / §4-6 FördergebietsG
0946	Sonderposten mit Rücklageanteil §52 Abs. 5 EStG
0947	Sonderposten mit Rücklageanteil §7g Abs. 1 EStG
0948	Sonderposten mit Rücklageanteil §7g Abs. 3 EStG
0949	Sonderposten mit Rücklageanteil §74 EStDV
0950	Rückstellungen für Pensionen und ähnliche Verpflichtungen
0955	Steuerrückstellungen
0957	Gewerbesteuerrückstellung
0963	Körperschaftsteuerrückstellung
0969	Rückstellungen für latente Steuern
0970	Sonstige Rückstellungen
0971	Rückst. unterl. Aufw. Instandhalt., Nachhol. in 3 Mon
0972	Rückst. unterl. Aufw. Instandhalt., Nachhol. in 4-12 Mon
0973	Rückstellungen für Abraum- und Abfallbeseitigung
0974	Rückstellungen für Gewährleistungen
0976	Rückst. f. drohende Verluste a. schwebenden Geschäften
0977	Rückstellungen für Abschluß- und Prüfungskosten
0978	Aufwandsrückstellungen gemäß § 249 Abs. 2 HGB
0979	Rückstellungen für den Umweltschutz
0980	Aktive Rechnungsabgrenzung
0983	Abgrenzung aktive latente Steuern
0984	Als Aufwand berücks. Zölle u. Verbrauchsst. a. Vorräte
0985	Als Aufwand berücks. Umsatzsteuer auf Anzahlungen
0986	Damnum / Disagio
0990	Passive Rechnungsabgrenzung
0992	Wertber.n (zur unterjährigen Kostenverrechnung f. BWA)
0996	Pauschalwertberichtigung a. Ford. - Restlaufz. bis 1 Jahr
0997	Pauschalwertberichtigung a. Ford. - Restlaufz. größer 1 Jahr
0998	Einzelwertberichtigung a. Ford. - Restlaufz. bis 1 Jahr
0999	Einzelwertberichtigung a. Ford. - Restlaufz. größer 1 Jahr
1000	Kasse
1010	Nebenkasse 1
1020	Nebenkasse 2
1100	Postgiro
1110	Postgiro 1
1120	Postgiro 2
1130	Postgiro 3
1190	LZB-Guthaben
1195	Bundesbankguthaben
1200	Bank-Giro
1210	Bank-Giro 1
1220	Bank-Giro 2
1230	Bank-Giro 3
1300	Wechsel aus Lieferungen und Leistungen
1301	Wechsel aus Lieferungen u. Leistungen - Restlaufz. bis 1 J.
1302	Wechsel aus Lieferungen u. Leistungen - Restl. größer 1 J.
1305	Wechsel aus Lieferungen u. Leistungen, bundesbankfähig
1310	Besitzwechsel gg. verbundenen Unternehmen
1311	Besitzwechsel gg. verbundenen Untern. - Restl. b. 1 J.
1312	Besitzwechsel gg. verbundenen Untern. - Restl. gr. 1 J.
1315	Besitzwechsel gg. verb. Unternehmen, bundesbankfähig
1320	Besitzwechsel gg. Untern. m.d.e. Beteiligungsverh. best.
1321	Besitzwechsel gg. U. m.d.e. Beteilig. best. - Restl. b. 1 J
1322	Besitzwechsel gg. U. m.d.e. Beteilig. best. - Restl. gr. 1 J
1325	Besitzwechsel gg. U. m.d.e. Beteilig. best., bundsbankfähig
1327	Finanzwechsel
1330	Schecks
1340	Anteile an verb. Unternehmen (Umlaufvermögen)
1344	Anteile an herrschender oder mit Mehrheit beteiligter Gesellschaft
1345	Eigene Anteile
1348	Sonstige Wertpapiere
1350	GmbH-Anteile zum kurzfristigen Verbleib
1352	Genossenschaftsanteile zum kurzfristigen Verbleib
1355	Ansprüche aus Rückdeckungsversicherungen
1360	Geldtransit Bank
1361	Geldtransit Bank 1
1362	Geldtransit Bank 2
1363	Geldtransit Bank 3
1369	Interne Umbuchung
1370	Verrechnungskonto Gewinnermittlung §4/3 EStG, ergebniswirksam
1371	Verrechnungskonto für Gewinnermittl. §4/3EStG, nicht ergebniswirksam
1380	Überleitungskonto Kostenstelle
1390	Verrechnungskonto Ist-Versteuerung
1400	Forderungen aus Lief. und Leist. Kundengruppe 0
1401	Forderungen aus Lief. und Leist. Kundengruppe 1
1402	Forderungen aus Lief. und Leist. Kundengruppe 2
1410	Forderungen aus Lief. und Leist. ohne Kontokorrent
1450	Forderungen nach §11, Abs.1 Satz 2 EStG für § 4/3 EStG
1451	Ford.a.Lief.u.Leist. ohne Kontokorrent - Restlaufz. b. 1 J.
1455	Ford.a.Lief.u.Leist. ohne Kontokorrent - Restlaufz. gr.1 J.
1460	Zweifelhafte Forderungen
1461	Zweifelhafte Forderungen - Restlaufzeit bis 1 Jahr
1465	Zweifelhafte Forderungen - Restlaufzeit größer 1 Jahr
1470	Ford.a.Lief.u.Leist. gg. verbundenen Unternehmen
1471	Ford.a.Lief.u.Leist. gg. verb. Untern. - Restl. bis 1 J.
1475	Ford.a.Lief.u.Leist. gg. verb. Untern. - Restl. größer 1 J.
1478	Wertber. a. Ford.a.L.u.L. gg. verb. U. - Restl. b. 1 J.
1479	Wertber. a. Ford.a.L.u.L. gg. verb. U. - Restl. gr. 1 J.
1480	Ford.a.L.u.L. gg. Untern. m.d.e. Beteiligungsverh. best.
1481	Ford.a.L.u.L. gg. U. m.d.e. Beteilig. best. - Restl. b. 1 J
1485	Ford.a.L.u.L. gg. U. m.d.e. Beteilig. best. - Restl. gr. 1 J
1488	Wertber. a. Ford. Restl. b. 1 J. gg. U. m.d.e. Beteilig.
1489	Wertber. a. Ford. Restl. gr. 1 J. gg. U. m.d.e. Beteilig.
1490	Ford.a.Lief.u.Leist. gegen Gesellschafter
1491	Ford.a.Lief.u.Leist. gg. Gesellsch.- Restlaufz. bis 1 J.
1495	Ford.a.Lief.u.Leist. gg. Gesellsch.- Restlaufz. größer 1 J.
1499	Gegenkonto 14510-14980 bei Aufteilung Debitoren
1500	Sonstige Vermögensgegenstände
1501	Sonstige Vermögensgegenstände - Restlaufz. bis 1 Jahr
1502	Sonstige Vermögensgegenstände - Restlaufz. größer 1 Jahr
1503	Ford. gg. Vorstandsmitgl. u. Geschäftsf. - Restl. b. 1 J.
1504	Ford. gg. Vorstandsmitgl. u. Geschäftsf. - Restl. gr. 1 J.
1505	Ford. gg. Aufsichtsrats- u. Beiratsmitgl. - Restl. b. 1 J.
1506	Ford. gg. Aufsichtsrats- u. Beiratsmitgl. - Restl. gr. 1 J.
1507	Ford. gg. Gesellschafter - Restlaufzeit bis 1 Jahr
1508	Ford. gg. Gesellschafter - Restlaufzeit größer 1 Jahr
1510	Geleistete Anzahlungen auf Vorräte
1511	Geleistete Anzahlungen, 7% Vorsteuer
1516	Geleistete Anzahlungen, 15% Vorsteuer
1517	Geleistete Anzahlungen, 16% Vorsteuer
1521	Agenturwarenabrechnung
1525	Kautionen
1526	Kautionen - Restlaufzeit bis 1 Jahr
1527	Kautionen - Restlaufzeit größer 1 Jahr
1530	Forderungen gegen Personal
1531	Forderungen gegen Personal - Restlaufzeit bis 1 Jahr
1537	Forderungen gegen Personal - Restlaufzeit größer 1 Jahr
1540	Steuerüberzahlungen
1542	Steuererstattungsansprüche gg. anderen EU-Ländern
1545	Umsatzsteuerforderungen
1547	Forderungen aus entrichteten Verbrauchssteuern
1548	Vorsteuer im Folgejahr abziehbar
1549	Körperschaftsteuerrückforderung
1550	Darlehen
1551	Darlehen - Restlaufzeit bis 1 Jahr
1555	Darlehen - Restlaufzeit größer 1 Jahr
1560	Aufzuteilende Vorsteuer
1561	Aufzuteilende Vorsteuer, 7%
1562	Aufzuteilende Vorsteuer aus ig. Erwerb
1565	Aufzuteilende Vorsteuer, 16 %
1566	Aufzuteilende Vorsteuer, 15 %
1570	Abziehbare Vorsteuer
1571	Abziehbare Vorsteuer, 7%
1572	Abziehbare Vorsteuer aus ig. Erwerb
1573	Abziehbare Vorsteuer aus ig. Erwerb, 16%
1575	Abziehbare Vorsteuer, 16%
1576	Abziehbare Vorsteuer, 15%
1577	Vorsteuer nach allg. Durchschnittssätzen UStVA KZ 63
1578	Berichtigung des VSt-Abzugs früherer Jahre UStVA KZ 64
1580	Gegenkonto Vorsteuer § 4/3 EStG
1581	Auflösung Vorsteuer aus Vorjahr § 4/3 EStG
1584	Abziehb. VSt. a. ig. Erw. v. Neufahrz. v. Lief. ohne USt-ID
1586	Kürzung BerlinFG
1588	Bezahlte Einfuhrumsatzsteuer
1590	Durchlaufende Posten
1593	Verrechnungskto erhalt. Anzahl. b. Buchung ü. Kundenkto
1594	Forderungen gegen verbundene Unternehmen
1595	Ford. gg. verbundene Unternehmen - Restlaufz. b. 1 J.
1596	Ford. gg. verbundene Unternehmen - Restlaufz. gr. 1 J.
1597	Ford. gg. Untern. mit denen ein Beteiligungsverh. besteht
1598	Ford. gg. U. m.d.e. Beteiligungsv. best. - Restl. b. 1 J.
1599	Ford. gg. U. m.d.e. Beteiligungsv. best. - Restl. gr. 1 J.
1600	Verb. aus Lief. und Leist. Lieferantengruppe 0
1601	Verb. aus Lief. und Leist. Lieferantengruppe 1
1602	Verb. aus Lief. und Leist. Lieferantengruppe 2
1610	Verb.a.L.u.L. ohne Kontokorrent
1624	Verbindlichkeiten aus Lief. u. Leist. für Investitionen für §4/3 EStG
1625	Verb.a.L.u.L. ohne Kontokorrent - Restl. b. 1 J.
1626	Verb.a.L.u.L. ohne Kontokorrent - Restlaufz. 1 bis 5  J.
1628	Verb.a.L.u.L. ohne Kontokorrent - Restlaufz. größer 5 J.
1630	Verb.a.Lief.u.Leist. gg. verbundenen Unternehmen
1631	Verb.a.L.u.L. gg. verb. Untern. - Restlaufz. bis 1 J.
1635	Verb.a.L.u.L. gg. verb. Untern. - Restlaufz. 1 bis 5 J.
1638	Verb.a.L.u.L. gg. verb. Untern. - Restlaufz. größer 5 J.
1640	Verb.a.L.u.L. gg. Untern. m.d.e. Beteiligungsverh. best.
1641	Verb.a.L.u.L. gg. U. m.d.e. Beteilig. best. - Restl. b. 1 J
1645	Verb.a.L.u.L. gg. U. m.d.e. Beteilig. best. - Restl. 1 b 5 J
1648	Verb.a.L.u.L. gg. U. m.d.e. Beteilig. best. - Restl. gr. 5 J
1650	Verb.a.Lief.u.Leist. gegen Gesellschaftern
1651	Verb.a.Lief.u.Leist. gg. Gesellsch. - Restl. bis 1 J.
1655	Verb.a.Lief.u.Leist. gg. Gesellsch. - Restl. 1 bis 5  J.
1658	Verb.a.Lief.u.Leist. gg. Gesellsch. - Restl. größer 5  J.
1659	Gegenkonto 16250-16580 bei Aufteilung Kreditoren-Konto
1660	Schuldwechsel
1661	Schuldwechsel - Restlaufzeit bis 1 Jahr
1680	Schuldwechsel - Restlaufzeit 1 bis 5 Jahre
1690	Schuldwechsel - Restlaufzeit größer 5 Jahre
1700	Sonstige Verbindlichkeiten
1701	Sonstige Verbindlichkeiten - Restlaufzeit bis 1 Jahr
1702	Sonstige Verbindlichkeiten - Restlaufzeit 1 bis 5 Jahre
1703	Sonstige Verbindlichkeiten - Restlaufzeit größer 5 Jahre
1704	Sonstige Verbindlichkeiten, z.B. nach §11,Abs.2,2 EStG für §4/3
1705	Darlehen
1706	Darlehen - Restlaufzeit bis 1 Jahr
1707	Darlehen - Restlaufzeit 1 bis 5 Jahre
1708	Darlehen - Restlaufzeit größer 5 Jahre
1709	Gewinnverfügungskonto stiller Gesellschafter
1710	Erhaltene Anzahlungen (Verbindlichkeiten)
1711	Erhaltene verst. Anzahl., 7% USt (Verbindlichkeiten)
1716	Erhaltene verst. Anzahl., 15% USt (Verbindlichkeiten)
1717	Erhaltene verst. Anzahl., 16% USt (Verbindlichkeiten)
1719	Erhaltene Anzahlungen - Restlaufzeit bis 1 Jahr
1720	Erhaltene Anzahlungen - Restlaufzeit 1 bis 5 Jahre
1721	Erhaltene Anzahlungen - Restlaufzeit größer 5 Jahre
1722	Erhaltene Anzahlungen (von Vorräten offen abgesetzt)
1731	Agenturwarenabrechnung
1732	Erhaltene Kautionen
1733	Erhaltene Kautionen - Restlaufzeit bis 1 Jahr
1734	Erhaltene Kautionen - Restlaufzeit 1 bis 5 Jahre
1735	Erhaltene Kautionen - Restlaufzeit größer 5 Jahre
1736	Verbindlichkeiten aus Betriebsteuern und Abgaben
1737	Verb. aus Betriebsteuern u. Abgaben - Restlaufz. bis 1 J.
1738	Verb. aus Betriebsteuern u. Abgaben - Restlaufz. 1 bis 5 J.
1739	Verb. aus Betriebsteuern u. Abgaben - Restl. größer 5 J.
1740	Verbindlichkeiten aus Lohn und Gehalt
1741	Verbindlichkeiten aus Lohn- und Kirchensteuer
1742	Verbindlichkeiten im Rahmen der sozialen Sicherheit
1743	Verb. im Rahmen der sozialen Sicherheit - Restl. bis 1 J.
1744	Verb. im Rahmen der sozialen Sicherheit - Restl. 1 bis 5 J.
1745	Verb. im Rahmen der sozialen Sicherheit - Restl. gr. 5 J.
1746	Verbindlichkeiten aus Einbehaltungen
1747	Verbindlichkeiten für Verbrauchssteuern
1750	Verbindlichkeiten aus Vermögensbildung
1751	Verb. aus Vermögensbildung - Restlaufz. bis 1 Jahr
1752	Verb. aus Vermögensbildung - Restlaufz. 1 bis 5  Jahre
1753	Verb. aus Vermögensbildung - Restlaufz. größer 5  Jahre
1755	Lohn- und Gehaltsverrechnung
1758	Umsatzsteuerabzugsverfahren, 16% Umsatzsteuer
1759	Umsatzsteuerabzugsverfahren, 15% Umsatzsteuer
1760	Umsatzsteuer nicht fällig
1761	Umsatzsteuer nicht fällig , 7%
1762	Umsatzsteuer nicht fällig a.i. Inland steuerpfl. EU-Lief.
1763	Umsatzsteuer nicht fällig a.i. Inland steuerpfl. EU-Lief., 16%
1765	Umsatzsteuer nicht fällig, 16%
1766	Umsatzsteuer nicht fällig, 15%
1767	Umsatzsteuer a.i. and. EU-Land steuerpfl. Lief.
1768	Umsatzsteuer a.i. and. EU-Land steuerpfl. sonst. Lief./Werkl.
1769	Steuerzahlungen an andere EU-Länder
1770	Umsatzsteuer
1771	Umsatzsteuer, 7%
1772	Umsatzsteuer aus ig. Erwerb
1773	Umsatzsteuer aus ig. Erwerb, 16%
1775	Umsatzsteuer, 16%
1776	Umsatzsteuer, 15%
1777	Umsatzsteuer aus im Inland steuerpfl. EU-Lieferungen
1778	Umsatzsteuer aus im Inland steuerpfl. EU-Lieferungen, 16%
1779	Umsatzsteuer aus ig. Erwerb ohne Vorsteuerabzug
1780	Umsatzsteuer - Vorauszahlungen
1781	Umsatzsteuer - Vorauszahlungen 1/11
1782	Nachsteuer, UStVA KZ 65
1783	In Rechnung unber. ausgewiesene und geschuldete Steuer, UStVA KZ 69
1784	Umsatzsteuer aus ig. Erw. v. Neufahrz. v. Lief. ohne USt-ID
1788	Einfuhrumsatzsteuer aufgeschoben bis
1789	Umsatzsteuer laufendes Jahr
1790	Umsatzsteuer Vorjahr
1791	Umsatzsteuer frühere Jahre
1792	Abgrenzung für Grundstücke
1794	Abgrenzung für immaterielle Vermögensgegenstände
1795	Abgrenzung für Bauten auf eigenen Grundstücken
1796	Abgrenzung für andere Anlagen, B.u.G. Ausstattung
1797	Abgrenzung für Bauten auf fremden Grundstücken
1798	Abgrenzung für technische Anlagen und Maschinen
1799	Sonstige Verrechnungskonten (Interimskonten)
1793	Verrechnungskto geleist. Anzahl. bei Buchung über Lief.Kto.
1800	Privatentn. allg. (Privat Vollhafter / Einzelunternehmer)
1810	Privatsteuern (Privat Vollhafter / Einzelunternehmer)
1820	Sonderausg. beschr. abzugsf. (Privat Vollhaft./Einzelu.)
1830	Sonderausg. unbeschr. abzugsf. (Privat Vollhaft./Einzelu.)
1840	Privatspenden (Privat Vollhafter / Einzelunternehmer)
1850	Außergewöhnliche Belastungen (Privat Vollhaft. / Einzelunt.)
1860	Grundstücksaufwand (Privat Vollhafter / Einzelunternehmer)
1870	Grundstücksertrag (Privat Vollhafter / Einzelunternehmer)
1880	Eigenverbrauch (Privat Vollhafter / Einzelunternehmer)
1890	Privateinlagen (Privat Vollhafter / Einzelunternehmer)
1900	Privatentnahmen allgemein (Privat Teilhafter)
1910	Privatsteuern (Privat Teilhafter)
1920	Sonderausgaben beschränkt abzugsf. (Privat Teilhafter)
1930	Sonderausgaben unbeschränkt abzugsf. (Privat Teilhafter)
1940	Privatspenden (Privat Teilhafter)
1950	Außergewöhnliche Belastungen (Privat Teilhafter)
1960	Grundstücksaufwand (Privat Teilhafter)
1970	Grundstücksertrag (Privat Teilhafter)
1980	Eigenverbrauch (Privat Teilhafter)
1990	Privateinlagen  (Privat Teilhafter)
2000	Außerordentliche Aufwendungen
2010	Betriebsfremde Aufw. (soweit nicht außerordentlich)
2020	Periodenfremde Aufw. (soweit nicht außerordentlich)
2100	Zinsen und ähnliche Aufwendungen
2103	Steuerlich abzugsfähige, andere Nebenleistungen zu Steuern
2104	Steuerlich nicht abzugsfähige, andere Nebenleistungen zu Steuern
2107	Zinsaufwendungen §233a AO betriebliche Steuern
2108	Zinsaufw. §233a, §234, §237 AO Personenst. §8 GewStG
2109	Zinsaufwendungen an verbundene Unternehmen
2110	Zinsaufwendungen für kurzfristige Verbindlichkeiten
2118	In Dauerschuldzins. umqualif. Zinsen a. kurzfristige Verb.
2119	Zinsaufw. f. kurzfristige Verb. an verbunden Unternehmen
2120	Zinsaufwendungen für langfristige Verbindlichkeiten
2127	Renten u. dauernde Last. a. Gründung/Erwerb §8GewStG
2128	Zinsaufw. an Mitu. f. Hingabe v. langfrist. Kapital §15 EStG
2129	Zinsaufw. f. langfristige Verb. an verbundene Unternehmen
2130	Diskontaufwendungen
2139	Diskontaufwendungen an verbundene Unternehmen
2140	Zinsähnliche Aufwendungen
2149	Zinsähnliche Aufwendungen an verbundene Unternehmen
2150	Aufwendungen aus Kursdifferenzen
2170	Nicht abziehb. VSt a. Zinsen u. ähnl. Aufw.
2171	Nicht abziehb. VSt, 7% a. Zinsen u. ähnl. Aufw.
2175	Nicht abziehb. VSt. 16% a. Zinsen u. ähnl. Aufw.
2176	Nicht abziehb. VSt, 15% a. Zinsen u. ähnl. Aufw.
2200	Körperschaftsteuer
2203	Körperschaftsteuer für Vorjahre
2205	Anrechenbare Körperschaftssteuer auf vereinnahmte Kapitalerträge
2208	Solidaritätszuschlag
2209	Solidaritätszuschlag für Vorjahre
2210	Kapitalertragsteuer
2213	Anrechenbarer Solidaritätszuschlag auf Kapitalertragssteuer
2215	Zinsabschlagsteuer
2218	Anrechenbarer Solidaritätszuschlag auf Zinsabschlagsteuer
2223	Vermögensteuer für Vorjahre
2280	Steuernachz. Vorjahre f. Steuern v. Einkommen u. Ertrag
2282	Steuererstatt. Vorjahre f. Steuern v. Einkommen u. Ertrag
2284	Erträge a. Aufl. v. Rückst. f. Steuern v. Eink. u. Ertrag
2285	Steuernachzahlung Vorjahre für sonstige Steuern
2287	Steuererstattung Vorjahre für sonstige Steuern
2289	Erträge a. d. Auflösung v. Rückstell. f. sonstige Steuern
2300	Sonstige Aufwendungen
2307	Sonstige Aufwendungen betriebsfremd und regelmäßig
2309	Sonstige Aufwendungen unregelmäßig
2310	Anlagenabgänge (Restbuchwert und Buchverlust)
2315	Anlagenabgänge (Restbuchwert bei Buchgewinn)
2320	Verluste a. Abgang v. Gegenst. d. Anlagevermögens
2325	Verluste a. Abgang v. Gegenst. d. Umlaufv. (außer Vorräte)
2340	Einstell. in Sonderpost. m. Rücklageant. (steuerfr. Rückl.)
2341	Einstell. in Sonderpost. m. Rücklageant. (Ansparabschreibungen)
2345	Einstell. in Sonderpost. m. Rücklageant. (Sonderabschr.)
2350	Grundstücksaufwendungen
2375	Grundsteuer
2380	Spenden, steuerlich nicht absetzbar
2381	Beiträge u. Spenden f. wissenschaftl. u. kulturelle Zwecke
2382	Beiträge u. Spenden f. mildtätige Zwecke
2383	Beiträge u. Spenden f. kirchl., religiöse u. gemeinn. Zwecke
2384	Beiträge u. Spenden an politische Parteien
2385	Nicht abziehbare Hälfte der Aufsichtsratsvergütungen
2386	Abziehbare Aufsichtsratsvergütungen
2400	Forderungsverluste (übliche Höhe)
2401	Forderungsverluste, 7% USt (übliche Höhe)
2402	Ford.Verl. a. steuerfr. EU-Lief. (übliche Höhe)
2403	Ford.Verl. a.i. Inl. steuerpfl. EU-Lief., 7% USt (übl. Höhe)
2404	Ford.Verl. a.i. Inl. steuerpfl. EU-Lief., 15%+16%USt (übl. Höhe)
2405	Forderungsverluste, 15%+16% USt (übliche Höhe)
2406	Forderungsverluste, 16% USt (übliche Höhe)
2407	Forderungsverluste, 15% USt (übliche Höhe)
2408	Ford.Verl. a.i. Inl. steuerpfl. EU-Lief., 16%USt (übl. Höhe)
2409	Ford.Verl. a.i. Inl. steuerpfl. EU-Lief., 15%USt (übl. Höhe)
2430	Forderungsverlust unüblich hoch
2450	Einstellungen in Pauschalwertberichtigung zu Forderungen
2451	Einstellungen in Einzelwertberichtigung zu Forderungen
2490	Aufwendungen aus Verlustübernahme
2492	Abgef. Gew. aufgrund einer Gewinngemeinschaft
2493	Abgef. Gew. a. stille Gesellschafter §8 GewStG
2494	Abgef. Gew. a. Gewinn- oder Teilgewinnabführungsvertr.
2495	Einst. in die Kapitalrückl. n. Vorschr. d. vereinf. Kap.Herabs.
2496	Einst. in die gesetzliche Rücklage
2497	Einst. in die satzungsmäßige Rücklage
2498	Einst. in die Rücklage für eigene Anteile
2499	Einst. in andere Gewinnrücklagen
2500	Außerordentliche Erträge
2510	Betriebsfremde Erträge (soweit nicht außerordentlich)
2520	Periodenfremde Erträge (soweit nicht außerordentlich)
2600	Erträge aus Beteiligungen
2617	Gewinne a.Ant. an nicht steuerbefr. inländischen KG §9Nr.2aGewStG
2618	Gewinnanteile aus Mitunternehmerschaften §9 GewStG
2619	Erträge aus Beteiligungen an verbundenen Unternehmen
2620	Ertr. a. and. Wertpap. u. Ausl. d. Finanzanlageverm.
2649	Ertr. a. and. Wertpap. u. Ausl. d. Fin.Anl.Verm. a. verb. U.
2650	Sonstige Zinsen und ähnliche Erträge
2657	Zinserträge §233a AO betriebliche Steuern
2658	Zinserträge §233a AO Körperschaftsteuer / Vermögensteuer
2659	Sonstige Zinsen u. ähnliche Erträge aus verb. Unternehmen
2660	Erträge aus Kursdifferenzen
2670	Diskonterträge
2679	Diskonterträge aus verbundenen Unternehmen
2680	Zinsähnliche Erträge
2689	Zinsähnliche Erträge aus verbundenen Unternehmen
2700	Sonstige Erträge
2705	Sonstige Erträge betrieblich und regelmäßig
2707	Sonstige Erträge betriebsfremd und regelmäßig
2709	Sonstige Erträge unregelmäßig
2710	Erträge aus Zuschreibungen des Anlagevermögens
2715	Erträge aus Zuschreibungen des Umlaufvermögens
2720	Ertr. a. Abgang v. Gegenst. d. Anlagevermögens
2725	Ertr. a. Abgang v. Gegenst. d. Umlaufv.s (außer Vorräte)
2730	Ertr. a. Herabs. d. Pauschalwertber. zu Forderungen
2731	Ertr. a. Herabs. d. Einzelwertber. zu Forderungen
2732	Erträge aus abgeschriebenen Forderungen
2735	Erträge aus der Auflösung von Rückstellungen
2739	Erträge aus der Auflösung von Sonderpost. m. Rücklageant. (Ansparabschr.)
2740	Ertr. a. Aufl. v. Sonderp. m. Rückl.Ant. (steuerfr. Rückl.)
2741	Ertr. a. Aufl. v. Sonderp. m. Rückl.Ant. (Sonderabschr.)
2742	Versicherungsentschädigungen
2743	Investitionszuschüsse (steuerpflichtig)
2744	Investitionszulagen (steuerfrei)
2745	Erträge aus Kapitalherabsetzung
2750	Grundstückserträge
2780	Steuererstattung Vorjahre f. Steuern vom Eink. u. Ertrag
2785	Steuererstattung Vorjahre f. sonstige Steuern
2790	Erträge aus Verlustübernahme
2792	Erh. Gew. aufgrund einer Gewinngemeinschaft
2794	Erh. Gew. aufgrund eines Gew.- oder Teilgew.Abführ.Vertr.
2795	Entnahmen aus der Kapitalrücklage
2796	Entnahmen aus der gesetzlichen Rücklage
2797	Entnahmen aus satzungsgemäßen Rücklagen
2798	Entnahmen aus der Rücklage für eigene Anteile
2799	Entnahmen aus anderen Gewinnrücklagen
2860	Gewinnvortrag nach Verwendung
2862	Gewinnvortrag 50/45% Vorbelastung
2864	Gewinnvortrag 30% Vorbelastung
2866	Gewinnvortrag 0% Vorbelastung
2868	Verlustvortrag nach Verwendung
2869	Vorträge auf neue Rechnung (GuV)
2870	Ausschüttung
2890	Verrechneter kalkulatorischer Unternehmerlohn
2891	Verrechnete kalkulatorische Miete und Pacht
2892	Verrechnete kalkulatorische Zinsen
2893	Verrechnete kalkulatorische Abschreibung
2894	Verrechnete kalkulatorische Wagnisse
2895	Verrechneter kalkulatorischer Lohn für unentgeltliche Mitarbeiter
3000	Roh-, Hilfs- und Betriebsstoffe
3090	Energiestoffe (Fertigung)
3100	Fremdleistungen
3150	Leistungen von ausländischen Unternehmen (Nullregelung)
3200	Wareneingang
3300	Wareneingang,  7% Vorsteuer
3340	Wareneingang, 15% Vorsteuer
3400	Wareneingang, 15%+16% Vorsteuer
3410	Wareneingang, 16% Vorsteuer
3420	Innergem. Erwerb, 7% VSt u. 7% USt
3425	Innergem. Erwerb, 15%+16% VSt u. 15%+16% USt
3430	Innergem. Erwerb, ohne VSt-Abzug u. 7% USt
3431	Innergem. Erwerb, 16% VSt u. 16% Ust
3433	Innergem. Erwerb, 15% VSt u. 15% Ust
3435	Innergem. Erwerb, ohne VSt-Abzug u. 15%+16% USt
3436	Innergem. Erwerb, ohne VSt-Abzug u. 16% Ust
3437	Innergem. Erwerb, ohne VSt-Abzug u. 15% Ust
3440	Innergem. Erw. v. Neufahrz. v. Lief. ohne USt-ID, 15%+16% USt
3441	Innergem. Erw. v. Neufahrz. v. Lief. ohne USt-ID, 16% Ust
3442	Innergem. Erw. v. Neufahrz. v. Lief. ohne USt-ID, 15% Ust
3500	Wareneingang, 5% Vorsteuer
3530	Wareneingang, 9% Vorsteuer
3540	Wareneingang, 9,5% Vorsteuer
3550	Steuerfreier innergemeinschaftlicher Erwerb
3600	Nicht abziehbare Vorsteuer
3610	Nicht abziehbare Vorsteuer,   7%
3650	Nicht abziehbare Vorsteuer, 16%
3660	Nicht abziehbare Vorsteuer, 15%
3700	Nachlässe
3710	Nachlässe, 7% Vorsteuer
3720	Nachlässe, 15%+16% Vorsteuer
3722	Nachlässe, 16% Vorsteuer
3723	Nachlässe, 15% Vorsteuer
3724	Nachlässe aus ig. Erwerb, 7% VSt und 7% USt
3725	Nachlässe aus ig. Erwerb, 15%+16% VSt und 15%+16% USt
3726	Nachlässe aus ig. Erwerb, 16% VSt und 16% Ust
3727	Nachlässe aus ig. Erwerb, 15% VSt und 15% Ust
3730	Erhaltene Skonti
3731	Erhaltene Skonti,   7% Vorsteuer
3735	Erhaltene Skonti, 16% Vorsteuer
3736	Erhaltene Skonti, 15% Vorsteuer
3740	Erhaltene Boni
3750	Erhaltene Boni,   7% Vorsteuer
3760	Erhaltene Boni, 15%+16% Vorsteuer
3762	Erhaltene Boni, 16% Vorsteuer
3764	Erhaltene Boni, 15% Vorsteuer
3770	Erhaltene Rabatte
3780	Erhaltene Rabatte, 7% Vorsteuer
3790	Erhaltene Rabatte, 15%+16% Vorsteuer
3792	Erhaltene Rabatte, 16% Vorsteuer
3794	Erhaltene Rabatte, 15% Vorsteuer
3800	Anschaffungsnebenkosten
3830	Leergut
3850	Zölle und Einfuhrabgaben
3960	Bestandsv. Roh-, Hilfs- u. Betriebsstoffe / bezogene Waren
3970	Bestand Roh-, Hilfs- und Betriebsstoffe
3980	Bestand Waren
3990	Verrechnete Stoffkosten
4000	Material- und Stoffverbrauch
4100	Löhne und Gehälter
4110	Löhne
4120	Gehälter
4124	Geschäftsführergehälter der GmbH-Gesellschafter
4125	Ehegattengehalt
4126	Tantiemen
4127	Geschäftsführergehälter
4128	Vergütungen an angestellte Mitunternehmer §15 EStG
4130	Gesetzliche soziale Aufwendungen
4137	Gesetzliche soziale Aufw. für Mitunternehmer §15 EStG
4138	Beiträge zur Berufsgenossenschaft
4139	Ausgleichsabgabe i. S. d. Schwerbehindertengesetzes
4140	Freiw. soziale Aufwendungen (lohnsteuerfrei)
4145	Freiw. soziale Aufwendungen (lohnsteuerpflichtig)
4149	Pauschale Lohnsteuer auf s. Bezüge (z.B. Fahrtkostenzuschuß)
4150	Krankengeldzuschüsse
4160	Versorgungskassen
4165	Aufwendungen für die Altersversorgung
4167	Pauschale Lohnsteuer auf s. Bezüge (z.B. Direktversicherung)
4168	Aufw. f. die Altersversorgung f. Mitunternehmer §15 EStG
4169	Aufwendungen für Unterstützung
4170	Vermögenswirksame Leistungen
4175	Fahrtkostenerstattung - Wohnung / Arbeitsstätte
4180	Bedienungsgelder
4190	Aushilfslöhne
4199	Lohnsteuer für Aushilfen
4200	Raumkosten
4210	Miete
4218	Gewerbesteuerlich zu berücks. Miete §8 GewStG
4219	Vergütung an Mitu. f. mietw. Überl. v. Wirtschaftsg. §15EStG
4220	Pacht
4228	Gewerbesteuerlich zu berücks. Pacht §8 GewStG
4229	Vergütung an Mitu. f. pachtw. Überl. v. Wirtschaftsg.§15EStG
4230	Heizung
4240	Gas, Strom, Wasser (Verwaltung, Vertrieb)
4250	Reinigung
4260	Instandhaltung betrieblicher Räume
4270	Abgaben für betrieblich genutzten Grundbesitz
4280	Sonstige Raumkosten
4300	Nicht abziehb. VSt a. sonst. betriebl. Aufw./AfA
4301	Nicht abziehb. VSt, 7% a. sonst. betriebl. Aufw./AfA
4305	Nicht abziehb. VSt, 16% a. sonst. betriebl. Aufw./AfA
4306	Nicht abziehb. VSt, 15% a. sonst. betriebl. Aufw./AfA
4320	Gewerbesteuer (Vorauszahlung)
4330	Gewerbeertragsteuer
4335	Gewerbekapitalsteuer
4340	Sonstige Betriebsteuern
4350	Verbrauchsteuer
4360	Versicherungen
4370	Nettoprämie für Rückdeckung künftiger Versorgungsleistungen
4380	Beiträge
4390	Sonstige Abgaben
4396	Steuerlich abzugsfähige Verspätungszuschläge und Zwangsgelder
4397	Steuerlich nicht abzugsfähige Verspätungszuschläge und Zwangsgelder
4400	Besondere Kosten (zur freien Verfügung)
4500	Fahrzeugkosten
4510	Kfz-Steuern
4520	Kfz-Versicherungen
4530	Laufende Kfz-Betriebskosten
4540	Kfz-Reparaturen
4550	Garagenmieten
4570	Fremdfahrzeuge
4580	Sonstige Kfz-Kosten
4600	Werbe- und Reisekosten
4610	Werbekosten
4630	Geschenke bis DM 75,00
4635	Geschenke über DM 75,00
4638	Geschenke ausschließlich betrieblich genutzt
4640	Repräsentationskosten
4650	Bewirtungskosten
4653	Aufwerksamkeiten
4654	Nicht abzugsfähige Bewirtungskosten
4655	Nicht abzugsfähige Betriebsausgaben
4660	Reisekosten Arbeitnehmer
4666	Reisekost. Arbeitn., 12,3%/13,1% VSt  Verpfl.Mehr- / Übern.Aufw.
4667	Reisekost. Arbeitn., 9,8%/10,5% VSt Gesamtpauschal.
4670	Reisekosten Unternehmer
4675	Reisekosten Unternehmer, 9,8/10,5% VSt sonst.Gesamtpauschal.
4676	Reisekost. Untern., 12,3%/13,1% VSt Verpfl.Mehr- / Übern.Aufw.
4677	Reisekosten Unternehmer, 9,8%/10,5% VSt Verpfl.Mehraufw. Gesamtpauschal.
4678	Km-Geld Erstattung, Unternehmer, 5,7%/6,1% VSt
4685	Km-Geld-Erstattung, Arbeitnehmer  8,2%/8,7% VSt
4700	Kosten der Warenabgabe
4710	Verpackungsmaterial
4730	Ausgangsfrachten
4750	Transportversicherungen
4760	Verkaufsprovisionen
4780	Fremdarbeiten
4790	Aufwand für Gewährleistungen
4800	Reparat. u. Inst. v. Maschinen u. technischen Anlagen
4805	Reparat. u. Inst. v. and. Anl. d. Betr.- u. Geschäftsausst.
4809	Sonstige Reparaturen und Instandhaltungen
4810	Mietleasing
4814	Gewerbesteuerl. zu berücksicht. Mietleasing §8 GewStG
4815	Kaufleasing
4820	Abschr. a. Aufw. f.d. Ingangs. u. Erw. des Geschäftsbetr.
4822	Abschr. a. immaterielle Vermögensgegenstände
4824	Abschreibung auf den Geschäfts- oder Firmenwert
4826	Außerplanm. Abschr. a. immaterielle Vermögensgegenstände
4830	Abschreibungen auf Sachanlagen
4840	Außerplanm. Abschreibungen auf Sachanlagen
4850	Abschr. a. Sachanl. aufgrund steuerl. Sondervorschriften
4855	Sofortabschreibung geringwertiger Wirtschaftsgüter
4860	Abschreibung auf aktivierte, geringwertige Wirtschaftsgüter
4865	Außerplanmäßige Abschr. a. aktivierte GWG
4870	Abschreibungen auf Finanzanlagen
4872	Abschr. aufgrund v. Verlustant. an Mitunt. §8 GewStG
4874	Abschr. a. Finanzanl. aufgrund steuerl. Sondervorschriften
4875	Abschreibungen auf Wertpapiere des Umlaufvermögens
4879	Vorwegn. künft. Wertschw. bei Wertpapieren des Umlaufv.
4880	Abschr. a. Umlaufv. ohne Wertpapiere (soweit unübl. Höhe)
4882	Abschr. a. Umlaufv. steuerrechtl. bedingt (unübl. Höhe)
4885	Vorwegn. künft. Wertschw. Uml.V. auß. Vorr./Wertp. d. Uml.V.
4886	Abschr. a. Uml.V. auß. Vorr./Wertp. d. Uml.V. (übl. Höhe)
4887	Abschr. a. Umlaufv., steuerrechtlich bedingt (übl. Höhe)
4890	Vorwegn. künftiger Wertschw. im Umlaufv. (unübl. Höhe)
4900	Sonstige betriebliche Aufwendungen
4905	Sonstige Aufwendungen betrieblich und regelmäßig
4910	Porto
4920	Telefon
4925	Telefax, Fernschreiber
4930	Bürobedarf
4940	Zeitschriften, Bücher
4945	Fortbildungskosten
4946	Freiwillige Sozialleistungen
4948	Vergütungen an freiberufliche Mitunternehmer §15 EStG
4950	Rechts- und Beratungskosten
4955	Buchführungskosten
4957	Abschluß- und Prüfungskosten
4960	Mieten für Einrichtungen
4968	Gewerbest. zu berücks. Miete f. Einrichtungen §8 GewStG
4969	Aufwendungen für Abraum- und Abfallbeseitigung
4970	Nebenkosten des Geldverkehrs
4980	Betriebsbedarf
4985	Werkzeuge und Kleingeräte
4990	Kalkulatorischer Unternehmerlohn
4991	Kalkulatorische Miete und Pacht
4992	Kalkulatorischer Zinsen
4993	Kalkulatorische Abschreibungen
4994	Kalkulatorische Wagnisse
4995	Kalkulatorischer Lohn für unentgeltliche Mitarbeiter
4996	Herstellungskosten
4997	Verwaltungskosten
4998	Vertriebskosten
4999	Gegenkonto 49960-49980
7000	Unfertige Erzeugnisse, unfertige Leistungen (Bestand)
7050	Unfertige Erzeugnisse (Bestand)
7080	Unfertige Leistungen (Bestand)
7090	In Ausführung befindliche Bauaufträge
7095	In Arbeit befindliche Bauaufträge
7100	Fertige Erzeugnisse und Waren (Bestand)
7110	Fertige Erzeugnisse (Bestand)
7140	Fertige Waren (Bestand)
8000	Erlöse (zur freien Verfügung)
8100	Steuerfreie Umsätze o. VSt-Abzug §4 Nr.8 ff. UStG
8110	Sonstige steuerfreie o. VSt-Abzug Umsätze Inland
8120	Steuerfreie Umsätze m. VSt-Abzug §4 Nr.1a, 1c, 2-7 UStG
8125	Steuerfreie innergem. Lief. §4 Nr.1b UStG
8130	Lieferung d. ersten Abnehmers bei innergem. Dreiecksgesch. §25 b Abs. 2 UStG
8135	Steuerfreie ig. Lief. v. Neufahrz. an Abn. ohne UST-ID
8140	Steuerfreie Umsätze Offshore usw.
8150	Sonstige steuerfreie Umsätze Ausland (§4,2-7)
8195	Erlöse aus Geldspielautomaten, 16% Ust
8196	Erlöse aus Geldspielautomaten, 15%/16% USt
8197	Erlöse aus Geldspielautomaten, 15% Ust
8200	Erlöse
8300	Erlöse,  7% USt
8310	Erlöse a.i.Inland steuerpfl. EU-Lieferungen, 7% USt
8315	Erlöse a.i.Inland steuerpfl. EU-Lieferungen, 15%/16% USt
8320	Erlöse a.i. anderen EU-Land steuerpfl. Lieferungen
8330	Erlöse a.i.Inland steuerpfl. EU-Lieferungen, 16% Ust
8335	Erlöse a.i.Inland steuerpfl. EU-Lieferungen, 15% Ust
8339	Erlöse a.i. and. EU-Land steuerpfl. sonst. Leist. (Nullreg.)
8340	Erlöse, 15% Ust
8400	Erlöse, 15%/16% USt
8410	Erlöse, 16% Ust
8500	Provisionserlöse
8504	Provisionserlöse steuerfrei (§4 Nr.8ff UStG)
8505	Provisionserlöse steuerfrei (§4 Nr.5 UStG)
8506	Provisionserlöse,  7% USt
8507	Provisionserlöse, 15% Ust
8508	Provisionserlöse, 15%/16% USt
8509	Provisionserlöse, 16% Ust
8520	Erlöse Abfallverwertung
8540	Erlöse Leergut
8590	Verrechnete Sachbezüge (keine Waren)
8591	Sachbezüge,   7% USt (Waren)
8595	Sachbezüge, 15%/16% USt (Waren)
8596	Sachbezüge, 16% USt (Waren)
8597	Sachbezüge, 15% USt (Waren)
8600	Sonstige Erlöse betrieblich und regelmäßig
8610	Verrechnete sonstige Sachbezüge
8611	Verrechnete sonstige Sachbezüge 15%/16% USt (z.B. Kfz. Gestellung)
8612	Verrechnete sonstige Sachbezüge 16% USt (z.B. Kfz. Gestellung)
8613	Verrechnete sonstige Sachbezüge 15% USt (z.B. Kfz. Gestellung)
8614	Verrechnete sonstige Sachbezüge, ohne Umsatzsteuer
8625	Sonstige Erlöse betrieblich und regelmäßig, steuerfrei
8630	Sonstige Erlöse betrieblich und regelmäßig, 7% USt
8640	Sonstige Erlöse betrieblich und regelmäßig, 15%/16% USt
8645	Sonstige Erlöse betrieblich und regelmäßig, 16% Ust
8647	Sonstige Erlöse betrieblich und regelmäßig, 15% Ust
8650	Erlöse Zinsen und Diskontspesen
8660	Erlöse Zinsen und Diskontspesen aus verbundenen Unternehmen
8700	Erlösschmälerungen
8705	Erlösschmälerungen aus steuerfreien Umsätzen §4 Nr. 1a UStG
8710	Erlösschmälerungen,  7% USt
8720	Erlösschmälerungen, 15%/16% USt
8722	Erlösschmälerungen, 16% Ust
8723	Erlösschmälerungen, 15% Ust
8724	Erlösschmälerungen aus steuerfreien innergm. Lieferungen
8725	Erlösschmäl. a. im Inland steuerpfl. EU-Lieferungen, 7% USt
8726	Erlösschmäl. a. im Inland steuerpfl. EU-Lieferungen, 15%/16% USt
8727	Erlösschmäl. a. im anderen EU-Land steuerpfl. Lief.
8728	Erlösschmäl. a. im Inland steuerpfl. EU-Lieferungen, 16% Ust
8729	Erlösschmäl. a. im Inland steuerpfl. EU-Lieferungen, 15% Ust
8730	Gewährte Skonti
8731	Gewährte Skonti,  7% USt
8735	Gewährte Skonti, 16% Ust
8736	Gewährte Skonti, 15% USt
8740	Gewährte Boni
8750	Gewährte Boni,  7% USt
8760	Gewährte Boni, 15%/16% USt
8762	Gewährte Boni, 16% Ust
8764	Gewährte Boni, 15% Ust
8770	Gewährte Rabatte
8780	Gewährte Rabatte,  7% USt
8790	Gewährte Rabatte, 15%/16% USt
8792	Gewährte Rabatte, 16% Ust
8794	Gewährte Rabatte, 15% Ust
8800	Erlöse aus Anlagenverkäufen
8801	Erlöse aus Anlagenverkäufen 15%/16% USt (bei Buchverlust)
8810	Erlöse aus Anlagenverkäufen 16% USt (bei Buchverlust)
8815	Erlöse aus Anlagenverkäufen 15% USt (bei Buchverlust)
8820	Erlöse aus Anlagenverkäufen 15%/16% USt (bei Buchgewinn)
8829	Erlöse aus Anlagenverkäufen (bei Buchgewinn)
8830	Erlöse aus Anlagenverkäufen 16% USt (bei Buchgewinn)
8835	Erlöse aus Anlagenverkäufen 15% USt (bei Buchgewinn)
8840	Erträge aus Kursdifferenzen
8900	Eigenverbrauch
8905	Entnahme Gegenstände ohne USt
8908	Entnahme von Gegenstände, 16% USt §1 Abs.1 Nr.2a UStG
8909	Entnahme von Gegenstände, 15% USt §1 Abs.1 Nr.2a UStG
8910	Entnahme von Gegenstände, 15%/16% USt §1 Abs.1 Nr.2a UStG
8915	Entnahme von Gegenstände, 7% USt §1 Abs.1 Nr.2a UStG
8920	Entnahme v. sonst. Leist., 15%/16% USt §1 A.1 Nr.2b UStG
8930	Entnahme v. sonst. Leist., 7% USt §1 A.1 Nr.2b UStG
8937	Entnahme v. sonst. Leist., 16% USt §1 A.1 Nr.2b UStG
8938	Entnahme v. sonst. Leist., 15% USt §1 A.1 Nr.2b UStG
8939	Entnahme v. sonst. Leist., ohne USt §1 A.1 Nr.2b UStG
8940	Eigenverbr., 15%/16% Ust  §4 A.1 Nr.5 1-7, A.7 EStG
8941	Eigenverbr., 7% Ust §4 A.1 Nr.5 1-7, A.7 EStG
8942	Eigenverbr., 16% Ust  §4 A.1 Nr.5 1-7, A.7 EStG
8943	Eigenverbr., 15% Ust  §4 A.1 Nr.5 1-7, A.7 EStG
8944	Eigenverbr., ohne Ust §4 A.1 Nr.5 1-7, A.7 EStG
8945	Unentgeltl. Leist. v. Ges. an Ges., 15%/16% USt §1A.1 Nr.3 UStG
8946	Unentgeltl. Leist. v. Ges. an Ges., 7% USt §1A.1 Nr.3 UStG
8947	Unentgeltl. Leist. v. Ges. an Ges., 16% USt §1A.1 Nr.3 UStG
8948	Unentgeltl. Leist. v. Ges. an Ges., 15% USt §1A.1 Nr.3 UStG
8949	Unentgeltl. Leist. v. Ges. an Ges., ohne USt §1A.1 Nr.3 UStG
8950	Nicht steuerbare Umsätze
8955	Umsatzsteuervergütungen
8960	Bestandsveränd. - unfertige Erzeugnisse
8970	Bestandsveränd. - unfertige Leistungen
8975	Bestandsveränd. - in Ausführung befindliche Bauaufträge
8977	Bestandsveränd. - in Arbeit befindliche Aufträge
8980	Bestandsveränd. - fertige Erzeugnisse
8990	Bestandsveränd. - andere aktivierte Eigenleistungen
9000	Saldenvorträge Sachkonten
9008	Saldenvorträge Debitoren
9009	Saldenvorträge Kreditoren
9060	Offene Posten aus 1990
9085	Offene Posten aus 1985
9086	Offene Posten aus 1986
9087	Offene Posten aus 1987
9088	Offene Posten aus 1988
9089	Offene Posten aus 1989
9090	Summenvortragskonto
9091	Offene Posten aus 1991
9092	Offene Posten aus 1992
9093	Offene Posten aus 1993
9094	Offene Posten aus 1994
9095	Offene Posten aus 1995
9096	Offene Posten aus 1996
9097	Offene Posten aus 1997
9098	Offene Posten aus 1998
9100	Saldovortragskonto der Statistikkonten
9101	Verkaufstage
9102	Anzahl der Barkunden
9103	Beschäftigte Personen
9104	Unbezahlte Personen
9105	Verkaufskräfte
9106	Geschäftsraum qm
9107	Verkaufsraum qm
9108	Veränderungsrate positiv
9109	Veränderungsrate negativ
9110	Plan-WE (in Prozent)
9120	Erweiterungsinvestitionen
9135	Auftragseingang im Geschäftsjahr
9140	Auftragsbestand
9190	Gegenkonto für statistische Mengeneinheiten Konten 91010-91190
9199	Gegenkonto zu 91200, 91350-91400
9200	Beschäftigte Personen
9209	Gegenkonto zu 92000
9210	Produktive Löhne
9219	Gegenkonto zu 92100
9230	Baukostenzuschüsse
9232	Investitionszulagen
9234	Investitionszuschüsse
9239	Gegenkonto zu 92300-92380
9240	Investitionsverbindlichkeiten bei den Leistungsverbindlichkeiten
9244	Gegenkonto zu 92400
9245	Forderungen aus Anlagenverkäufen bei den sonstigen Vermögensgegenst.
9249	Gegenkonto zu 92450
9250	Eigenkapitalersetzende Gesellschafterdarlehen
9255	Ungesicherte Gesellschafterdarlehen mit Restlaufzeit > 5 Jahre
9259	Gegenkonto zu 92500-92580
9260	Kurzfristige Rückstellungen
9262	Mittelfristige Rückstellungen
9264	Langfristige Rückstellungen
9269	Gegenkonto zu 92600-92680
9270	Gegenkonto zu 92710-92780
9271	Verb. a. d. Begebung u. Übertragung v. Wechseln
9272	Verb. a. d. Begebung u. Übertr. v. Wechseln gg. verb. U.
9273	Verb. a. Bürgsch., Wechsel- u. Scheckbürgsch.
9274	Verb. a. Bürgsch., Wechsel- u. Scheckbürgsch. gg. verb. U.
9275	Verb. aus Gewährleistungsverträgen
9276	Verb. aus Gewährleistungsverträgen gg. verbund. Untern.
9277	Haftung a. d. Best. von Sicherheiten für fremde Verbindl.
9278	Haftung a.d. Best. v. Sicherh. f. fr. Verbindl. gg. verb. U.
9280	Gegenkonto zu 92810-92840
9281	Verpflichtungen aus Miet- und Leasingverträgen
9282	Verpflichtungen aus Miet- und Leasingverträgen gg. verb. Unternehm.
9283	Andere Verpflichtungen gem. §285 Nr.3 HGB
9284	Andere Verpflichtungen gem. §285 Nr.3 HGB gg. verb. Unternehmen
9410	Aussteh. Einl. §26 A.3 DMBilG nicht eingef. (Aktivausw.)
9411	Aussteh. Einl. §26 A.3 DMBilG eingef. (Aktivausweis)
9413	Aufw. f. Ingangs. u. Erw. d. Gesch.Betr. §31A.1 Nr.2 DMBilG
9415	Nichtentgeltl. erw. immat. Verm.Gegenst. §31A.1 Nr.1 DMBilG
9416	Nutzungsrechte gem. § 9 Abs.3 Satz 2 DMBilG
9420	Ford. gg. verb. Untern. a. Ausgleichsverb. gem. §25 DMBilG
9421	Ford. gg. verb. U. a. Ausgl.Verb. §25 DMBilG Restl. b. 1 J.
9422	Ford. gg. verb. U. a. Ausgl.Verb. §25 DMBilG Restl. gr. 1 J.
9426	Eingeforderte Einlagen §26 Abs. 3 DMBilG
9427	Ausgleichsforderungen §24 DMBilG
9428	Ausgleichsford. §24 DMBilG - Restlaufz. bis 1 Jahr
9429	Ausgleichsford.  §24 DMBilG - Restlaufz. größer 1 Jahr
9430	Ford. nach dem VermG  §7 Abs. 6 DMBilG
9431	Ford. nach dem VermG  §7 A.6 DMBilG - Restl. bis 1 J.
9432	Ford. nach dem VermG  §7 A.6 DMBilG - Restl. gr. 1 J.
9433	Vermögensvorteile §31 Abs.1 Nr. 3 DMBilG
9434	Kapitalentwertungskonto
9435	Kapitalentwertungskonto §28 Abs.1 DMBilG
9436	Kapitalentwertungskonto §26 Abs.4 DMBilG
9438	Sonderverlustkonto aus Rückstellungen §17 Abs.4 DMBilG
9440	Beteiligunsentwertungskonto §24 Abs.5 DMBilG
9445	Vorläufige Gewinnrücklage §31 Abs.1 DMBilG
9446	Sonderrücklage §7 Abs.6 Satz 2 DMBilG
9447	Sonderrücklage §17 Abs.4 Satz 3 DMBilG
9448	Sonderrücklage §24 Abs. 5 Satz 3 DMBilG
9449	Sonderrücklage §27 Abs. 2 Satz 3 DMBilG
9450	Rückst. f. Umweltbeeinträchtigung §17 A.2a DMBilG
9451	Nachrangiges Kapital §16 Abs. 3 Satz 2 DMBilG
9453	Berichtig. v. Wertans. §36 DMBilG - Erhöhung d. Aktiva
9454	Berichtig. v. Wertans. §36 DMBilG - Verm. d. Aktivp.
9455	Berichtig. v. Wertans. §36 DMBilG - Erhöhung d. Passiva
9456	Berichtig. v. Wertans. §36 DMBilG - Verm. d. Passivp.
9457	Verb. gg. verb. Untern. a. Ausgleichsford. gem. §24 DMBilG
9458	Verb. gg. verb. U. a. Ausgl.Ford. §24 DMBilG Restl. b. 1 J.
9459	Verb. gg. verb. U. a. Ausgl.Ford. §24 DMBilG Restl. 1 b. 5 J
9460	Verb. gg. verb. U. a. Ausgl.Ford. §24 DMBilG Restl. gr. 5 J
9462	Verb. gg. verb. Untern. §26 DMBilG
9463	Verb. gg. verb. Untern. §26 DMBilG - Restl. bis 1 J.
9464	Verb. gg. verb. Untern. §26 DMBilG - Restl. 1 bis 5 J.
9465	Verb. gg. verb. Untern. §26 DMBilG - Restl. größer 5 J.
9467	Ausgleichsverbindlichkeiten §25 Abs.1 DMBilG
9468	Ausgleichsverb. §25 Abs.1 DMBilG - Restlaufz. bis 1 J.
9469	Ausgleichsverb. §25 A.1 DMBilG - Restlaufz. 1 bis 5 J.
9470	Ausgleichsverb. §25 A.1 DMBilG - Restlaufz. größer 5 J.
9472	Verb. nach dem VermG §7 Abs.6 DMBilG
9473	Verb. nach dem VermG §7 A.6 DMBilG - Restl. bis 1 J.
9474	Verb. nach dem VermG §7 A.6 DMBilG - Restl. 1 bis 5 J.
9475	Verb. nach dem VermG §7 A.6 DMBilG - Restl. größer 5 J.
9476	Verb. aus Rückzahlungsverpfl. 17 Abs.4a DMBilG
9477	Verb. a. Rückzahlg.Verpfl. - Restl. b. 1 J. §17 A.4a DMBilG
9478	Verb. a. Rückzahlg.Verpfl. - Restl. 1 b. 5 J. §17A.4a DMBilG
9479	Verb. a. Rückzahlg.Verpfl. - Restl. gr. 5 J. §17 A.4a DMBilG
9480	Auflösung Kapitalentwertungskonto §28 A.2 Satz 4 DMBilG
9481	Entnahmen a. vorläufigen Gewinnrücklagen §31 A.6 DMBilG
9482	Entnahmen a. Sonderrückl. zum Ausgleich von Verlusten
9486	Abschreibungen auf Ausgleichsforderungen DMBilG
9487	Erträge aus der Auflösung von Rückstellungen DMBilG
9500	Anteil für Konto 09000-09090
9510	Anteil für Konto 09100-09190
9520	Anteil für Konto 09200-09290
9530	Anteil für Konto 08300-08390
9540	Anteil für Konto 08100-08190
9570	Anteil für Konto 08700-08790
9580	Anteil für Konto 08800-08890
9590	Anteil für Konto 08900-08990
9600	Name des Gesellschafters (Vollhafter)
9610	Tätigkeitsvergütung (Vollhafter)
9620	Tantieme (Vollhafter)
9630	Darlehensverzinsung (Vollhafter)
9640	Gebrauchsüberlassung (Vollhafter)
9650	Sonstige Vergütungen (Vollhafter)
9690	Restanteil (Vollhafter)
9700	Name des Gesellschafters (Teilhafter)
9710	Tätigkeitsvergütung (Teilhafter)
9720	Tantieme (Teilhafter)
9730	Darlehensverzinsung (Teilhafter)
9740	Gebrauchsüberlassung (Teilhafter)
9750	Sonstige Vergütungen (Teilhafter)
9790	Restanteil (Teilhafter)
9890	Statistisches Konto für passive Lohnveredelung
9899	Gegenkonto zu 9890
\.


--
-- Data for Name: gl; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.gl (id, reference, description, transdate, employee_id, notes, department_id, approved, curr, exchangerate, ts, onhold) FROM stdin;
\.


--
-- Data for Name: gl_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.gl_log (id, reference, description, transdate, employee_id, notes, department_id, approved, curr, exchangerate, ts, onhold) FROM stdin;
\.


--
-- Data for Name: gl_log_deleted; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.gl_log_deleted (id, reference, description, transdate, employee_id, notes, department_id, approved, curr, exchangerate, ts, onhold) FROM stdin;
\.


--
-- Data for Name: imported_balance; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.imported_balance (id, banking_import_event_id, balance_type, amount, balance_currency, credit_debit, date) FROM stdin;
\.


--
-- Data for Name: imported_transaction; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.imported_transaction (id, parent_imported_transaction_id, banking_import_event_id, amount, currency, credit_debit, booking_date, status, reversal_indicator, transaction_ref, bank_domain_code, bank_family_code, bank_sub_family_code, transaction_text, origin_amount, origin_currency, exchange_rate, related_party_name, related_party_address, end_to_end_id, purpose, remittance_ref, remittance_type, hashcode, suppression) FROM stdin;
\.


--
-- Data for Name: imported_transaction_to_booking; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.imported_transaction_to_booking (imported_transaction_id, booking_id, ledger_type, exchange_rate) FROM stdin;
\.


--
-- Data for Name: inventory; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.inventory (id, warehouse_id, parts_id, trans_id, orderitems_id, qty, shippingdate, employee_id, department_id, warehouse_id2, serialnumber, itemnotes, cost, linetype, description, invoice_id, cogs) FROM stdin;
2	10255	10258	10260	1	20	2025-04-01	0	0	\N			50	0	Werkzeugkoffer	2	\N
3	10255	10259	10260	1	30	2025-04-01	0	0	\N			12	0	Handbuch	3	\N
4	10255	10258	10261	1	-5	2025-04-10	0	0	\N			\N	0	Werkzeugkoffer	4	\N
5	10255	10259	10261	1	-10	2025-04-10	0	0	\N			\N	0	Handbuch	5	\N
\.


--
-- Data for Name: invoice; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.invoice (id, trans_id, parts_id, description, qty, allocated, sellprice, fxsellprice, discount, assemblyitem, unit, project_id, deliverydate, serialnumber, itemnotes, lineitemdetail, ordernumber, ponumber, transdate, lastcost, warehouse_id, cogs) FROM stdin;
2	10260	10258	Werkzeugkoffer	-20	5	50	50	0	f	Stk	\N	\N			f			2025-04-01	\N	10255	\N
4	10261	10258	Werkzeugkoffer	5	-5	89	89	0	f	Stk	\N	\N			f			2025-04-10	\N	10255	\N
3	10260	10259	Handbuch	-30	10	12	12	0	f	Stk	\N	\N			f			2025-04-01	\N	10255	\N
5	10261	10259	Handbuch	10	-10	25	25	0	f	Stk	\N	\N			f			2025-04-10	\N	10255	\N
\.


--
-- Data for Name: invoice_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.invoice_log (id, trans_id, parts_id, description, qty, allocated, sellprice, fxsellprice, discount, assemblyitem, unit, project_id, deliverydate, serialnumber, itemnotes, lineitemdetail, ordernumber, ponumber, transdate, lastcost, warehouse_id, cogs, ts) FROM stdin;
\.


--
-- Data for Name: invoice_log_deleted; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.invoice_log_deleted (trans_id, chart_id, amount, transdate, source, approved, fx_transaction, project_id, memo, id, cleared, vr_id, entry_id, tax, taxamount, tax_chart_id, ts) FROM stdin;
\.


--
-- Data for Name: invoicetax; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.invoicetax (trans_id, invoice_id, chart_id, taxamount, amount) FROM stdin;
10260	2	10019	190	1000
10260	3	10017	25.2	360
10260	3	10252	25.2	360
10261	4	10022	84.55	445
10261	5	10252	17.5	250
\.


--
-- Data for Name: jcitems; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.jcitems (id, project_id, parts_id, description, qty, allocated, sellprice, fxsellprice, serialnumber, checkedin, checkedout, employee_id, notes) FROM stdin;
\.


--
-- Data for Name: language; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.language (code, description) FROM stdin;
\.


--
-- Data for Name: lastused; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lastused (id, report, cols, login) FROM stdin;
\.


--
-- Data for Name: makemodel; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.makemodel (parts_id, make, model) FROM stdin;
\.


--
-- Data for Name: oe; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.oe (id, ordnumber, transdate, vendor_id, customer_id, amount, netamount, reqdate, taxincluded, shippingpoint, notes, curr, employee_id, closed, quotation, quonumber, intnotes, department_id, shipvia, language_code, ponumber, terms, waybill, warehouse_id, description, aa_id, exchangerate) FROM stdin;
\.


--
-- Data for Name: orderitems; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.orderitems (id, trans_id, parts_id, description, qty, sellprice, discount, unit, project_id, reqdate, ship, serialnumber, itemnotes, lineitemdetail, ordernumber, ponumber) FROM stdin;
\.


--
-- Data for Name: parts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.parts (id, partnumber, description, unit, listprice, sellprice, lastcost, priceupdate, weight, onhand, notes, makemodel, assembly, alternate, rop, inventory_accno_id, income_accno_id, expense_accno_id, bin, obsolete, bom, image, drawing, microfiche, partsgroup_id, project_id, avgcost, tariff_hscode, countryorigin, barcode, toolnumber) FROM stdin;
10258	D-100	Werkzeugkoffer	Stk	0	89	50	2026-10-16	0	15		f	f	f	0	10188	10254	10135		f	f				0	\N	50				
10259	D-200	Handbuch	Stk	0	25	12	2026-10-16	0	20		f	f	f	0	10188	10253	10135		f	f				0	\N	12				
\.


--
-- Data for Name: partsattr; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.partsattr (parts_id, hotnew) FROM stdin;
\.


--
-- Data for Name: partscustomer; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.partscustomer (parts_id, customer_id, pricegroup_id, pricebreak, sellprice, validfrom, validto, curr) FROM stdin;
\.


--
-- Data for Name: partsgroup; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.partsgroup (id, partsgroup, pos) FROM stdin;
\.


--
-- Data for Name: partstax; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.partstax (parts_id, chart_id) FROM stdin;
10258	10019
10258	10022
10259	10017
10259	10252
\.


--
-- Data for Name: partsvendor; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.partsvendor (vendor_id, parts_id, partnumber, leadtime, lastcost, curr) FROM stdin;
\.


--
-- Data for Name: payment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payment (id, trans_id, exchangerate, paymentmethod_id) FROM stdin;
1	10261	1	0
\.


--
-- Data for Name: paymentmethod; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.paymentmethod (id, description, fee, rn) FROM stdin;
\.


--
-- Data for Name: pricegroup; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pricegroup (id, pricegroup) FROM stdin;
\.


--
-- Data for Name: project; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.project (id, projectnumber, description, startdate, enddate, parts_id, production, completed, customer_id) FROM stdin;
\.


--
-- Data for Name: recurring; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.recurring (id, reference, startdate, nextdate, enddate, repeat, unit, howmany, payment, description) FROM stdin;
\.


--
-- Data for Name: recurringemail; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.recurringemail (id, formname, format, message) FROM stdin;
\.


--
-- Data for Name: recurringprint; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.recurringprint (id, formname, format, printer) FROM stdin;
\.


--
-- Data for Name: report; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.report (reportid, reportcode, reportdescription, login) FROM stdin;
\.


--
-- Data for Name: reportvars; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reportvars (reportid, reportvariable, reportvalue) FROM stdin;
\.


--
-- Data for Name: search_irrelevant_words; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.search_irrelevant_words (id, search_target, word) FROM stdin;
1	RELATED_PARTY	sÃ rl
2	RELATED_PARTY	sa
3	RELATED_PARTY	gmbh
4	RELATED_PARTY	ag
5	RELATED_PARTY	sarl
6	RELATED_PARTY	sagl
7	RELATED_PARTY	gbr
8	RELATED_PARTY	ohg
9	RELATED_PARTY	partg
10	RELATED_PARTY	ug
11	RELATED_PARTY	ggmbh
12	RELATED_PARTY	llc
13	COMMON	the
14	COMMON	a
15	COMMON	an
16	COMMON	and
17	COMMON	der
18	COMMON	die
19	COMMON	das
20	COMMON	und
21	COMMON	ein
22	COMMON	eine
23	COMMON	le
24	COMMON	la
25	COMMON	et
26	COMMON	un
27	COMMON	une
\.


--
-- Data for Name: semaphore; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.semaphore (id, login, module, expires) FROM stdin;
\.


--
-- Data for Name: shipto; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.shipto (trans_id, shiptoname, shiptoaddress1, shiptoaddress2, shiptocity, shiptostate, shiptozipcode, shiptocountry, shiptocontact, shiptophone, shiptofax, shiptoemail) FROM stdin;
\.


--
-- Data for Name: sic; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sic (code, sictype, description) FROM stdin;
\.


--
-- Data for Name: status; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.status (trans_id, formname, printed, emailed, spoolfile) FROM stdin;
\.


--
-- Data for Name: tax; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tax (chart_id, rate, taxnumber, validto, reversecharge_id, vatkey, formdigit, validfrom, id, inactive) FROM stdin;
10017	0.07	\N	2019-12-31	\N	\N	0	\N	1	f
10018	0.16	\N	2019-12-31	\N	\N	0	\N	2	f
10019	0.15	\N	2019-12-31	\N	\N	0	\N	3	f
10021	0.16	\N	2019-12-31	\N	\N	0	\N	4	f
10022	0.15	\N	2019-12-31	\N	\N	0	\N	5	f
10249	0.16	\N	2019-12-31	\N	\N	0	\N	6	f
10250	0.16	\N	2019-12-31	\N	\N	0	\N	7	f
10019	0.19	DE123456789	\N	\N	\N	0	2020-01-01	8	f
10022	0.19	DE123456789	\N	\N	\N	0	2020-01-01	9	f
10017	0.07	DE123456789	\N	\N	\N	0	2020-01-01	10	f
10252	0.07	DE123456789	\N	\N	\N	0	2020-01-01	11	f
\.


--
-- Data for Name: translation; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.translation (trans_id, language_code, description) FROM stdin;
\.


--
-- Data for Name: trf; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.trf (id, transdate, trfnumber, description, notes, department_id, from_warehouse_id, to_warehouse_id, employee_id, delivereddate) FROM stdin;
\.


--
-- Data for Name: vat_settlement; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.vat_settlement (id, vat_form_id, period_from, period_to, creation_date, data, xml, type, meldecenter_data) FROM stdin;
\.


--
-- Data for Name: vendor; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.vendor (id, name, contact, phone, fax, email, notes, terms, taxincluded, vendornumber, cc, bcc, gifi_accno, business_id, taxnumber, sic_code, discount, creditlimit, iban, bic, employee_id, language_code, pricegroup_id, curr, startdate, enddate, arap_accno_id, payment_accno_id, discount_accno_id, cashdiscount, discountterms, threshold, paymentmethod_id, remittancevoucher, dispatch_id, last_modified, expense_accno_id, early_payment_discount, payment_clearing_accno_id, reminderstop) FROM stdin;
10257	Großhandel AG	 					30	f	DL-2				0			0	0			0	\N	0	EUR	2024-01-01	\N	\N	\N	\N	0	0	0	0	t	0	2026-10-16 15:23:43.696744+02	10135	0.0300	\N	f
\.


--
-- Data for Name: vendortax; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.vendortax (vendor_id, chart_id) FROM stdin;
10257	10017
10257	10019
\.


--
-- Data for Name: vr; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.vr (br_id, trans_id, id, vouchernumber) FROM stdin;
\.


--
-- Data for Name: warehouse; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.warehouse (id, description) FROM stdin;
10255	Lager Berlin
\.


--
-- Data for Name: xabschluss; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.xabschluss (id, xml, data, status) FROM stdin;
\.


--
-- Data for Name: xabschluss_history; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.xabschluss_history (id, xml, data) FROM stdin;
\.


--
-- Data for Name: xcontrolling_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.xcontrolling_log (id, trans_id, controlling_key, checked, checked_timestamp, checked_hash, checked_login_ref, checked_by_ibp_user_id) FROM stdin;
\.


--
-- Data for Name: yearend; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.yearend (trans_id, transdate, id) FROM stdin;
\.


--
-- Name: addressid; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.addressid', 3, true);


--
-- Name: assemblyid; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.assemblyid', 1, true);


--
-- Name: bank_account_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.bank_account_id_seq', 1, false);


--
-- Name: banking_export_event_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.banking_export_event_id_seq', 1, false);


--
-- Name: banking_import_event_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.banking_import_event_id_seq', 1, false);


--
-- Name: blink_export_process_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.blink_export_process_id_seq', 1, false);


--
-- Name: blink_export_process_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.blink_export_process_log_id_seq', 1, false);


--
-- Name: blink_import_process_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.blink_import_process_id_seq', 1, false);


--
-- Name: blink_import_process_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.blink_import_process_log_id_seq', 1, false);


--
-- Name: booking_to_settlement_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.booking_to_settlement_id_seq', 1, false);


--
-- Name: chat_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.chat_id_seq', 1, false);


--
-- Name: contactid; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.contactid', 3, true);


--
-- Name: credits_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.credits_id_seq', 1, false);


--
-- Name: customerloginid; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.customerloginid', 1, true);


--
-- Name: debits_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.debits_id_seq', 1, false);


--
-- Name: debitscredits_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.debitscredits_id_seq', 1, false);


--
-- Name: entry_id; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.entry_id', 17, true);


--
-- Name: exported_payment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.exported_payment_id_seq', 1, false);


--
-- Name: financial_year_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.financial_year_id_seq', 1, true);


--
-- Name: id; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.id', 10261, true);


--
-- Name: imported_balance_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.imported_balance_id_seq', 1, false);


--
-- Name: imported_transaction_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.imported_transaction_id_seq', 1, false);


--
-- Name: inventoryid; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.inventoryid', 5, true);


--
-- Name: invoiceid; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.invoiceid', 5, true);


--
-- Name: jcitemsid; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.jcitemsid', 1, true);


--
-- Name: lastused_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.lastused_id_seq', 1, false);


--
-- Name: orderitemsid; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.orderitemsid', 1, true);


--
-- Name: search_irrelevant_words_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.search_irrelevant_words_id_seq', 27, true);


--
-- Name: tax_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tax_id_seq', 11, true);


--
-- Name: vat_settlement_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.vat_settlement_id_seq', 1, false);


--
-- Name: xabschluss_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.xabschluss_history_id_seq', 1, false);


--
-- Name: xabschluss_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.xabschluss_id_seq', 1, false);


--
-- Name: xcontrolling_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.xcontrolling_log_id_seq', 1, false);


--
-- Name: yearend_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.yearend_id_seq', 1, false);


--
-- Name: address address_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.address
    ADD CONSTRAINT address_pkey PRIMARY KEY (id);


--
-- Name: bank_account bank_account_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bank_account
    ADD CONSTRAINT bank_account_pkey PRIMARY KEY (id);


--
-- Name: banking_export_event banking_export_event_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.banking_export_event
    ADD CONSTRAINT banking_export_event_pkey PRIMARY KEY (id);


--
-- Name: banking_import_event banking_import_event_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.banking_import_event
    ADD CONSTRAINT banking_import_event_pkey PRIMARY KEY (id);


--
-- Name: blink_export_process_log blink_export_process_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blink_export_process_log
    ADD CONSTRAINT blink_export_process_log_pkey PRIMARY KEY (id);


--
-- Name: blink_export_process blink_export_process_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blink_export_process
    ADD CONSTRAINT blink_export_process_pkey PRIMARY KEY (id);


--
-- Name: blink_import_process_log blink_import_process_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blink_import_process_log
    ADD CONSTRAINT blink_import_process_log_pkey PRIMARY KEY (id);


--
-- Name: blink_import_process blink_import_process_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blink_import_process
    ADD CONSTRAINT blink_import_process_pkey PRIMARY KEY (id);


--
-- Name: booking_to_settlement booking_to_settlement_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.booking_to_settlement
    ADD CONSTRAINT booking_to_settlement_pkey PRIMARY KEY (id);


--
-- Name: br br_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.br
    ADD CONSTRAINT br_pkey PRIMARY KEY (id);


--
-- Name: build build_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.build
    ADD CONSTRAINT build_pkey PRIMARY KEY (id);


--
-- Name: chat chat_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.chat
    ADD CONSTRAINT chat_pkey PRIMARY KEY (id);


--
-- Name: contact contact_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contact
    ADD CONSTRAINT contact_pkey PRIMARY KEY (id);


--
-- Name: curr curr_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.curr
    ADD CONSTRAINT curr_pkey PRIMARY KEY (curr);


--
-- Name: customer customer_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer
    ADD CONSTRAINT customer_pkey PRIMARY KEY (id);


--
-- Name: customerlogin customerlogin_login_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customerlogin
    ADD CONSTRAINT customerlogin_login_key UNIQUE (login);


--
-- Name: customerlogin customerlogin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customerlogin
    ADD CONSTRAINT customerlogin_pkey PRIMARY KEY (id);


--
-- Name: customerlogin customerlogin_session_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customerlogin
    ADD CONSTRAINT customerlogin_session_key UNIQUE (session);


--
-- Name: exported_payment exported_payment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.exported_payment
    ADD CONSTRAINT exported_payment_pkey PRIMARY KEY (id);


--
-- Name: financial_year financial_year_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.financial_year
    ADD CONSTRAINT financial_year_pkey PRIMARY KEY (id);


--
-- Name: imported_balance imported_balance_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.imported_balance
    ADD CONSTRAINT imported_balance_pkey PRIMARY KEY (id);


--
-- Name: imported_transaction imported_transaction_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.imported_transaction
    ADD CONSTRAINT imported_transaction_pkey PRIMARY KEY (id);


--
-- Name: invoice invoice_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoice
    ADD CONSTRAINT invoice_pkey PRIMARY KEY (id);


--
-- Name: lastused lastused_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lastused
    ADD CONSTRAINT lastused_pkey PRIMARY KEY (id);


--
-- Name: paymentmethod paymentmethod_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.paymentmethod
    ADD CONSTRAINT paymentmethod_pkey PRIMARY KEY (id);


--
-- Name: report report_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.report
    ADD CONSTRAINT report_pkey PRIMARY KEY (reportid);


--
-- Name: search_irrelevant_words search_irrelevant_words_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.search_irrelevant_words
    ADD CONSTRAINT search_irrelevant_words_pkey PRIMARY KEY (id);


--
-- Name: tax tax_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tax
    ADD CONSTRAINT tax_pkey PRIMARY KEY (id);


--
-- Name: trf trf_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trf
    ADD CONSTRAINT trf_pkey PRIMARY KEY (id);


--
-- Name: vat_settlement vat_settlement_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vat_settlement
    ADD CONSTRAINT vat_settlement_pkey PRIMARY KEY (id);


--
-- Name: vendor vendor_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vendor
    ADD CONSTRAINT vendor_pkey PRIMARY KEY (id);


--
-- Name: xabschluss_history xabschluss_history_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.xabschluss_history
    ADD CONSTRAINT xabschluss_history_pkey PRIMARY KEY (id);


--
-- Name: xabschluss xabschluss_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.xabschluss
    ADD CONSTRAINT xabschluss_pkey PRIMARY KEY (id);


--
-- Name: yearend yearend_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.yearend
    ADD CONSTRAINT yearend_pkey PRIMARY KEY (id);


--
-- Name: acc_trans_chart_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX acc_trans_chart_id_key ON public.acc_trans USING btree (chart_id);


--
-- Name: acc_trans_chart_id_transdate_approved_trans_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX acc_trans_chart_id_transdate_approved_trans_id ON public.acc_trans USING btree (chart_id, transdate, approved, trans_id, amount);


--
-- Name: acc_trans_source_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX acc_trans_source_key ON public.acc_trans USING btree (lower(source));


--
-- Name: acc_trans_trans_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX acc_trans_trans_id_key ON public.acc_trans USING btree (trans_id);


--
-- Name: acc_trans_transdate_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX acc_trans_transdate_key ON public.acc_trans USING btree (transdate);


--
-- Name: ap_employee_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ap_employee_id_key ON public.ap USING btree (employee_id);


--
-- Name: ap_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ap_id_key ON public.ap USING btree (id);


--
-- Name: ap_invnumber_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ap_invnumber_key ON public.ap USING btree (invnumber);


--
-- Name: ap_ordnumber_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ap_ordnumber_key ON public.ap USING btree (ordnumber);


--
-- Name: ap_quonumber_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ap_quonumber_key ON public.ap USING btree (quonumber);


--
-- Name: ap_transdate_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ap_transdate_key ON public.ap USING btree (transdate);


--
-- Name: ap_vendor_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ap_vendor_id_key ON public.ap USING btree (vendor_id);


--
-- Name: ar_customer_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ar_customer_id_key ON public.ar USING btree (customer_id);


--
-- Name: ar_employee_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ar_employee_id_key ON public.ar USING btree (employee_id);


--
-- Name: ar_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ar_id_key ON public.ar USING btree (id);


--
-- Name: ar_invnumber_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ar_invnumber_key ON public.ar USING btree (invnumber);


--
-- Name: ar_ordnumber_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ar_ordnumber_key ON public.ar USING btree (ordnumber);


--
-- Name: ar_quonumber_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ar_quonumber_key ON public.ar USING btree (quonumber);


--
-- Name: ar_transdate_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ar_transdate_key ON public.ar USING btree (transdate);


--
-- Name: assembly_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX assembly_id_key ON public.assembly USING btree (id);


--
-- Name: audittrail_trans_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX audittrail_trans_id_key ON public.audittrail USING btree (trans_id);


--
-- Name: cargo_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX cargo_id_key ON public.cargo USING btree (id, trans_id);


--
-- Name: chart_accno_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX chart_accno_key ON public.chart USING btree (accno);


--
-- Name: chart_category_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX chart_category_key ON public.chart USING btree (category);


--
-- Name: chart_gifi_accno_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX chart_gifi_accno_key ON public.chart USING btree (gifi_accno);


--
-- Name: chart_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX chart_id_key ON public.chart USING btree (id);


--
-- Name: chart_link_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX chart_link_key ON public.chart USING btree (link);


--
-- Name: customer_contact_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX customer_contact_key ON public.customer USING btree (lower((contact)::text));


--
-- Name: customer_customer_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX customer_customer_id_key ON public.customertax USING btree (customer_id);


--
-- Name: customer_customernumber_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX customer_customernumber_key ON public.customer USING btree (customernumber);


--
-- Name: customer_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX customer_name_key ON public.customer USING btree (lower((name)::text));


--
-- Name: department_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX department_id_key ON public.department USING btree (id);


--
-- Name: employee_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX employee_id_key ON public.employee USING btree (id);


--
-- Name: employee_login_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX employee_login_key ON public.employee USING btree (login);


--
-- Name: employee_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX employee_name_key ON public.employee USING btree (lower((name)::text));


--
-- Name: exchangerate_ct_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX exchangerate_ct_key ON public.exchangerate USING btree (curr, transdate);


--
-- Name: fifo_parts_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fifo_parts_id ON public.fifo USING btree (parts_id);


--
-- Name: fifo_trans_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fifo_trans_id ON public.fifo USING btree (trans_id);


--
-- Name: gifi_accno_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX gifi_accno_key ON public.gifi USING btree (accno);


--
-- Name: gl_description_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX gl_description_key ON public.gl USING btree (lower(description));


--
-- Name: gl_employee_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX gl_employee_id_key ON public.gl USING btree (employee_id);


--
-- Name: gl_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX gl_id_key ON public.gl USING btree (id);


--
-- Name: gl_reference_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX gl_reference_key ON public.gl USING btree (reference);


--
-- Name: gl_transdate_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX gl_transdate_key ON public.gl USING btree (transdate);


--
-- Name: inventory_invoice_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX inventory_invoice_id ON public.inventory USING btree (invoice_id);


--
-- Name: inventory_parts_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX inventory_parts_id_key ON public.inventory USING btree (parts_id);


--
-- Name: invoice_parts_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX invoice_parts_id ON public.invoice USING btree (parts_id);


--
-- Name: invoice_qty; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX invoice_qty ON public.invoice USING btree (qty);


--
-- Name: invoice_trans_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX invoice_trans_id_key ON public.invoice USING btree (trans_id);


--
-- Name: jcitems_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX jcitems_id_key ON public.jcitems USING btree (id);


--
-- Name: language_code_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX language_code_key ON public.language USING btree (code);


--
-- Name: makemodel_make_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX makemodel_make_key ON public.makemodel USING btree (lower(make));


--
-- Name: makemodel_model_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX makemodel_model_key ON public.makemodel USING btree (lower(model));


--
-- Name: makemodel_parts_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX makemodel_parts_id_key ON public.makemodel USING btree (parts_id);


--
-- Name: oe_employee_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX oe_employee_id_key ON public.oe USING btree (employee_id);


--
-- Name: oe_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX oe_id_key ON public.oe USING btree (id);


--
-- Name: oe_ordnumber_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX oe_ordnumber_key ON public.oe USING btree (ordnumber);


--
-- Name: oe_transdate_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX oe_transdate_key ON public.oe USING btree (transdate);


--
-- Name: orderitems_trans_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX orderitems_trans_id_key ON public.orderitems USING btree (trans_id);


--
-- Name: parts_description_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX parts_description_key ON public.parts USING btree (lower(description));


--
-- Name: parts_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX parts_id_key ON public.parts USING btree (id);


--
-- Name: parts_partnumber_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX parts_partnumber_key ON public.parts USING btree (lower(partnumber));


--
-- Name: partscustomer_customer_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX partscustomer_customer_id_key ON public.partscustomer USING btree (customer_id);


--
-- Name: partscustomer_parts_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX partscustomer_parts_id_key ON public.partscustomer USING btree (parts_id);


--
-- Name: partsgroup_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX partsgroup_id_key ON public.partsgroup USING btree (id);


--
-- Name: partsgroup_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX partsgroup_key ON public.partsgroup USING btree (partsgroup);


--
-- Name: partstax_parts_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX partstax_parts_id_key ON public.partstax USING btree (parts_id);


--
-- Name: partsvendor_parts_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX partsvendor_parts_id_key ON public.partsvendor USING btree (parts_id);


--
-- Name: partsvendor_vendor_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX partsvendor_vendor_id_key ON public.partsvendor USING btree (vendor_id);


--
-- Name: pricegroup_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX pricegroup_id_key ON public.pricegroup USING btree (id);


--
-- Name: pricegroup_pricegroup_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX pricegroup_pricegroup_key ON public.pricegroup USING btree (pricegroup);


--
-- Name: project_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX project_id_key ON public.project USING btree (id);


--
-- Name: projectnumber_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX projectnumber_key ON public.project USING btree (projectnumber);


--
-- Name: shipto_trans_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX shipto_trans_id_key ON public.shipto USING btree (trans_id);


--
-- Name: status_trans_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX status_trans_id_key ON public.status USING btree (trans_id);


--
-- Name: translation_trans_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX translation_trans_id_key ON public.translation USING btree (trans_id);


--
-- Name: vendor_contact_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX vendor_contact_key ON public.vendor USING btree (lower((contact)::text));


--
-- Name: vendor_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX vendor_name_key ON public.vendor USING btree (lower((name)::text));


--
-- Name: vendor_vendornumber_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX vendor_vendornumber_key ON public.vendor USING btree (vendornumber);


--
-- Name: vendortax_vendor_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX vendortax_vendor_id_key ON public.vendortax USING btree (vendor_id);


--
-- Name: customer trg_set_last_modified_customer; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_set_last_modified_customer BEFORE UPDATE ON public.customer FOR EACH ROW EXECUTE FUNCTION public.update_last_modified_column();


--
-- Name: vendor trg_set_last_modified_vendor; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_set_last_modified_vendor BEFORE UPDATE ON public.vendor FOR EACH ROW EXECUTE FUNCTION public.update_last_modified_column();


--
-- Name: acc_trans acc_trans_imported_transaction_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.acc_trans
    ADD CONSTRAINT acc_trans_imported_transaction_id_fkey FOREIGN KEY (imported_transaction_id) REFERENCES public.imported_transaction(id);


--
-- Name: banking_export_event banking_export_event_bank_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.banking_export_event
    ADD CONSTRAINT banking_export_event_bank_account_id_fkey FOREIGN KEY (bank_account_id) REFERENCES public.bank_account(id);


--
-- Name: banking_import_event banking_import_event_bank_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.banking_import_event
    ADD CONSTRAINT banking_import_event_bank_account_id_fkey FOREIGN KEY (bank_account_id) REFERENCES public.bank_account(id);


--
-- Name: blink_export_process blink_export_process_bank_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blink_export_process
    ADD CONSTRAINT blink_export_process_bank_account_id_fkey FOREIGN KEY (bank_account_id) REFERENCES public.bank_account(id);


--
-- Name: blink_export_process_log blink_export_process_log_banking_export_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blink_export_process_log
    ADD CONSTRAINT blink_export_process_log_banking_export_event_id_fkey FOREIGN KEY (banking_export_event_id) REFERENCES public.banking_export_event(id);


--
-- Name: blink_export_process_log blink_export_process_log_blink_export_process_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blink_export_process_log
    ADD CONSTRAINT blink_export_process_log_blink_export_process_id_fkey FOREIGN KEY (blink_export_process_id) REFERENCES public.blink_export_process(id);


--
-- Name: blink_import_process blink_import_process_bank_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blink_import_process
    ADD CONSTRAINT blink_import_process_bank_account_id_fkey FOREIGN KEY (bank_account_id) REFERENCES public.bank_account(id);


--
-- Name: blink_import_process_log blink_import_process_log_banking_import_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blink_import_process_log
    ADD CONSTRAINT blink_import_process_log_banking_import_event_id_fkey FOREIGN KEY (banking_import_event_id) REFERENCES public.banking_import_event(id);


--
-- Name: blink_import_process_log blink_import_process_log_blink_import_process_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blink_import_process_log
    ADD CONSTRAINT blink_import_process_log_blink_import_process_id_fkey FOREIGN KEY (blink_import_process_id) REFERENCES public.blink_import_process(id);


--
-- Name: booking_to_settlement booking_to_settlement_settlement_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.booking_to_settlement
    ADD CONSTRAINT booking_to_settlement_settlement_id_fkey FOREIGN KEY (settlement_id) REFERENCES public.vat_settlement(id);


--
-- Name: exported_payment exported_payment_banking_export_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.exported_payment
    ADD CONSTRAINT exported_payment_banking_export_event_id_fkey FOREIGN KEY (banking_export_event_id) REFERENCES public.banking_export_event(id);


--
-- Name: financial_year fk_yearend; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.financial_year
    ADD CONSTRAINT fk_yearend FOREIGN KEY (yearend_id) REFERENCES public.yearend(id) ON DELETE SET NULL;


--
-- Name: imported_balance imported_balance_banking_import_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.imported_balance
    ADD CONSTRAINT imported_balance_banking_import_event_id_fkey FOREIGN KEY (banking_import_event_id) REFERENCES public.banking_import_event(id);


--
-- Name: imported_transaction imported_transaction_banking_import_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.imported_transaction
    ADD CONSTRAINT imported_transaction_banking_import_event_id_fkey FOREIGN KEY (banking_import_event_id) REFERENCES public.banking_import_event(id);


--
-- Name: imported_transaction imported_transaction_parent_imported_transaction_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.imported_transaction
    ADD CONSTRAINT imported_transaction_parent_imported_transaction_id_fkey FOREIGN KEY (parent_imported_transaction_id) REFERENCES public.imported_transaction(id);


--
-- Name: imported_transaction_to_booking imported_transaction_to_booking_imported_transaction_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.imported_transaction_to_booking
    ADD CONSTRAINT imported_transaction_to_booking_imported_transaction_id_fkey FOREIGN KEY (imported_transaction_id) REFERENCES public.imported_transaction(id);


--
-- Name: vr vr_br_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vr
    ADD CONSTRAINT vr_br_id_fkey FOREIGN KEY (br_id) REFERENCES public.br(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

